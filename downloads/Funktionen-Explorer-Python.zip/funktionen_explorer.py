"""
funktionen_explorer.py
======================

Funktionen-Explorer: Erweiterung des Polynom-Explorers auf beliebige Funktionsterme
(3Blue1Brown-Stil). Benötigt polynom_explorer.py im selben Ordner.

Alles aus dem Polynom-Explorer bleibt erhalten (Grad-Regler, Koeffizienten, Stützpunkte,
Nullstellen, Extrema, Wendepunkte, Tangenten, Integral mit ziehbaren Grenzen, Zoom, Verschieben).
Neu:

* Allgemeine Termeingabe  f(x) = …  mit allen reellen Funktionen des Python-Moduls math
  (sin, cos, exp, log, gamma, erf, …), den eingebauten Funktionen abs, round, min, max sowie
  sign, heaviside und sinc aus numpy.
* Menüpunkt „Weitere Funktionen“: durchscrollbare, durchsuchbare Liste; Antippen/Anklicken
  fügt die Funktion an der Cursorposition in die Termeingabe ein.
* Wechselschalter „dunkel | hell“ oben rechts (aus dem Polynom-Explorer): schaltet die gesamte Darstellung
  zwischen dem dunklen 3Blue1Brown-Stil und dem hellen Farbschema der Pearson-Mathematikbücher um
  (auch per Programm: set_design("pearson") / set_design("3b1b") oder starte(…, design="pearson")).
* Funktionsleiste  F | f | f′ | f″ | f‴  (Wechselschalter, beliebig kombinierbar): Stammfunktion, Funktion und
  1.–3. Ableitung gleichzeitig mit allen Eigenschaften. Ableitungen werden symbolisch gebildet und vereinfacht
  (Ausdruck.ableitung()), die Stammfunktion F(x) = ∫ f(t) dt vom Anker 0 (sonst 1, −1 oder Bildmitte) numerisch.
* Zweite Funktion  g(x) = …  (eigenes Termfeld) mit eigener Funktionsleiste  G | g | g′ | g″ | g‴,
  eigenen Tangenten (gestrichelt), eigenem Punkt Q, eigenen Stützpunkten und eigener Integralfläche.
  „Funktion f | Funktion g“ wählt, welche Funktion Grad, Koeffizienten und Punkt P bzw. Q bearbeiten.
* Wird ein Polynom eingegeben (z. B. (x-1)(x+2)^2), schaltet der Explorer automatisch in den
  Polynom-Modus (exakte Analyse, Koeffizienten, Stützpunkte). Sonst: numerische Analyse im
  sichtbaren Bereich.
* Knopfleiste  Obersumme | Untersumme | Trapezsumme | Mittensumme  mit Untergrenze a, Obergrenze b und
  Anzahl n der Teilintervalle (aus dem Polynom-Explorer): Rechtecke bzw. Trapeze der bearbeiteten Funktion;
  Maus über ein Rechteck/Trapez zeigt seinen Anteil an der Summe (absolut und in Prozent). Bei allgemeinen
  Funktionen werden größter und kleinster Wert je Teilintervall numerisch gesucht (Abtasten + Goldener Schnitt).

Schreibweise in der Termeingabe
-------------------------------
  2x^2 - 3x + 1      implizite Multiplikation, ^ oder ** für Potenzen
  0,5x  bzw. 0.5x    Dezimalkomma oder -punkt
  log(x; 2)          mehrere Argumente werden mit Semikolon getrennt
  π, √x, x², |x|, x! Sonderzeichen sind erlaubt (x! = Γ(x+1) für reelle x)
  ln, lg, arcsin, sgn …  gängige Schulschreibweisen als Alias

Verwendung als Unterprogramm
----------------------------
    from funktionen_explorer import Ausdruck, analysiere_funktion, FunktionenExplorer, starte

    f = Ausdruck("x·sin(x)")
    f(np.array([0.0, 1.0]))                    # Funktionswerte
    f.tex()                                    # Mathtext-Darstellung
    analysiere_funktion(f, -6, 6, a=0, b=3)    # Nullstellen, Extrema, Wendepunkte, Integral …
    f.ableitung().text                         # "sin(x) + x·cos(x)"  (symbolisch, vereinfacht)
    st = stammfunktion_numerisch(f, -6, 6)     # {"F": Funktion, "anker": 0.0}

    starte("2sin(x) + x/2")                    # interaktives Fenster
    ex = starte("ln(x)", term_g="x^2/2 - 2", kurven_g={"f": True, "d1": True}, block=False)
    ex.set_term("e^(-x^2)", "g"); ex.term_g     # zweite Funktion g
    ex.bearbeite("g")                          # Grad, Koeffizienten, Punkt Q gehören jetzt zu g
    ex.ableitung(1, "g").text                  # Ableitungsterm von g
    ex.zeige_summe("unter", n=10); ex.summe    # Untersumme U_10 der bearbeiteten Funktion
    starte("x·sin(x)", design="pearson")       # im Pearson-Schulbuchstil
"""

from __future__ import annotations

import math
import re
import sys
from typing import Callable

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, TextBox

import polynom_explorer as pe
from polynom_explorer import (DESIGN_NAMEN, FARBEN, FARBSCHEMATA, KURVEN, KURVEN_G, NAMEN, N_MAX, PolynomExplorer,
                              _dez, _zahl_text, _zahl_tex, _als_bruch)

__all__ = ["Ausdruck", "TermFehler", "analysiere_funktion", "tangenten_funktion", "tangente_in", "integral",
           "stammfunktion_numerisch", "stamm_analyse", "FUNKTIONSKATALOG", "FunktionenExplorer", "starte"]

STANDARD_TERM = "2sin(x) + x/2"
STANDARD_TERM_G = "x^2/2 - 2"


# ==========================================================================
# Funktionskatalog (identisch zur Browser-Version)
# ==========================================================================
# (Name, Vorlage zum Einfügen, Beschreibung, Herkunft)
FUNKTIONSKATALOG: list[tuple[str, list[tuple[str, str, str, str]]]] = [
    ("Potenzen & Wurzeln", [
        ("sqrt", "sqrt(x)", "Quadratwurzel √x", "math"),
        ("cbrt", "cbrt(x)", "Kubikwurzel ∛x, auch für negative x", "math"),
        ("exp", "exp(x)", "Exponentialfunktion eˣ", "math"),
        ("exp2", "exp2(x)", "Zweierpotenz 2ˣ", "math"),
        ("expm1", "expm1(x)", "eˣ − 1, genau für kleine x", "math"),
        ("pow", "pow(x; 2)", "Potenz xʸ", "math"),
        ("isqrt", "isqrt(x)", "ganzzahlige Wurzel ⌊√n⌋, nur ganze n ≥ 0", "math"),
    ]),
    ("Logarithmen", [
        ("log", "log(x)", "natürlicher Logarithmus ln x", "math"),
        ("log", "log(x; 2)", "Logarithmus zur Basis b", "math"),
        ("ln", "ln(x)", "Schreibweise für log(x)", "Alias"),
        ("log10", "log10(x)", "Zehnerlogarithmus lg x", "math"),
        ("lg", "lg(x)", "Schreibweise für log10(x)", "Alias"),
        ("log2", "log2(x)", "Zweierlogarithmus", "math"),
        ("log1p", "log1p(x)", "ln(1 + x), genau für kleine x", "math"),
    ]),
    ("Trigonometrie", [
        ("sin", "sin(x)", "Sinus (Bogenmaß)", "math"),
        ("cos", "cos(x)", "Kosinus (Bogenmaß)", "math"),
        ("tan", "tan(x)", "Tangens (Bogenmaß)", "math"),
        ("asin", "asin(x)", "Arkussinus, auch arcsin", "math"),
        ("acos", "acos(x)", "Arkuskosinus, auch arccos", "math"),
        ("atan", "atan(x)", "Arkustangens, auch arctan", "math"),
        ("atan2", "atan2(x; 1)", "Winkel des Punktes (x | y): atan2(y; x)", "math"),
        ("hypot", "hypot(x; 1)", "Abstand √(x² + y²)", "math"),
        ("degrees", "degrees(x)", "Bogenmaß → Grad", "math"),
        ("radians", "radians(x)", "Grad → Bogenmaß", "math"),
    ]),
    ("Hyperbelfunktionen", [
        ("sinh", "sinh(x)", "Sinus hyperbolicus", "math"),
        ("cosh", "cosh(x)", "Kosinus hyperbolicus", "math"),
        ("tanh", "tanh(x)", "Tangens hyperbolicus", "math"),
        ("asinh", "asinh(x)", "Areasinus hyperbolicus, auch arsinh", "math"),
        ("acosh", "acosh(x)", "Areakosinus hyperbolicus, auch arcosh", "math"),
        ("atanh", "atanh(x)", "Areatangens hyperbolicus, auch artanh", "math"),
    ]),
    ("Betrag & Runden", [
        ("abs", "abs(x)", "Betrag |x|", "builtins"),
        ("fabs", "fabs(x)", "Betrag |x| als Kommazahl", "math"),
        ("sign", "sign(x)", "Vorzeichenfunktion sgn(x), auch sgn", "numpy"),
        ("floor", "floor(x)", "Abrunden ⌊x⌋ (Gaußklammer)", "math"),
        ("ceil", "ceil(x)", "Aufrunden ⌈x⌉", "math"),
        ("trunc", "trunc(x)", "Nachkommastellen abschneiden", "math"),
        ("round", "round(x)", "Runden, bei ,5 zur geraden Zahl", "builtins"),
        ("round", "round(x; 1)", "Runden auf n Nachkommastellen", "builtins"),
        ("copysign", "copysign(x; -1)", "Betrag von x mit Vorzeichen von y", "math"),
        ("fmod", "fmod(x; 2)", "Divisionsrest, Vorzeichen wie x", "math"),
        ("remainder", "remainder(x; 2)", "Rest x − n·y, n nächste ganze Zahl", "math"),
        ("min", "min(x; 1)", "kleinster Wert", "builtins"),
        ("max", "max(x; 1)", "größter Wert", "builtins"),
        ("heaviside", "heaviside(x; 0,5)", "Sprungfunktion (Wert y an der Stelle 0)", "numpy"),
    ]),
    ("Kombinatorik & ganze Zahlen", [
        ("factorial", "factorial(x)", "Fakultät n!, nur ganze n ≥ 0 (für reelle x: x!)", "math"),
        ("comb", "comb(x; 2)", "Binomialkoeffizient (n über k)", "math"),
        ("perm", "perm(x; 2)", "Variationen n!/(n − k)!", "math"),
        ("gcd", "gcd(x; 12)", "größter gemeinsamer Teiler", "math"),
        ("lcm", "lcm(x; 4)", "kleinstes gemeinsames Vielfaches", "math"),
    ]),
    ("Spezielle Funktionen", [
        ("gamma", "gamma(x)", "Gammafunktion Γ(x)", "math"),
        ("lgamma", "lgamma(x)", "ln |Γ(x)|", "math"),
        ("erf", "erf(x)", "Gaußsche Fehlerfunktion", "math"),
        ("erfc", "erfc(x)", "komplementäre Fehlerfunktion 1 − erf(x)", "math"),
        ("sinc", "sinc(x)", "sin(πx)/(πx)", "numpy"),
        ("ldexp", "ldexp(x; 3)", "x · 2ⁿ", "math"),
        ("nextafter", "nextafter(x; 10)", "nächste Gleitkommazahl in Richtung y", "math"),
        ("ulp", "ulp(x)", "Abstand zur nächsten Gleitkommazahl", "math"),
    ]),
    ("Konstanten", [
        ("pi", "pi", "Kreiszahl π ≈ 3,14159", "math"),
        ("e", "e", "Eulersche Zahl ≈ 2,71828", "math"),
        ("tau", "tau", "τ = 2π", "math"),
        ("inf", "inf", "unendlich", "math"),
        ("nan", "nan", "keine Zahl (not a number)", "math"),
    ]),
]

ALIASE = {"ln": "log", "lg": "log10", "arcsin": "asin", "arccos": "acos", "arctan": "atan",
          "arsinh": "asinh", "arcosh": "acosh", "artanh": "atanh", "sgn": "sign", "wurzel": "sqrt"}

KONSTANTEN = {"pi": math.pi, "e": math.e, "tau": math.tau, "inf": math.inf, "nan": math.nan}


# ---- Implementierungen (vektorisiert, Fehler -> nan wie „nicht definiert“) -------------------
def _vekt(fn):
    def sicher(*a):
        try:
            v = fn(*a)
            return float(v)
        except (ValueError, OverflowError, ZeroDivisionError, TypeError):
            return math.nan
    return np.vectorize(sicher, otypes=[float])


def _ganz(v):
    """Python verlangt bei factorial, comb, … echte ganze Zahlen."""
    if not math.isfinite(v) or v != math.floor(v):
        raise ValueError
    return int(v)


def _round(x, n=None):
    if n is None:
        return np.round(x)                      # Python round(): bei ,5 zur geraden Zahl
    return _vekt(lambda a, k: round(a, _ganz(k)))(x, n)


FUNKTIONEN: dict[str, tuple[Callable, int, int]] = {
    # Name: (Implementierung, min. Argumente, max. Argumente)
    "sqrt": (np.sqrt, 1, 1), "cbrt": (np.cbrt, 1, 1), "exp": (np.exp, 1, 1),
    "exp2": (np.exp2, 1, 1), "expm1": (np.expm1, 1, 1), "pow": (np.power, 2, 2),
    "isqrt": (_vekt(lambda a: math.isqrt(_ganz(a))), 1, 1),
    "log": (lambda x, b=None: np.log(x) if b is None else np.log(x) / np.log(b), 1, 2),
    "log10": (np.log10, 1, 1), "log2": (np.log2, 1, 1), "log1p": (np.log1p, 1, 1),
    "sin": (np.sin, 1, 1), "cos": (np.cos, 1, 1), "tan": (np.tan, 1, 1),
    "asin": (np.arcsin, 1, 1), "acos": (np.arccos, 1, 1), "atan": (np.arctan, 1, 1),
    "atan2": (np.arctan2, 2, 2),
    "hypot": (lambda *a: np.sqrt(sum(np.square(v) for v in a)), 1, 9),
    "degrees": (np.degrees, 1, 1), "radians": (np.radians, 1, 1),
    "sinh": (np.sinh, 1, 1), "cosh": (np.cosh, 1, 1), "tanh": (np.tanh, 1, 1),
    "asinh": (np.arcsinh, 1, 1), "acosh": (np.arccosh, 1, 1), "atanh": (np.arctanh, 1, 1),
    "abs": (np.abs, 1, 1), "fabs": (np.abs, 1, 1), "sign": (np.sign, 1, 1),
    "floor": (np.floor, 1, 1), "ceil": (np.ceil, 1, 1), "trunc": (np.trunc, 1, 1),
    "round": (_round, 1, 2), "copysign": (np.copysign, 2, 2), "fmod": (np.fmod, 2, 2),
    "remainder": (_vekt(math.remainder), 2, 2),
    "min": (lambda *a: np.minimum.reduce(np.broadcast_arrays(*a)), 2, 9),
    "max": (lambda *a: np.maximum.reduce(np.broadcast_arrays(*a)), 2, 9),
    "heaviside": (np.heaviside, 2, 2),
    "factorial": (_vekt(lambda a: math.factorial(_ganz(a))), 1, 1),
    "comb": (_vekt(lambda n, k: math.comb(_ganz(n), _ganz(k))), 2, 2),
    "perm": (_vekt(lambda n, k=None: math.perm(_ganz(n), None if k is None else _ganz(k))), 1, 2),
    "gcd": (_vekt(lambda *a: math.gcd(*[_ganz(v) for v in a])), 1, 9),
    "lcm": (_vekt(lambda *a: math.lcm(*[_ganz(v) for v in a])), 1, 9),
    "gamma": (_vekt(math.gamma), 1, 1), "lgamma": (_vekt(math.lgamma), 1, 1),
    "erf": (_vekt(math.erf), 1, 1), "erfc": (_vekt(math.erfc), 1, 1),
    "sinc": (np.sinc, 1, 1),
    "ldexp": (_vekt(lambda a, k: math.ldexp(a, _ganz(k))), 2, 2),
    "nextafter": (np.nextafter, 2, 2), "ulp": (_vekt(math.ulp), 1, 1),
}
_GAMMA = _vekt(math.gamma)


# ==========================================================================
# Parser  ->  Syntaxbaum (Tupel)
#   ("zahl", wert, text) ("x",) ("konst", name) ("neg", a) ("bin", op, a, b, implizit)
#   ("fak", a) ("ruf", name, [args])
# ==========================================================================
class TermFehler(ValueError):
    pass


_TOKEN = re.compile(r"""
    (?P<ws>\s+)
  | (?P<zahl>(?:\d+(?:[.,]\d+)?|\.\d+)(?:[eE][+-]?\d+)?)
  | (?P<name>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>\*\*|[-+*/^()!;|·×÷:−πτ√²³∞])
""", re.X)
_OP_NORM = {"·": "*", "×": "*", "÷": "/", ":": "/", "−": "-", "**": "^"}
_SYMBOLNAMEN = {"π": "pi", "τ": "tau", "∞": "inf"}


def _tokens(text: str):
    out, pos = [], 0
    while pos < len(text):
        m = _TOKEN.match(text, pos)
        if not m and text[pos] == ",":
            raise TermFehler(f"Komma an Stelle {pos + 1}: Dezimalkomma nur zwischen Ziffern, "
                             "Argumente mit Semikolon trennen, z. B. log(x; 2)")
        if not m:
            raise TermFehler(f"Unbekanntes Zeichen „{text[pos]}“ an Stelle {pos + 1}")
        art = m.lastgroup
        wert = m.group()
        if art == "op" and wert in _SYMBOLNAMEN:
            art, wert = "name", _SYMBOLNAMEN[wert]
        elif art == "op":
            wert = _OP_NORM.get(wert, wert)
        if art != "ws":
            out.append((art, wert, pos))
        pos = m.end()
    out.append(("ende", "", len(text)))
    return out


class _Parser:
    def __init__(self, text):
        self.t = _tokens(text)
        self.i = 0
        self.betrag_tiefe = 0

    def sieh(self):
        return self.t[self.i]

    def nimm(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def ist(self, op):
        tok = self.sieh()
        return tok[0] == "op" and tok[1] == op

    def fehler(self, msg):
        raise TermFehler(f"{msg} (Stelle {self.sieh()[2] + 1})")

    def parse(self):
        if self.sieh()[0] == "ende":
            raise TermFehler("Der Term ist leer.")
        n = self.ausdruck()
        if self.sieh()[0] != "ende":
            self.fehler(f"Unerwartetes „{self.sieh()[1]}“")
        return n

    def ausdruck(self):
        n = self.term()
        while self.ist("+") or self.ist("-"):
            op = self.nimm()[1]
            n = ("bin", op, n, self.term(), False)
        return n

    def startet_faktor(self):
        art, wert, _ = self.sieh()
        if art in ("zahl", "name"):
            return True
        return art == "op" and (wert in ("(", "√") or (wert == "|" and self.betrag_tiefe == 0))

    def term(self):
        n = self.vorzeichen()
        while True:
            if self.ist("*") or self.ist("/"):
                op = self.nimm()[1]
                n = ("bin", op, n, self.vorzeichen(), False)
            elif self.startet_faktor():
                n = ("bin", "*", n, self.potenz(), True)
            else:
                return n

    def vorzeichen(self):
        if self.ist("-"):
            self.nimm()
            return ("neg", self.vorzeichen())
        if self.ist("+"):
            self.nimm()
            return self.vorzeichen()
        return self.potenz()

    def potenz(self):
        b = self.postfix()
        if self.ist("^"):
            self.nimm()
            return ("bin", "^", b, self.vorzeichen(), False)
        return b

    def postfix(self):
        n = self.primaer()
        while True:
            if self.ist("!"):
                self.nimm()
                n = ("fak", n)
            elif self.ist("²") or self.ist("³"):
                e = 2 if self.nimm()[1] == "²" else 3
                n = ("bin", "^", n, ("zahl", float(e), str(e)), False)
            else:
                return n

    def primaer(self):
        art, wert, pos = self.sieh()
        if art == "zahl":
            self.nimm()
            return ("zahl", float(wert.replace(",", ".")), wert)
        if art == "op" and wert == "(":
            self.nimm()
            n = self.ausdruck()
            if not self.ist(")"):
                self.fehler("Schließende Klammer „)“ fehlt")
            self.nimm()
            return n
        if art == "op" and wert == "|":
            self.nimm()
            self.betrag_tiefe += 1
            n = self.ausdruck()
            self.betrag_tiefe -= 1
            if not self.ist("|"):
                self.fehler("Schließender Betragsstrich „|“ fehlt")
            self.nimm()
            return ("ruf", "abs", [n])
        if art == "op" and wert == "√":
            self.nimm()
            return ("ruf", "sqrt", [self.postfix()])
        if art == "name":
            self.nimm()
            name = wert.lower()
            name = ALIASE.get(name, name)
            if name == "x":
                return ("x",)
            if name in KONSTANTEN:
                return ("konst", name)
            if name in FUNKTIONEN:
                if not self.ist("("):
                    self.fehler(f"Nach „{wert}“ wird eine Klammer erwartet, z. B. {wert}(x)")
                self.nimm()
                args = [self.ausdruck()]
                while self.ist(";"):
                    self.nimm()
                    args.append(self.ausdruck())
                if not self.ist(")"):
                    self.fehler(f"„)“ nach den Argumenten von {wert} fehlt (Argumente mit ; trennen)")
                self.nimm()
                _, mi, ma = FUNKTIONEN[name]
                if not (mi <= len(args) <= ma):
                    soll = str(mi) if mi == ma else f"{mi} bis {ma}"
                    raise TermFehler(f"{wert} erwartet {soll} Argument(e), nicht {len(args)}")
                return ("ruf", name, args)
            raise TermFehler(f"Unbekannter Name „{wert}“ an Stelle {pos + 1}"
                             + (" – für Produkte ein Malzeichen oder Leerzeichen setzen, z. B. x·2"
                                if len(wert) > 1 else ""))
        if art == "ende":
            self.fehler("Term endet unerwartet")
        self.fehler(f"Unerwartetes „{wert}“")


# ---- Auswertung --------------------------------------------------------------------------
def _ev(n, x):
    t = n[0]
    if t == "zahl":
        return n[1]
    if t == "x":
        return x
    if t == "konst":
        return KONSTANTEN[n[1]]
    if t == "neg":
        return -_ev(n[1], x)
    if t == "bin":
        a, b = _ev(n[2], x), _ev(n[3], x)
        op = n[1]
        if op == "+":
            return a + b
        if op == "-":
            return a - b
        if op == "*":
            return a * b
        if op == "/":
            return np.divide(a, b)
        return np.power(np.asarray(a, dtype=float), b)
    if t == "fak":
        a = _ev(n[1], x)
        if np.ndim(a) == 0 and math.isfinite(a) and a >= 0 and a == math.floor(a) and a <= 170:
            return float(math.factorial(int(a)))
        return _GAMMA(np.asarray(a, dtype=float) + 1.0)          # x! = Γ(x + 1)
    if t == "ruf":
        fn = FUNKTIONEN[n[1]][0]
        return fn(*[_ev(a, x) for a in n[2]])
    if t == "abl":                                               # numerische Ableitung (ohne Ableitungsregel)
        xa = np.asarray(x, dtype=float)
        h = 1e-3 * (1 + np.abs(xa))
        g = lambda u: np.asarray(_ev(n[1], u), dtype=float)
        return (-g(xa + 2 * h) + 8 * g(xa + h) - 8 * g(xa - h) + g(xa - 2 * h)) / (12 * h)
    raise TermFehler("interner Fehler")


def _enthaelt_x(n) -> bool:
    if n[0] == "x":
        return True
    if n[0] in ("zahl", "konst"):
        return False
    if n[0] == "ruf":
        return any(_enthaelt_x(a) for a in n[2])
    return any(_enthaelt_x(k) for k in n[1:] if isinstance(k, tuple))


def _konstwert(n) -> float:
    with np.errstate(all="ignore"):
        return float(np.asarray(_ev(n, np.array([0.0])), dtype=float).ravel()[0])


# ---- Polynom erkennen ----------------------------------------------------------------------
def _als_polynom(n):
    """Koeffizienten (aufsteigend), falls der Baum ein Polynom vom Grad ≤ N_MAX ist, sonst None."""
    t = n[0]
    if not _enthaelt_x(n):
        v = _konstwert(n)
        return np.array([v]) if math.isfinite(v) else None
    if t == "x":
        return np.array([0.0, 1.0])
    if t == "neg":
        p = _als_polynom(n[1])
        return None if p is None else -p
    if t == "bin":
        op = n[1]
        if op in "+-*":
            p, q = _als_polynom(n[2]), _als_polynom(n[3])
            if p is None or q is None:
                return None
            if op == "*":
                if len(p) + len(q) - 2 > N_MAX:
                    return None
                return np.convolve(p, q)
            m = max(len(p), len(q))
            p, q = np.pad(p, (0, m - len(p))), np.pad(q, (0, m - len(q)))
            return p + q if op == "+" else p - q
        if op == "/":
            if _enthaelt_x(n[3]):
                return None
            d, p = _konstwert(n[3]), _als_polynom(n[2])
            return None if p is None or d == 0 or not math.isfinite(d) else p / d
        if op == "^":
            if _enthaelt_x(n[3]):
                return None
            e, p = _konstwert(n[3]), _als_polynom(n[2])
            if p is None or not (e >= 0 and e == math.floor(e)) or (len(p) - 1) * e > N_MAX:
                return None
            r = np.array([1.0])
            for _ in range(int(e)):
                r = np.convolve(r, p)
            return r
    return None


# ---- Darstellung ------------------------------------------------------------------------------
_TEX_FN = {"sin": r"\sin", "cos": r"\cos", "tan": r"\tan", "asin": r"\arcsin", "acos": r"\arccos",
           "atan": r"\arctan", "sinh": r"\sinh", "cosh": r"\cosh", "tanh": r"\tanh", "exp": r"\exp",
           "asinh": r"\mathrm{arsinh}", "acosh": r"\mathrm{arcosh}", "atanh": r"\mathrm{artanh}",
           "sign": r"\mathrm{sgn}", "gamma": r"\Gamma"}
_TEX_KONST = {"pi": r"\pi", "e": "e", "tau": r"\tau", "inf": r"\infty", "nan": r"\mathrm{nan}"}
_TXT_KONST = {"pi": "π", "e": "e", "tau": "τ", "inf": "inf", "nan": "nan"}
# Rang: 1 Summe, 2 Produkt/Vorzeichen, 4 Potenz, 5 Fakultät, 6 Atom
_RANG = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 4}


def _rang(n) -> int:
    t = n[0]
    if t == "bin":
        return _RANG[n[1]]
    if t == "neg":
        return 2
    if t == "fak":
        return 5
    if t == "zahl" and n[1] < 0:
        return 2
    return 6


def _zahlig(n) -> bool:
    """Zahl, Konstante oder Bruch aus Zahlen – darf ohne Malpunkt vor einem Faktor stehen."""
    t = n[0]
    if t in ("zahl", "konst"):
        return True
    if t == "bin" and n[1] == "/":
        return _zahlig(n[2]) and _zahlig(n[3])
    if t == "fak":
        return n[1][0] == "zahl"
    return False


def _beginnt_mit_zahl(n) -> bool:
    t = n[0]
    if t == "zahl":
        return True
    if t == "bin":
        return _beginnt_mit_zahl(n[2]) and n[1] != "/"
    if t == "fak":
        return _beginnt_mit_zahl(n[1])
    return False


def _tex(n) -> str:
    t = n[0]
    if t == "zahl":
        return n[2].replace(",", ".").replace(".", "{,}") if "e" not in n[2].lower() else _zahl_tex(n[1])
    if t == "x":
        return "x"
    if t == "konst":
        return _TEX_KONST[n[1]]
    if t == "neg":
        a = n[1]
        return "-" + (rf"\left({_tex(a)}\right)" if _rang(a) <= 1 else _tex(a))
    if t == "fak":
        a = n[1]
        inner = _tex(a)
        return (rf"\left({inner}\right)" if _rang(a) < 6 or (a[0] == "bin" and a[1] == "/") else inner) + "!"
    if t == "bin":
        op, a, b = n[1], n[2], n[3]
        if op in "+-":
            rb = _tex(b)
            if b[0] == "neg" or (op == "-" and _rang(b) <= 1):
                rb = rf"\left({rb}\right)"
            return f"{_tex(a)} {op} {rb}"
        if op == "*":
            la = _tex(a) if _rang(a) >= 2 else rf"\left({_tex(a)}\right)"
            rb = _tex(b) if _rang(b) > 2 or (b[0] == "bin" and b[1] in "*/") else rf"\left({_tex(b)}\right)"
            if _zahlig(a) and not _beginnt_mit_zahl(b) and _rang(b) > 2:
                return la + rb
            return la + r" \cdot " + rb
        if op == "/":
            return rf"\frac{{{_tex(a)}}}{{{_tex(b)}}}"
        basis = _tex(a)
        if _rang(a) < 6 or (a[0] == "bin" and a[1] == "/") or a[0] == "ruf" and a[1] not in ("abs", "fabs"):
            basis = rf"\left({basis}\right)"
        return f"{basis}^{{{_tex(b)}}}"
    if t == "ruf":
        name, args = n[1], n[2]
        a = [_tex(v) for v in args]
        if name == "sqrt":
            return rf"\sqrt{{{a[0]}}}"
        if name == "cbrt":
            return rf"\sqrt[3]{{{a[0]}}}"
        if name in ("abs", "fabs"):
            return rf"\left|{a[0]}\right|"
        if name == "floor":
            return rf"\lfloor {a[0]} \rfloor"
        if name == "ceil":
            return rf"\lceil {a[0]} \rceil"
        if name == "log":
            return rf"\ln\left({a[0]}\right)" if len(a) == 1 else rf"\log_{{{a[1]}}}\left({a[0]}\right)"
        if name == "log10":
            return rf"\log_{{10}}\left({a[0]}\right)"
        if name == "log2":
            return rf"\log_{{2}}\left({a[0]}\right)"
        if name == "factorial":
            inner = a[0]
            return (inner if _rang(args[0]) == 6 else rf"\left({inner}\right)") + "!"
        kopf = _TEX_FN.get(name, rf"\mathrm{{{name}}}")
        return kopf + r"\left(" + r";\, ".join(a) + r"\right)"
    if t == "abl":
        return rf"\left({_tex(n[1])}\right)'"
    return "?"


def _txt(n) -> str:
    """Wieder einlesbarer Text (für das Verschieben allgemeiner Funktionen)."""
    t = n[0]
    if t == "zahl":
        return n[2]
    if t == "x":
        return "x"
    if t == "konst":
        return _TXT_KONST[n[1]]
    if t == "neg":
        a = n[1]
        return "-" + (f"({_txt(a)})" if _rang(a) <= 1 else _txt(a))
    if t == "fak":
        a = n[1]
        return (f"({_txt(a)})" if _rang(a) < 6 else _txt(a)) + "!"
    if t == "bin":
        op, a, b = n[1], n[2], n[3]
        la, rb = _txt(a), _txt(b)
        if op in "+-":
            if b[0] == "neg" or (op == "-" and _rang(b) <= 1) or (b[0] == "zahl" and b[1] < 0):
                rb = f"({rb})"
            return f"{la} {op} {rb}"
        if op in "*/":
            if _rang(a) < 2:
                la = f"({la})"
            if _rang(b) <= 2:
                rb = f"({rb})"
            if op == "*" and la[-1:].isdigit() and (rb[:1].isalpha() or rb[:1] in "(√π|"):
                return la + rb
            return f"{la}{'·' if op == '*' else '/'}{rb}"
        if _rang(a) < 6:
            la = f"({la})"
        if _rang(b) < 6:
            rb = f"({rb})"
        return f"{la}^{rb}"
    if t == "ruf":
        return f"{n[1]}(" + "; ".join(_txt(a) for a in n[2]) + ")"
    if t == "abl":
        return f"({_txt(n[1])})'"
    return "?"


# ==========================================================================
# Symbolisches Ableiten und Vereinfachen (identisch zur Browser-Version)
# ==========================================================================
def _zahl_wert(n):
    """Wert eines reinen Zahlterms (ohne x und Konstanten) oder None."""
    t = n[0]
    if t == "zahl":
        return n[1]
    if t == "neg":
        v = _zahl_wert(n[1])
        return None if v is None else -v
    if t == "bin" and n[1] == "/" and n[2][0] == "zahl" and n[3][0] == "zahl" and n[3][1] != 0:
        return n[2][1] / n[3][1]
    return None


def _bruch(v):
    return _als_bruch(v) if math.isfinite(v) else None


def _num(v):
    v = float(v)
    if not math.isfinite(v):
        return ("konst", "nan")
    if v < 0:
        return ("neg", _num(-v))
    b = _bruch(v)
    if b is not None and b.denominator != 1:
        return ("bin", "/", ("zahl", float(b.numerator), str(b.numerator)),
                ("zahl", float(b.denominator), str(b.denominator)), False)
    if b is not None:
        return ("zahl", float(b.numerator), str(b.numerator))
    return ("zahl", v, _dez(v, 4))


def _R(name, *args):
    return ("ruf", name, list(args))


def _KO(name):
    return ("konst", name)


def _neg(a):
    v = _zahl_wert(a)
    if v is not None:
        return _num(-v)
    return a[1] if a[0] == "neg" else ("neg", a)


def _add(a, b):
    va, vb = _zahl_wert(a), _zahl_wert(b)
    if va is not None and vb is not None:
        return _num(va + vb)
    if va == 0:
        return b
    if vb == 0:
        return a
    if b[0] == "neg":
        return _sub(a, b[1])
    return ("bin", "+", a, b, False)


def _sub(a, b):
    va, vb = _zahl_wert(a), _zahl_wert(b)
    if va is not None and vb is not None:
        return _num(va - vb)
    if vb == 0:
        return a
    if va == 0:
        return _neg(b)
    if b[0] == "neg":
        return _add(a, b[1])
    return ("bin", "-", a, b, False)


def _mul(a, b):
    va, vb = _zahl_wert(a), _zahl_wert(b)
    if va is not None and vb is not None:
        return _num(va * vb)
    if va == 0 or vb == 0:
        return _num(0)
    if va == 1:
        return b
    if vb == 1:
        return a
    if a[0] == "neg":
        return _neg(_mul(a[1], b))
    if b[0] == "neg":
        return _neg(_mul(a, b[1]))
    if vb is not None:
        return _mul(b, a)                                   # Zahlen nach vorn
    if va is not None and b[0] == "bin" and b[1] == "*" and _zahl_wert(b[2]) is not None:
        return _mul(_num(va * _zahl_wert(b[2])), b[3])
    return ("bin", "*", a, b, False)


def _div(a, b):
    va, vb = _zahl_wert(a), _zahl_wert(b)
    if va is not None and vb is not None and vb != 0:
        return _num(va / vb)
    if va == 0:
        return _num(0)
    if vb == 1:
        return a
    if a[0] == "neg":
        return _neg(_div(a[1], b))
    if b[0] == "neg":
        return _neg(_div(a, b[1]))
    return ("bin", "/", a, b, False)


def _hoch(va, vb):
    """va ** vb wie in JavaScript (nan statt Fehler bzw. komplexer Zahl)."""
    try:
        w = va ** vb
    except ZeroDivisionError:
        return math.inf
    except OverflowError:
        return math.inf
    return math.nan if isinstance(w, complex) else float(w)


def _pot(a, b):
    va, vb = _zahl_wert(a), _zahl_wert(b)
    if vb == 0:
        return _num(1)
    if vb == 1:
        return a
    if va is not None and vb is not None and _bruch(_hoch(va, vb)) is not None:
        return _num(_hoch(va, vb))
    return ("bin", "^", a, b, False)


def _ableite(n):
    """Ableitung des Syntaxbaums nach x (Regeln für alle Funktionen des Katalogs; Γ, ln|Γ|, x!, min, max numerisch)."""
    t = n[0]
    if t in ("zahl", "konst"):
        return _num(0)
    if t == "x":
        return _num(1)
    if t == "neg":
        return _neg(_ableite(n[1]))
    if t in ("fak", "abl"):
        return ("abl", n) if _enthaelt_x(n) else _num(0)
    if t == "bin":
        op, a, b = n[1], n[2], n[3]
        xa, xb = _enthaelt_x(a), _enthaelt_x(b)
        if not xa and not xb:
            return _num(0)
        da = _ableite(a) if xa else _num(0)
        db = _ableite(b) if xb else _num(0)
        if op == "+":
            return _add(da, db)
        if op == "-":
            return _sub(da, db)
        if op == "*":
            return _mul(a, db) if not xa else _mul(b, da) if not xb else _add(_mul(da, b), _mul(a, db))
        if op == "/":
            if not xb:
                return _div(da, b)
            if not xa:
                return _neg(_div(_mul(a, db), _pot(b, _num(2))))
            return _div(_sub(_mul(da, b), _mul(a, db)), _pot(b, _num(2)))
        # Potenz
        if not xb:
            vb = _zahl_wert(b)
            return _mul(_mul(b, _pot(a, _num(vb - 1) if vb is not None else _sub(b, _num(1)))), da)
        if not xa:
            return _mul(n if a == ("konst", "e") else _mul(n, _R("log", a)), db)
        return _mul(n, _add(_mul(db, _R("log", a)), _div(_mul(b, da), a)))
    if t == "ruf":
        return _ableite_ruf(n)
    return ("abl", n)


def _ableite_ruf(n):
    name, args = n[1], n[2]
    u = args[0]
    if not any(_enthaelt_x(a) for a in args):
        return _num(0)
    du = lambda: _ableite(u)
    kette = lambda g: _mul(g, du())
    qu = lambda v: _pot(v, _num(2))
    if name == "sqrt":
        return _div(du(), _mul(_num(2), n))
    if name == "cbrt":
        return _div(du(), _mul(_num(3), qu(n)))
    if name == "exp":
        return kette(n)
    if name == "exp2":
        return kette(_mul(n, _R("log", _num(2))))
    if name == "expm1":
        return kette(_R("exp", u))
    if name == "pow":
        return _ableite(("bin", "^", u, args[1], False))
    if name == "log":
        if len(args) == 1:
            return _div(du(), u)
        if not _enthaelt_x(args[1]):
            return _div(du(), _mul(u, _R("log", args[1])))
        return _ableite(("bin", "/", _R("log", u), _R("log", args[1]), False))
    if name == "log10":
        return _div(du(), _mul(u, _R("log", _num(10))))
    if name == "log2":
        return _div(du(), _mul(u, _R("log", _num(2))))
    if name == "log1p":
        return _div(du(), _add(_num(1), u))
    if name == "sin":
        return kette(_R("cos", u))
    if name == "cos":
        return _neg(kette(_R("sin", u)))
    if name == "tan":
        return _div(du(), qu(_R("cos", u)))
    if name == "asin":
        return _div(du(), _R("sqrt", _sub(_num(1), qu(u))))
    if name == "acos":
        return _neg(_div(du(), _R("sqrt", _sub(_num(1), qu(u)))))
    if name == "atan":
        return _div(du(), _add(_num(1), qu(u)))
    if name == "atan2":
        y, x = args
        return _div(_sub(_mul(x, _ableite(y)), _mul(y, _ableite(x))), _add(qu(x), qu(y)))
    if name == "hypot":
        summe = _mul(args[0], _ableite(args[0]))
        for a in args[1:]:
            summe = _add(summe, _mul(a, _ableite(a)))
        return _div(summe, n)
    if name == "degrees":
        return _div(_mul(_num(180), du()), _KO("pi"))
    if name == "radians":
        return _div(_mul(_KO("pi"), du()), _num(180))
    if name == "sinh":
        return kette(_R("cosh", u))
    if name == "cosh":
        return kette(_R("sinh", u))
    if name == "tanh":
        return _div(du(), qu(_R("cosh", u)))
    if name == "asinh":
        return _div(du(), _R("sqrt", _add(qu(u), _num(1))))
    if name == "acosh":
        return _div(du(), _R("sqrt", _sub(qu(u), _num(1))))
    if name == "atanh":
        return _div(du(), _sub(_num(1), qu(u)))
    if name in ("abs", "fabs"):
        return kette(_R("sign", u))
    if name in ("sign", "floor", "ceil", "trunc", "round", "heaviside", "ulp"):
        return _num(0)
    if name in ("isqrt", "factorial", "comb", "perm", "gcd", "lcm"):
        return _KO("nan")                                   # nur für ganze Zahlen definiert
    if name == "copysign":
        return kette(_mul(_R("sign", u), _R("copysign", _num(1), args[1])))
    if name == "fmod":
        return _sub(du(), _mul(_R("trunc", _div(u, args[1])), _ableite(args[1])))
    if name == "remainder":
        return _sub(du(), _mul(_R("round", _div(u, args[1])), _ableite(args[1])))
    if name == "erf":
        return kette(_mul(_div(_num(2), _R("sqrt", _KO("pi"))), _R("exp", _neg(qu(u)))))
    if name == "erfc":
        return _neg(kette(_mul(_div(_num(2), _R("sqrt", _KO("pi"))), _R("exp", _neg(qu(u))))))
    if name == "sinc":
        return kette(_div(_sub(_R("cos", _mul(_KO("pi"), u)), n), u))
    if name == "ldexp":
        return _R("ldexp", du(), args[1])
    if name == "nextafter":
        return du()
    return ("abl", n)                                       # gamma, lgamma, min, max


# ---- Vereinfachen: Normalform „Summe von Produkten“ ------------------------------------------
# Liste von Termen {"c": Zahl, "f": {Schlüssel: (Basis, Exponent)}}. Gleichartige Terme werden zusammengefasst,
# Potenzen gleicher Basis addiert; eine Summe als Faktor bleibt ein Faktor, nur auf Nenner wird verteilt.
def _rund(e):
    b = _bruch(e)
    return float(b) if b is not None else e


def _nf_zahl(v):
    return [{"c": float(v), "f": {}}]


def _nf_atom(b, e=1.0):
    return [{"c": 1.0, "f": {_txt(b): (b, float(e))}}]


def _nf_summe(terme):
    out = {}
    for t in terme:
        f = {k: v for k, v in t["f"].items() if v[1] != 0}
        sig = "·".join(sorted(f"{k}^{v[1]!r}" for k, v in f.items()))
        if sig in out:
            out[sig]["c"] += t["c"]
            out[sig]["m"] = max(out[sig]["m"], abs(t["c"]))
        else:
            out[sig] = {"c": t["c"], "f": f, "m": abs(t["c"])}
    return [{"c": _rund(t["c"]), "f": t["f"]} for t in out.values() if not (abs(t["c"]) <= 1e-12 * t["m"])]


def _verteilbar(A):
    return len(A) == 1 and len(A[0]["f"]) > 0 and all(v[1] < 0 for v in A[0]["f"].values())


def _nf_mul(A, B):
    if not A or not B:
        return []
    if len(A) > 1 and not _verteilbar(B):
        A = _nf_atom(_baue(A))
    if len(B) > 1 and not _verteilbar(A):
        B = _nf_atom(_baue(B))
    out = []
    for a in A:
        for b in B:
            f = dict(a["f"])
            for k, (basis, e) in b["f"].items():
                f[k] = (f[k][0], _rund(f[k][1] + e)) if k in f else (basis, e)
            out.append({"c": a["c"] * b["c"], "f": f})
    return _nf_summe(out)


def _nf_pot(A, e):
    if e == 0:
        return _nf_zahl(1)
    if not A:
        return [] if e > 0 else _nf_zahl(math.nan)
    ganz = e == round(e)
    if len(A) == 1:
        t = A[0]
        ok = (ganz or t["c"] > 0) and (ganz or all(not (v[1] == round(v[1]) and v[1] % 2 == 0) for v in t["f"].values()))
        if ok:
            return [{"c": _rund(_hoch(t["c"], e)), "f": {k: (v[0], _rund(v[1] * e)) for k, v in t["f"].items()}}]
    return _nf_atom(_baue(A), e)


def _nf(n):
    t = n[0]
    if t == "zahl":
        return _nf_zahl(n[1])
    if t in ("x", "konst"):
        return _nf_atom(n)
    if t == "neg":
        return [{"c": -u["c"], "f": u["f"]} for u in _nf(n[1])]
    if t == "bin":
        op = n[1]
        if op == "+":
            return _nf_summe(_nf(n[2]) + _nf(n[3]))
        if op == "-":
            return _nf_summe(_nf(n[2]) + [{"c": -u["c"], "f": u["f"]} for u in _nf(n[3])])
        if op == "*":
            return _nf_mul(_nf(n[2]), _nf(n[3]))
        if op == "/":
            return _nf_mul(_nf(n[2]), _nf_pot(_nf(n[3]), -1))
        E = _nf(n[3])
        if not E:
            return _nf_zahl(1)
        if len(E) == 1 and not E[0]["f"]:
            return _nf_pot(_nf(n[2]), E[0]["c"])
        return _nf_atom(("bin", "^", _baue(_nf(n[2])), _baue(E), False))
    if t == "ruf":
        if n[1] == "sqrt":
            return _nf_pot(_nf(n[2][0]), 0.5)
        return _nf_atom(("ruf", n[1], [_vereinfache(a) for a in n[2]]))
    if t == "fak":
        return _nf_atom(("fak", _vereinfache(n[1])))
    return _nf_atom(n)


def _mul_roh(a, b):
    return ("bin", "*", a, b, False)


def _baue_faktor(b, e):
    if e == 1:
        return b
    if e == 0.5:
        return _R("sqrt", b)
    return _pot(b, _num(e))


def _produkt(zahl, faktoren):
    """Produkt links geklammert, Zahl vorn:  ((2·x)·e^…)  ->  „2x·e^…“"""
    p = None if zahl == 1 else _num(zahl)
    for b, e in faktoren:
        p = _mul_roh(p, _baue_faktor(b, e)) if p is not None else _baue_faktor(b, e)
    return p


def _baue_term(t):
    rang = lambda v: 0 if v[0][0] == "konst" else 1 if v[0][0] == "x" else 2      # π, e vor x vor allem anderen
    fs = sorted(t["f"].values(), key=rang)                                         # stabil: sonst Reihenfolge des Auftretens
    c = abs(t["c"])
    br = _bruch(c)
    p, q = (br.numerator, br.denominator) if br is not None else (c, 1)
    zaehler = _produkt(p, [v for v in fs if v[1] > 0]) or _num(1)
    nenner = _produkt(q, [(b, -e) for b, e in fs if e < 0])
    knoten = ("bin", "/", zaehler, nenner, False) if nenner is not None else zaehler
    return t["c"] < 0, knoten


def _baue(A):
    if not A:
        return _num(0)
    terme = [_baue_term(t) for t in [t for t in A if t["f"]] + [t for t in A if not t["f"]]]   # Zahlterm zuletzt
    minus, n = terme[0]
    n = ("neg", n) if minus else n
    for minus, k in terme[1:]:
        n = ("bin", "-" if minus else "+", n, k, False)
    return n


def _vereinfache(n):
    try:
        return _baue(_nf(n))
    except Exception:
        return n


def _zahlknoten(v: float):
    text = _zahl_text(v)
    if "/" in text or "!" in text:          # Bruch -> als Teilbaum einlesen
        return _Parser(text).parse()
    if v < 0:
        return ("neg", ("zahl", -v, _zahl_text(-v)))
    return ("zahl", v, text)


def _ersetze_x(n, neu):
    t = n[0]
    if t == "x":
        return neu
    if t in ("zahl", "konst"):
        return n
    if t == "neg":
        return ("neg", _ersetze_x(n[1], neu))
    if t in ("fak", "abl"):
        return (t, _ersetze_x(n[1], neu))
    if t == "bin":
        return ("bin", n[1], _ersetze_x(n[2], neu), _ersetze_x(n[3], neu), n[4])
    if t == "ruf":
        return ("ruf", n[1], [_ersetze_x(a, neu) for a in n[2]])
    return n


def _verschiebe_baum(baum, dx: float, dy: float):
    """g(x) = f(x − dx) + dy  als neuer Syntaxbaum."""
    dx, dy = round(dx, 3) + 0.0, round(dy, 3) + 0.0
    n = baum
    if dx != 0:
        innen = ("bin", "-" if dx > 0 else "+", ("x",), _zahlknoten(abs(dx)), False)
        n = _ersetze_x(n, innen)
    if dy != 0:
        # Konstanten am Ende zusammenfassen:  … + c  ->  … + (c + dy)
        if n[0] == "bin" and n[1] in "+-" and not _enthaelt_x(n[3]):
            c = _konstwert(n[3]) * (1 if n[1] == "+" else -1) + dy
            n = n[2] if abs(c) < 5e-13 else ("bin", "+" if c > 0 else "-", n[2], _zahlknoten(abs(c)), False)
        else:
            n = ("bin", "+" if dy > 0 else "-", n, _zahlknoten(abs(dy)), False)
    return n


class Ausdruck:
    """Ein eingelesener Funktionsterm f(x). Aufrufbar mit Zahlen oder numpy-Arrays."""

    def __init__(self, text_oder_baum):
        if isinstance(text_oder_baum, tuple):
            self.baum = text_oder_baum
            self.text = _txt(self.baum)
        else:
            self.text = str(text_oder_baum).strip()
            self.baum = _Parser(self.text).parse()

    def __call__(self, x):
        x = np.asarray(x, dtype=float)
        with np.errstate(all="ignore"):
            y = np.asarray(_ev(self.baum, x), dtype=float)
        return np.broadcast_to(y, x.shape).astype(float) if x.ndim else float(y.ravel()[0])

    def tex(self) -> str:
        return _tex(self.baum)

    def tex_zeilen(self, max_zeichen: int = 60, name: str = "f") -> list[str]:
        """Mathtext-Zeilen; lange Summen werden an Plus/Minus umbrochen."""
        teile = []
        n = self.baum
        while n[0] == "bin" and n[1] in "+-":
            teile.append((n[1], n[3]))
            n = n[2]
        teile.append(("", n))
        teile.reverse()
        zeilen, akt, laenge = [], "", 0
        for op, k in teile:
            s = _tex(k)
            if op and (k[0] == "neg" or (op == "-" and _rang(k) <= 1)):
                s = rf"\left({s}\right)"
            stueck = (f" {op} " if op else "") + s
            l = len(_txt(k)) + 3
            if akt and laenge + l > max_zeichen:
                zeilen.append(akt)
                akt, laenge = stueck, l
            else:
                akt, laenge = akt + stueck, laenge + l
        zeilen.append(akt)
        out = [rf"${name}(x) = {zeilen[0]}$"]
        out += [rf"$\qquad\quad {z}$" for z in zeilen[1:]]
        return out

    def als_polynom(self):
        p = _als_polynom(self.baum)
        if p is None:
            return None
        p = np.where(np.abs(p) < 1e-300, 0.0, p)
        while len(p) > 1 and p[-1] == 0:
            p = p[:-1]
        return p

    def verschoben(self, dx: float, dy: float) -> "Ausdruck":
        return Ausdruck(_verschiebe_baum(self.baum, dx, dy))

    def ableitung(self) -> "Ausdruck":
        """f′ als neuer, vereinfachter Ausdruck (symbolisch)."""
        return Ausdruck(_vereinfache(_ableite(self.baum)))


def wert(text: str) -> float:
    """Zahl oder konstanter Ausdruck (z. B. „1/7!“, „sqrt(2)“, „π/4“)."""
    a = Ausdruck(text)
    if _enthaelt_x(a.baum):
        raise TermFehler("Hier ist eine Zahl ohne x gefragt.")
    v = _konstwert(a.baum)
    if not math.isfinite(v):
        raise TermFehler("Der Ausdruck hat keinen endlichen Wert.")
    return v


def polynom_text(c) -> str:
    """Koeffizienten (aufsteigend) als einlesbarer Term, z. B. „4/5·x^3 - 16/5·x“."""
    teile = []
    for i in range(len(c) - 1, -1, -1):
        a = float(c[i])
        if a == 0:
            continue
        z = _zahl_text(abs(a))
        pot = "" if i == 0 else ("x" if i == 1 else f"x^{i}")
        if i == 0:
            s = z
        elif z == "1":
            s = pot
        else:
            s = f"{z}·{pot}"
        teile.append(("-" if a < 0 else "+", s))
    if not teile:
        return "0"
    out = ("-" if teile[0][0] == "-" else "") + teile[0][1]
    for vz, s in teile[1:]:
        out += f" {vz} {s}"
    return out


# ==========================================================================
# Numerische Analyse (für Nicht-Polynome; identischer Algorithmus in der Browser-Version)
# ==========================================================================
def _abl1(f, x, h):
    return (-f(x + 2 * h) + 8 * f(x + h) - 8 * f(x - h) + f(x - 2 * h)) / (12 * h)


def _abl2(f, x, h):
    return (-f(x + 2 * h) + 16 * f(x + h) - 30 * f(x) + 16 * f(x - h) - f(x - 2 * h)) / (12 * h * h)


def _nullstellen_von(g, xs, gs, schritte: int = 80, rauschen=0.0) -> np.ndarray:
    """Vorzeichenwechsel von g auf dem Gitter xs, verfeinert per (vektorisierter) Bisektion.
    Pole/Sprünge werden verworfen: |g| muss an der Stelle deutlich kleiner sein als an den Rändern."""
    ok = np.isfinite(gs)
    rauschen = np.broadcast_to(np.asarray(rauschen, dtype=float), gs.shape)
    deutlich = np.maximum(np.abs(gs[:-1]), np.abs(gs[1:])) > np.maximum(rauschen[:-1], rauschen[1:])
    i = np.where(ok[:-1] & ok[1:] & (gs[:-1] * gs[1:] < 0) & deutlich)[0]
    gefunden = []
    if i.size:
        lo, hi, glo = xs[i].copy(), xs[i + 1].copy(), gs[i].copy()
        rand = np.minimum(np.abs(gs[i]), np.abs(gs[i + 1]))
        for _ in range(schritte):
            mid = (lo + hi) / 2
            gm = g(mid)
            links = np.sign(gm) == np.sign(glo)
            lo = np.where(links, mid, lo)
            glo = np.where(links, gm, glo)
            hi = np.where(links, hi, mid)
        xr = (lo + hi) / 2
        gr = g(xr)
        ok_r = np.isfinite(gr) & ((np.abs(gr) <= 1e-3 * rand) | (np.abs(gr) < 1e-12))
        gefunden += list(xr[ok_r])
    # exakte Nullen auf dem Gitter (z. B. sign(0) = 0)
    j = np.where((gs[1:-1] == 0) & ok[:-2] & ok[2:] & (gs[:-2] * gs[2:] < 0)
                 & (np.maximum(np.abs(gs[:-2]), np.abs(gs[2:])) > np.maximum(rauschen[:-2], rauschen[2:])))[0] + 1
    gefunden += list(xs[j])
    if not gefunden:
        return np.array([])
    gefunden = np.sort(np.array(gefunden, dtype=float))
    schritt = xs[1] - xs[0]
    res = [gefunden[0]]
    for v in gefunden[1:]:
        if v - res[-1] > 0.5 * schritt:
            res.append(v)
    return np.array(res)


def integral(f, a: float, b: float, tol: float | None = None):
    """Adaptives Simpson-Verfahren (stufenweise, vektorisiert). None, falls f im Intervall
    nicht überall definiert ist."""
    a, b = float(a), float(b)
    if a == b:
        return 0.0
    vz = 1.0
    if a > b:
        a, b, vz = b, a, -1.0
    n0 = 32
    l = a + (b - a) * np.arange(n0) / n0
    r = l + (b - a) / n0
    m = (l + r) / 2
    fl, fm, fr = f(l), f(m), f(r)
    if not (np.all(np.isfinite(fl)) and np.all(np.isfinite(fm)) and np.all(np.isfinite(fr))):
        return None
    if tol is None:
        tol = 1e-10 * max(1.0, float(np.mean(np.abs(fm))) * (b - a))
    ganz = (r - l) / 6 * (fl + 4 * fm + fr)
    tol_i = np.full(n0, tol / n0)
    summe = 0.0
    for _ in range(45):
        lm, rm = (l + m) / 2, (m + r) / 2
        flm, frm = f(lm), f(rm)
        if not (np.all(np.isfinite(flm)) and np.all(np.isfinite(frm))):
            return None
        links = (m - l) / 6 * (fl + 4 * flm + fm)
        rechts = (r - m) / 6 * (fm + 4 * frm + fr)
        fehler = links + rechts - ganz
        fertig = np.abs(fehler) <= 15 * tol_i
        summe += float(np.sum((links + rechts + fehler / 15)[fertig]))
        rest = ~fertig
        if not rest.any():
            return vz * summe
        l, m, r = (np.concatenate([l[rest], m[rest]]), np.concatenate([lm[rest], rm[rest]]),
                   np.concatenate([m[rest], r[rest]]))
        fl, fm, fr = (np.concatenate([fl[rest], fm[rest]]), np.concatenate([flm[rest], frm[rest]]),
                      np.concatenate([fm[rest], fr[rest]]))
        ganz = np.concatenate([links[rest], rechts[rest]])
        tol_i = np.concatenate([tol_i[rest], tol_i[rest]]) / 2
        if l.size > 20000:
            break
    return vz * (summe + float(np.sum(ganz)))


def analysiere_funktion(f, x0: float, x1: float, a: float | None = None, b: float | None = None,
                        punkte: int = 2001) -> dict:
    """
    Numerische Kurvendiskussion von f im Bereich [x0, x1] (f: Ausdruck, Text oder Funktion).
    Rückgabe wie analysiere() des Polynom-Explorers:
      nullstellen, extrema [(x, y, "Hochpunkt"/"Tiefpunkt")], sattelpunkte, wendepunkte,
      integral, flaeche (None, falls nicht berechenbar), bereich.
    """
    if isinstance(f, str):
        f = Ausdruck(f)
    fv = lambda x: np.asarray(f(np.asarray(x, dtype=float)), dtype=float)
    breite = max(x1 - x0, 1e-9)
    xs = np.linspace(x0, x1, punkte)
    schritt = xs[1] - xs[0]
    h1, h2 = 2e-5 * breite, 2e-4 * breite
    g1 = lambda x: _abl1(fv, np.asarray(x, dtype=float), h1)
    g2 = lambda x: _abl2(fv, np.asarray(x, dtype=float), h2)
    with np.errstate(all="ignore"):
        ys = fv(xs)
        endlich = ys[np.isfinite(ys)]
        skala = float(np.percentile(endlich, 95) - np.percentile(endlich, 5)) if endlich.size else 1.0
        skala = max(skala, 1e-12)

        def stetig(x):
            d = 1e-9 * (1 + abs(x))
            w = fv(np.array([x - d, x, x + d]))
            return bool(np.all(np.isfinite(w)) and abs(w[2] - w[0]) <= 1e-3 * skala + 1e-12)

        def glatt(x, w):
            """Keine Polstelle/kein Sprung in [x − w, x + w]: Funktionswerte endlich und
            ihre Änderungen von Punkt zu Punkt ohne extreme Ausreißer."""
            v = fv(np.linspace(x - w, x + w, 41))
            if not np.all(np.isfinite(v)):
                return False
            d = np.abs(np.diff(v))
            return bool(d.max() <= 200 * np.median(d) + 1e-12 * (1 + np.abs(v).max()))

        null_eps = 1e-10 * breite
        y_eps = 1e-10 * (1 + skala)
        sauber = lambda v, eps: 0.0 if abs(v) < eps else float(v)
        fx = lambda x: sauber(float(fv(np.array([x]))[0]) + 0.0, y_eps)

        null = [sauber(v, null_eps) for v in _nullstellen_von(fv, xs, ys)]

        # Rundungsrauschen der Ableitungsschätzungen (verhindert Scheinpunkte bei Geraden/Konstanten)
        basis = np.abs(ys) + 1e-3 * skala
        d1s = g1(xs)
        extrema = []
        for x in _nullstellen_von(g1, xs, d1s, rauschen=50 * 2.2e-16 * basis / h1):
            x = sauber(x, null_eps)
            if not stetig(x) or not glatt(x, schritt):
                continue
            eps = schritt / 3
            l, r = np.sign(g1(np.array([x - eps, x + eps])))
            if l > 0 > r:
                extrema.append((float(x), fx(x), "Hochpunkt"))
            elif l < 0 < r:
                extrema.append((float(x), fx(x), "Tiefpunkt"))

        d2s = g2(xs)
        typ_d1 = float(np.median(np.abs(d1s[np.isfinite(d1s)]))) if np.any(np.isfinite(d1s)) else 1.0
        wende, sattel = [], []
        for x in _nullstellen_von(g2, xs, d2s, rauschen=500 * 2.2e-16 * basis / h2 ** 2):
            x = sauber(x, null_eps)
            if not stetig(x) or not glatt(x, 3 * h2):
                continue
            if any(abs(x - e[0]) < 3 * h2 for e in extrema):   # Artefakt neben Knick/Spitze
                continue
            wende.append((float(x), fx(x)))
            if abs(float(g1(np.array([x]))[0])) <= 1e-6 * (1 + typ_d1):
                sattel.append((float(x), fx(x)))

        # Berührstellen (doppelte Nullstellen) an Extrema
        for x, y, _ in extrema:
            if abs(y) <= 1e-9 * (1 + skala) and all(abs(x - v) > schritt for v in null):
                null.append(x)
        null.sort()

        integ = flaeche = None
        if a is not None and b is not None:
            integ = integral(fv, a, b)
            if integ is not None:
                gx = np.linspace(min(a, b), max(a, b), 257)
                integ = sauber(integ, 1e-11 * max(1.0, float(np.mean(np.abs(fv(gx)))) * abs(b - a)))
                lo, hi = min(a, b), max(a, b)
                gx = np.linspace(lo, hi, 4001)
                teile = [lo] + [float(v) for v in _nullstellen_von(fv, gx, fv(gx)) if lo < v < hi] + [hi]
                stuecke = [integral(fv, p, q) for p, q in zip(teile[:-1], teile[1:])]
                flaeche = None if any(s is None for s in stuecke) else float(sum(abs(s) for s in stuecke))

    return {"nullstellen": null, "extrema": extrema, "sattelpunkte": sattel, "wendepunkte": wende,
            "integral": integ, "flaeche": flaeche, "bereich": (x0, x1)}


def stammfunktion_numerisch(f, x0: float, x1: float, extra=()) -> dict:
    """
    Stammfunktion F(x) = ∫_anker^x f(t) dt (identischer Algorithmus in der Browser-Version):
    Simpson-Tabelle vom Anker nach links und rechts, dazwischen kubisch hermitesch interpoliert (F′ = f an den Knoten).
    Anker: 0, sonst 1, −1 oder die Bildmitte – die erste Stelle, an der f definiert ist.
    Über Pole/Lücken hinweg ist F nicht definiert (nan).  Rückgabe {"F": Funktion, "anker": Zahl}.
    """
    if isinstance(f, str):
        f = Ausdruck(f)
    fv = lambda x: np.asarray(f(np.asarray(x, dtype=float)), dtype=float)
    breite = max(x1 - x0, 1e-9)
    with np.errstate(all="ignore"):
        anker = next((c for c in (0.0, 1.0, -1.0, (x0 + x1) / 2)
                      if np.isfinite(fv(np.array([c]))[0]) and np.isfinite(fv(np.array([c + 1e-7 * (1 + abs(c))]))[0])),
                     (x0 + x1) / 2)
        pts = [x0, x1, anker] + [float(v) for v in extra if v is not None and math.isfinite(v)]
        lo, hi = min(pts) - 0.05 * breite, max(pts) + 0.05 * breite
        h = max((hi - lo) / 60000, breite / 4000)
        nl, nr = math.ceil((anker - lo) / h), math.ceil((hi - anker) / h)
        n = nl + nr + 1
        X0 = anker - nl * h
        DV = fv(X0 + h * np.arange(n))
        betr = np.sort(np.abs(DV[np.isfinite(DV)]))
        skala = float(betr[len(betr) // 2]) if betr.size else 1.0
        fm = fv(X0 + (np.arange(n - 1) + 0.5) * h)
        a, b = DV[:-1], DV[1:]
        simpson, trapez = h / 6 * (a + 4 * fm + b), h / 2 * (a + b)
        d = np.abs(simpson - trapez)                                     # Simpson gegen Trapez: Polstelle?
        ok = (np.isfinite(a) & np.isfinite(b) & np.isfinite(fm) &          # keine Lücke, keine Polstelle
              ~((d > 0.05 * h * (np.abs(a) + np.abs(fm) + np.abs(b)) / 3) & (d > 0.05 * h * (1 + skala))))
    FV = np.full(n, np.nan)
    FV[nl] = 0.0
    rechts = ok[nl:]
    k = rechts.size if rechts.all() else int(np.argmin(rechts))
    FV[nl + 1:nl + 1 + k] = np.cumsum(simpson[nl:nl + k])
    links = ok[:nl][::-1]
    k = links.size if links.all() else int(np.argmin(links))
    FV[nl - 1 - np.arange(k)] = -np.cumsum(simpson[:nl][::-1][:k])

    def F(x):
        x = np.asarray(x, dtype=float)
        u = (x - X0) / h
        j = np.floor(u)
        j = np.where(j == n - 1, n - 2, j)
        gueltig = np.isfinite(j) & (j >= 0) & (j < n - 1)
        ji = np.where(gueltig, j, 0).astype(int)
        t = u - ji
        F0, F1 = FV[ji], FV[ji + 1]
        t2, t3 = t * t, t * t * t
        with np.errstate(all="ignore"):
            y = ((2 * t3 - 3 * t2 + 1) * F0 + (t3 - 2 * t2 + t) * h * DV[ji] + (3 * t2 - 2 * t3) * F1
                 + (t3 - t2) * h * DV[ji + 1])
        y = np.where(gueltig & np.isfinite(F0) & np.isfinite(F1), y, np.nan)
        return y if y.ndim else float(y)

    return {"F": F, "anker": float(anker)}


def stamm_analyse(f, st: dict, erg_f: dict, x0: float, x1: float, a: float | None = None, b: float | None = None,
                  punkte: int = 2001) -> dict:
    """
    Kurvendiskussion der Stammfunktion: Nullstellen von F direkt, Extrema von F = Nullstellen von f mit
    Vorzeichenwechsel, Wendepunkte von F = Extremstellen von f (erg_f), Sattelpunkte dort, wo zusätzlich f = 0.
    """
    if isinstance(f, str):
        f = Ausdruck(f)
    fv = lambda x: np.asarray(f(np.asarray(x, dtype=float)), dtype=float)
    F = st["F"]
    breite = max(x1 - x0, 1e-9)
    xs = np.linspace(x0, x1, punkte)
    schritt = xs[1] - xs[0]
    with np.errstate(all="ignore"):
        Fs = F(xs)
        endlich = np.sort(Fs[np.isfinite(Fs)])
        perz = lambda q: endlich[min(len(endlich) - 1, max(0, round(q * (len(endlich) - 1))))]
        skala = max(float(perz(0.95) - perz(0.05)) if endlich.size else 1.0, 1e-12)
        null_eps = 1e-10 * breite
        sauber = lambda v, eps: 0.0 if abs(v) < eps else float(v)
        Fx = lambda x: sauber(float(F(x)) + 0.0, 1e-10 * (1 + skala))
        null = [sauber(v, null_eps) for v in _nullstellen_von(F, xs, Fs)]
        fs = fv(xs)
        extrema, wende, sattel = [], [], []
        for x in _nullstellen_von(fv, xs, fs):
            x = sauber(x, null_eps)
            if not np.isfinite(F(x)):
                continue
            eps = schritt / 3
            l, r = np.sign(fv(np.array([x - eps, x + eps])))
            if l > 0 > r:
                extrema.append((float(x), Fx(x), "Hochpunkt"))
            elif l < 0 < r:
                extrema.append((float(x), Fx(x), "Tiefpunkt"))
        f_betr = np.sort(np.abs(fs[np.isfinite(fs)]))
        f_skala = float(f_betr[len(f_betr) // 2]) if f_betr.size else 1.0
        for x, y, _ in erg_f["extrema"]:
            if not np.isfinite(F(x)):
                continue
            wende.append((float(x), Fx(x)))
            if abs(y) <= 1e-9 * (1 + f_skala):
                sattel.append((float(x), Fx(x)))
        for x, y, *_ in extrema + sattel:                   # Berührstellen
            if abs(y) <= 1e-9 * (1 + skala) and all(abs(x - v) > schritt for v in null):
                null.append(x)
        null.sort()
        integ = flaeche = None
        if a is not None and b is not None:
            integ = integral(F, a, b)
            if integ is not None:
                lo, hi = min(a, b), max(a, b)
                mittel = float(np.mean(np.abs(F(np.linspace(lo, hi, 257)))))
                integ = sauber(integ, 1e-11 * max(1.0, mittel * abs(b - a)))
                gx = np.linspace(lo, hi, 4001)
                teile = [lo] + [float(v) for v in _nullstellen_von(F, gx, F(gx)) if lo < v < hi] + [hi]
                stuecke = [integral(F, p, q) for p, q in zip(teile[:-1], teile[1:])]
                flaeche = None if any(v is None for v in stuecke) else float(sum(abs(v) for v in stuecke))
    return {"nullstellen": null, "extrema": extrema, "sattelpunkte": sattel, "wendepunkte": wende,
            "integral": integ, "flaeche": flaeche, "bereich": (x0, x1), "anker": st["anker"]}


def tangente_in(f, x0: float, breite: float = 13.0) -> dict:
    """Tangente an einer beliebigen Stelle x0 einer allgemeinen Funktion:
    {"x0", "y0", "m", "n"}; an Knickstellen existiert = False, bei unendlicher Steigung senkrecht = True."""
    if isinstance(f, str):
        f = Ausdruck(f)
    fv = lambda x: np.asarray(f(np.asarray(x, dtype=float)), dtype=float)
    h1 = 2e-5 * breite
    with np.errstate(all="ignore"):
        y0 = float(fv(np.array([x0]))[0])
        hk = 1e-6 * (1 + abs(x0))
        w = fv(np.array([x0 - hk, x0, x0 + hk]))
        ml, mr = (w[1] - w[0]) / hk, (w[2] - w[1]) / hk
        m = float(_abl1(fv, np.array([x0]), h1)[0])
    if not np.isfinite(m) or abs(m) > 1e7 or (abs(ml) > 1e6 and abs(mr) > 1e6 and ml * mr > 0):
        return {"x0": x0, "y0": y0, "m": math.inf, "n": math.nan, "senkrecht": True}
    if abs(ml - mr) > 1e-3 * (1 + abs(ml) + abs(mr)):
        return {"x0": x0, "y0": y0, "m": math.nan, "n": math.nan, "existiert": False}
    m = 0.0 if abs(m) < 1e-10 else m
    n = y0 - m * x0
    return {"x0": x0, "y0": y0, "m": m, "n": 0.0 if abs(n) < 1e-10 * (1 + abs(y0)) else n}


def tangenten_funktion(f, erg: dict, breite: float = 13.0) -> list[dict]:
    """Tangenten an Hoch-, Tief-, Wende- und Sattelpunkten einer allgemeinen Funktion.
    An Knickstellen gibt es keine Tangente (existiert = False), bei unendlicher Steigung eine
    senkrechte Tangente (senkrecht = True)."""
    if isinstance(f, str):
        f = Ausdruck(f)

    def eigenschaften(x0, y0):
        t = tangente_in(f, x0, breite)
        t["y0"] = y0
        if "senkrecht" not in t and "existiert" not in t:
            n = y0 - t["m"] * x0
            t["n"] = 0.0 if abs(n) < 1e-10 * (1 + abs(y0)) else n
        return t

    out, z = [], {"H": 0, "T": 0, "W": 0, "S": 0}
    for x, y, typ in erg["extrema"]:
        t = eigenschaften(x, y)
        if t.get("existiert") is not False and not t.get("senkrecht"):
            t["m"], t["n"] = 0.0, t["y0"]
        k = typ[0]
        z[k] += 1
        out.append({"typ": k, "nr": z[k], **t})
    for x, y in erg["wendepunkte"]:
        t = eigenschaften(x, y)
        s = any(abs(sx - x) < 1e-9 * (1 + abs(x)) for sx, _ in erg["sattelpunkte"])
        if s and not t.get("senkrecht"):
            t["m"], t["n"] = 0.0, t["y0"]
        k = "S" if s else "W"
        z[k] += 1
        out.append({"typ": k, "nr": z[k], **t})
    return out


# ==========================================================================
# Interaktive Oberfläche
# ==========================================================================
_HOCH = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")


def _huebsch(text: str) -> str:
    """Term-Text lesbarer: x^2 -> x², x^(-1) -> x⁻¹, sqrt( -> √(."""
    text = re.sub(r"\^(?:\((-?\d+)\)|(\d+)(?![.,\d/]))", lambda m: (m.group(1) or m.group(2)).translate(_HOCH), text)
    return text.replace("sqrt(", "√(")


class FunktionenExplorer(PolynomExplorer):
    """Polynom-Explorer mit allgemeiner Termeingabe für f und g und Funktionsliste „Weitere Funktionen“."""

    LISTE_ZEILEN = 15
    _FN_FELDER = PolynomExplorer._FN_FELDER + ("ausdruck", "modus", "_abl_cache")

    def __init__(self, term: str = STANDARD_TERM, fig=None, untere_grenze: float = -1.0,
                 obere_grenze: float = 1.0, x_bereich=(-6.5, 6.5), y_bereich=(-4.0, 4.0),
                 on_change: Callable[[dict, dict], None] | None = None, design: str | None = None,
                 kurven: dict | None = None, term_g: str = STANDARD_TERM_G, kurven_g: dict | None = None):
        self._start_terme = {"f": Ausdruck(term), "g": Ausdruck(term_g)}
        self._liste_offen = False
        self._liste_scroll = 0.0
        self._liste_druck = None
        self._filter = ""
        super().__init__(fig=fig, untere_grenze=untere_grenze, obere_grenze=obere_grenze,
                         x_bereich=x_bereich, y_bereich=y_bereich, on_change=on_change, design=design,
                         kurven=kurven, kurven_g=kurven_g)
        try:
            self.fig.canvas.manager.set_window_title("Funktionen-Explorer")
        except Exception:
            pass

    def _fn_anlegen(self, k, c, kurven):
        a = self._start_terme[k]
        p = a.als_polynom()
        self.ausdruck, self._abl_cache = a, (None, [])
        self.modus = "polynom" if p is not None else "allgemein"
        super()._fn_anlegen(k, p if p is not None else pe.standard_polynom(3), kurven)

    # ------------------------------------------------------------ öffentliche Schnittstelle
    def modus_von(self, fn: str = "f") -> str:
        """"polynom" oder "allgemein"."""
        with self._mit(fn):
            return self.modus

    def ableitung(self, k: int = 1, fn: str | None = None) -> Ausdruck:
        """k-te Ableitung von f bzw. g als Ausdruck (symbolisch, vereinfacht; zwischengespeichert)."""
        with self._mit(fn or self._geladen):
            if self._abl_cache[0] is not self.ausdruck:
                self._abl_cache = (self.ausdruck, [])
            liste = self._abl_cache[1]
            while len(liste) < k:
                liste.append((liste[-1] if liste else self.ausdruck).ableitung())
            return liste[k - 1]

    # ------------------------------------------------------------ Hooks des Polynom-Explorers
    def _polynom_modus(self) -> bool:
        return self.modus == "polynom"

    def _f(self, x):
        if self._polynom_modus():
            return super()._f(x)
        return self.ausdruck(np.asarray(x, dtype=float))

    def _kritische_stellen(self):
        # Polynome: exakt über die Nullstellen von f′; allgemeine Funktionen: numerisch (None)
        return super()._kritische_stellen() if self._polynom_modus() else None

    def _analyse(self, mit_grenzen: bool = True) -> dict:
        if self._polynom_modus():
            return super()._analyse(mit_grenzen)
        a, b = (self.a, self.b) if mit_grenzen else (None, None)
        return analysiere_funktion(self.ausdruck, self.xlim[0], self.xlim[1], a, b)

    def _term_text(self) -> str:
        return self.ausdruck.text

    def _term_setzen(self, text: str) -> None:
        self._uebernehme(Ausdruck(text))

    def _kopf_text(self) -> str:
        nm = self._nm["f"]
        return f"{nm}: Polynom vom Grad {self.n}" if self._polynom_modus() else f"{nm}: allgemeine Fkt. (sichtb. Ber.)"

    def _status_text(self, kurz: bool = False) -> str:
        nm = self._nm["f"]
        if kurz:
            return f"{nm}: Polynom vom Grad {self.n} (exakt)" if self._polynom_modus() else f"{nm}: allgemein (sichtbarer Bereich)"
        if self._polynom_modus():
            return f"{nm}: Polynom vom Grad {self.n} – exakte Analyse, Koeffizienten und Stützpunkte aktiv"
        return f"{nm}: allgemeine Funktion – Analyse im sichtbaren Bereich"

    def _kurven_daten(self, mit_grenzen: bool = True, erg_f: dict | None = None) -> list[dict]:
        if self._polynom_modus():
            return super()._kurven_daten(mit_grenzen, erg_f)
        a, b = (self.a, self.b) if mit_grenzen else (None, None)
        x0, x1 = self.xlim
        if erg_f is None:
            erg_f = analysiere_funktion(self.ausdruck, x0, x1, a, b)
        out = []
        for schl, k, name, tex, farbe, _ in self._kurven_liste():
            if not self._kv[schl]:
                continue
            d = {"schl": schl, "k": k, "name": name, "tex": tex, "farbe": farbe, "c": None, "fn": self._geladen}
            if k == 0:
                d.update(f=self.ausdruck, erg=erg_f, text=_huebsch(self.ausdruck.text))
            elif k > 0:                     # f^(k) nur dort, wo f definiert ist (z. B. ln x → 1/x nur für x > 0)
                A, fa = self.ableitung(k), self.ausdruck

                def g(x, A=A, fa=fa):
                    x = np.asarray(x, dtype=float)
                    y = np.where(np.isfinite(fa(x)), A(x), np.nan)
                    return y if y.ndim else float(y)
                d.update(f=g, erg=analysiere_funktion(g, x0, x1, a, b), text=_huebsch(A.text), ausdruck=A)
            else:
                st = stammfunktion_numerisch(self.ausdruck, x0, x1, (self.a, self.b))
                d.update(f=st["F"], erg=stamm_analyse(self.ausdruck, st, erg_f, x0, x1, a, b), stamm=st,
                         text=f"∫ {self._nm['f']}(t) dt von {_dez(st['anker'], 3)} bis x")
            out.append(d)
        return out

    def _nullstellen_numerisch(self, g, x0: float, x1: float) -> list[float]:
        xs = np.linspace(x0, x1, 4001)
        with np.errstate(all="ignore"):
            gs = np.asarray(g(xs), dtype=float)
        if not np.any(np.isfinite(gs) & (np.abs(gs) >= 1e-12)):
            return []                                   # gleiche Graphen
        with np.errstate(all="ignore"):
            return [float(x) for x in _nullstellen_von(g, xs, gs)]

    def _tangenten_berechnen(self, erg):
        if self._polynom_modus():
            return super()._tangenten_berechnen(erg)
        return tangenten_funktion(self.ausdruck, erg, self.xlim[1] - self.xlim[0])

    def _term_zeilen(self):
        return self.ausdruck.tex_zeilen(max_zeichen=58, name=self._nm["f"])

    def _stellen_mit_wert(self, y: float) -> list[float]:
        if self._polynom_modus():
            return super()._stellen_mit_wert(y)
        # numerisch: erst im sichtbaren Bereich, dann im zehnfach breiteren Bereich suchen
        g = lambda x: np.asarray(self.ausdruck(np.asarray(x, dtype=float)), dtype=float) - y
        x0, x1 = self.xlim
        mitte, breite = (x0 + x1) / 2, x1 - x0
        for faktor in (1, 10):
            xs = np.linspace(mitte - faktor * breite / 2, mitte + faktor * breite / 2, 8001)
            with np.errstate(all="ignore"):
                gs = g(xs)
                stellen = list(_nullstellen_von(g, xs, gs))
            # Berührstellen: y wird nur als Extremwert angenommen (kein Vorzeichenwechsel von f − y)
            erg = analysiere_funktion(self.ausdruck, xs[0], xs[-1])
            schritt = xs[1] - xs[0]
            for ex, ey, _ in erg["extrema"]:
                if abs(ey - y) <= 1e-6 * (1 + abs(y)) and all(abs(ex - v) > schritt for v in stellen):
                    stellen.append(float(ex))
            if stellen:
                return sorted(stellen)
        return []

    def _tangente_in(self, x0: float) -> dict:
        if self._polynom_modus():
            return super()._tangente_in(x0)
        return tangente_in(self.ausdruck, x0, self.xlim[1] - self.xlim[0])

    def _graph_drag_start(self):
        return super()._graph_drag_start() if self._polynom_modus() else self.ausdruck

    def _graph_drag(self, start, dx, dy):
        if self._polynom_modus():
            return super()._graph_drag(start, dx, dy)
        # auf 1/20 der Gitterweite einrasten, damit der Term übersichtlich bleibt
        rx = self._gitterschritt(self.ax.xaxis, self.xlim) / 20
        ry = self._gitterschritt(self.ax.yaxis, self.ylim) / 20
        self.ausdruck = start.verschoben(round(dx / rx) * rx, round(dy / ry) * ry)
        self._termfeld_setzen(self.ausdruck.text)

    @staticmethod
    def _gitterschritt(achse, grenzen) -> float:
        t = achse.get_major_locator().tick_values(*grenzen)
        return float(t[1] - t[0]) if len(t) > 1 else 1.0

    def _polynom_geaendert(self):
        self.modus = "polynom"
        self.ausdruck = Ausdruck(polynom_text(self.c))
        self._termfeld_setzen(self.ausdruck.text)

    def _zahl_lesen(self, txt: str) -> float:
        return wert(txt)

    def _zeichne_zusatz(self):
        """Ganzzahlige Funktionen (factorial, comb, …) als Punkte an den ganzen Stellen."""
        if self._polynom_modus():
            return
        k0, k1 = math.ceil(self.xlim[0]), math.floor(self.xlim[1])
        if k1 - k0 > 400 or k1 < k0:
            return
        ks = np.arange(k0, k1 + 1, dtype=float)
        yk = self._f(ks)
        neben = self._f(np.concatenate([ks - 0.3, ks + 0.3]))
        einzeln = np.isfinite(yk) & ~np.isfinite(neben[:ks.size]) & ~np.isfinite(neben[ks.size:])
        if np.any(einzeln):
            self.ax.plot(ks[einzeln], yk[einzeln], "o", ms=6, zorder=5,
                         color=FARBEN["graph"] if self._geladen == "f" else FARBEN["g_graph"])

    def _boxen_aktualisieren(self):
        super()._boxen_aktualisieren()
        allgemein = not self._polynom_modus()
        if allgemein:
            for tb in self.boxen:
                tb.ax.set_visible(False)
        self.koeff_hinweis.set_visible(allgemein)

    def _zuruecksetzen(self):
        self.xlim, self.ylim = [-6.5, 6.5], [-4.0, 4.0]
        self.a, self.b = -1.0, 1.0
        for k, t in (("f", STANDARD_TERM), ("g", STANDARD_TERM_G)):
            with self._mit(k):
                self._uebernehme(Ausdruck(t))
            self._termfeld_setzen(t, k)
        self._status_fehler = ""
        self.aktualisiere()

    # ------------------------------------------------------------ Oberfläche
    def _baue_oberflaeche(self):
        super()._baue_oberflaeche()
        fig = self.fig
        self._koeff_beispiel = "(z. B. 0,5   -3/4   1/7!   sqrt(2))"
        self._hinweis.set_text(
            "Termfelder f(x), g(x): z. B. 2x^2, sin(x), e^x, √x, |x|, log(x; 2)  ·  Funktion f | g: was Grad, Koeffizienten "
            "und Punkt P/Q bearbeiten\nMaus:  Kreise = Polynom verformen  ·  Graph = verschieben  ·  Punkt P/Q = Tangente "
            "entlang des Graphen  ·  Marken a / b = Integrationsgrenzen  ·  Hintergrund = Ansicht  ·  Mausrad = Zoom"
            "\nSummen:  Ober-, Unter-, Trapez-, Mittensumme über [a; b] mit n Teilintervallen (n auch über die Schieberegler, 1 … 1000)  ·  Maus über ein Rechteck bzw. "
            "Trapez = sein Anteil an der Summe (absolut und in Prozent)")

        self.liste_knopf = self._knopf([0.533, 0.935, 0.102, 0.042], "Weitere Funktionen", FARBEN["feld"])
        self.liste_knopf.on_clicked(lambda _e: self._liste_umschalten())

        self.koeff_hinweis = fig.text(
            0.70, 0.80, "Koeffizienten gibt es nur bei Polynomen.\n"
                        "Polynom als Term eingeben (z. B. (x-1)(x+2)²)\noder einen Grad wählen.",
            color=FARBEN["text_dim"], fontsize=10, va="top", linespacing=1.5, visible=False)

        # Funktionsliste (Overlay über dem Koordinatensystem)
        pos = self.ax.get_position()
        self.liste_ax = fig.add_axes([pos.x0, pos.y0, pos.width, pos.height], zorder=40)
        self.liste_ax.set_navigate(False)
        self.such_box = TextBox(fig.add_axes([pos.x0 + 0.215, pos.y1 - 0.052, 0.24, 0.036], zorder=41),
                                "Suchen: ", initial="")
        self._stil_textbox(self.such_box)
        self.such_box.label.set_fontsize(11)
        self.such_box.on_text_change(self._filter_geaendert)
        self.zu_knopf = self._knopf([pos.x1 - 0.085, pos.y1 - 0.052, 0.075, 0.036], "Schließen", FARBEN["feld"])
        self.zu_knopf.ax.set_zorder(41)
        self.zu_knopf.on_clicked(lambda _e: self._liste_umschalten(False))
        self._liste_sichtbar(False)
        self._akt_beschriften()
        self._herleitung_knoepfe()

    # ---- Herleitungen: Doppelklick (oder ⓘ) auf einen Rechenknopf → kommentierter Rechenweg als Druckseite ----
    _HL_SCHALTER = {"nullstellen": "null", "extrema": "ext", "wende": "wende", "integral": "integral", "schnitt": "schnitt",
                    "yachse": "yachse", "t_hoch": "tH", "t_tief": "tT", "t_wende": "tW", "t_frei": "tP", "sekante": "sek",
                    "s_ober": "ober", "s_unter": "unter", "s_trapez": "trapez", "s_mitte": "mitte"}
    _HL_KURVE = {"F": "kF", "f": "kf", "d1": "kd1", "d2": "kd2", "d3": "kd3"}

    def _herleitung_knoepfe(self):
        """Kleine ⓘ-Knöpfe an allen Rechenknöpfen und Doppelklick-Erkennung."""
        self._hl_ziele = []                       # (Achse des Knopfes, Art, Funktion oder None, Schalter, Kurve)
        self._hl_info = []
        for schl, art in self._HL_SCHALTER.items():
            if schl in self.knoepfe:
                self._hl_ziele.append((self.knoepfe[schl][0].ax, art, None, schl, None))
        for fn, knoepfe in self.kurven_knoepfe.items():
            for schl, btn in knoepfe.items():
                self._hl_ziele.append((btn.ax, self._HL_KURVE[schl], fn, None, schl))
        for ax, art, fn, schl, kurve in self._hl_ziele:
            pos = ax.get_position()
            iax = self.fig.add_axes([pos.x1 - 0.0105, pos.y1 - 0.0165, 0.0095, 0.0145], zorder=ax.get_zorder() + 5)
            ib = Button(iax, "i", color=FARBEN["feld"], hovercolor=FARBEN["feld_hover"])
            ib.label.set_fontsize(7)
            ib.label.set_fontweight("bold")
            ib.label.set_color(FARBEN["text"])
            ib.on_clicked(lambda _e, art=art, fn=fn: self.zeige_herleitung(art, fn))
            self._hl_info.append(ib)
        self._hl_ausstehend = None
        self.fig.canvas.mpl_connect("button_press_event", self._hl_druck)
        self.fig.canvas.mpl_connect("button_release_event", self._hl_loslassen)

    def _hl_druck(self, ev):
        if not getattr(ev, "dblclick", False):
            return
        for ax, art, fn, schl, kurve in self._hl_ziele:
            if ev.inaxes is ax:
                self._hl_ausstehend = (art, fn, schl, kurve)
                return

    def _hl_loslassen(self, ev):
        """Nach dem zweiten Klick (der den Knopf zurückgeschaltet hat): Eigenschaft einblenden, Rechenweg öffnen."""
        if not self._hl_ausstehend:
            return
        art, fn, schl, kurve = self._hl_ausstehend
        self._hl_ausstehend = None
        if schl is not None and not self.zeige.get(schl, True):
            self._umschalten(schl)
        if kurve is not None:
            with self._mit(fn):
                an = self._kv[kurve]
            if not an:
                self._kurve_umschalten(fn, kurve)
        self.zeige_herleitung(art, fn)

    def _herleitung_lage(self, art: str, fn: str | None = None) -> dict:
        fn = fn or self.akt

        def daten(k):
            with self._mit(k):
                return {"fn": NAMEN[k]["f"], "term": self._term_text(),
                        "c": [float(v) for v in self.c] if self._polynom_modus() else None}
        d = daten(fn)
        with self._mit(fn):
            xP, xA, xB = float(self.t_x), float(self.sek["xA"]), float(self.sek["xB"])
        return {"art": art, "fn": d["fn"], "term": d["term"], "c": d["c"], "x0": float(self.xlim[0]), "x1": float(self.xlim[1]),
                "a": float(self.a), "b": float(self.b), "n": int(self.summe_n), "xP": xP, "xA": xA, "xB": xB,
                "andere": daten("g" if fn == "f" else "f")}

    def herleitung(self, art: str, fn: str | None = None) -> dict:
        """Kommentierter Rechenweg zu einem Knopf als Dokument (siehe herleitung.py), z. B. herleitung("ext")."""
        import herleitung as hl
        return hl.erzeuge(self._herleitung_lage(art, fn))

    def zeige_herleitung(self, art: str, fn: str | None = None, pfad: str | None = None) -> str:
        """Rechenweg als druckbare Seite im Browser öffnen (Knopf „Drucken“ auf der Seite); gibt den Dateipfad zurück."""
        import herleitung as hl
        p = hl.zeige(self.herleitung(art, fn), pfad)
        self.status.set_text("Rechenweg geöffnet: " + p)
        self.fig.canvas.draw_idle()
        return p

    def _alle_textboxen(self) -> list:
        return super()._alle_textboxen() + [self.such_box]

    def _design_anwenden(self, alt: dict) -> None:
        super()._design_anwenden(alt)
        if self._liste_offen:
            self._zeichne_liste()
        for ib in getattr(self, "_hl_info", []):         # ⓘ-Knöpfe der Herleitungen
            ib.color, ib.hovercolor = FARBEN["feld"], FARBEN["feld_hover"]
            ib.ax.set_facecolor(FARBEN["feld"])
            ib.label.set_color(FARBEN["text"])
        try:
            self.fig.canvas.manager.set_window_title(f"Funktionen-Explorer – {DESIGN_NAMEN[self.design]}")
        except Exception:
            pass

    def _uebernehme(self, a: Ausdruck):
        """Term für die geladene Funktion übernehmen (Polynom erkennen)."""
        p = a.als_polynom()
        self.ausdruck = a
        if p is not None:
            self.modus = "polynom"
            self.c, self.n = np.asarray(p, dtype=float), len(p) - 1
            self._stuetz_verteilen()
        else:
            self.modus = "allgemein"

    def _grad_geaendert(self, val):
        if self._sperre:
            return
        if not self._polynom_modus():
            self.modus = "polynom"
            self.n = -1                     # erzwingt Standardpolynom
        super()._grad_geaendert(val)

    # ------------------------------------------------------------ Funktionsliste
    def _eintraege(self):
        f = self._filter.strip().lower()
        zeilen = []
        for kat, liste in FUNKTIONSKATALOG:
            treffer = [e for e in liste if not f or f in e[0] or f in e[1].lower() or f in e[2].lower()]
            if treffer:
                zeilen.append(("kat", kat))
                zeilen += [("fn", e) for e in treffer]
        return zeilen

    def _liste_sichtbar(self, an: bool):
        self._liste_offen = an
        for a in (self.liste_ax, self.such_box.ax, self.zu_knopf.ax):
            a.set_visible(an)
        if not an and self.such_box.capturekeystrokes:
            self.such_box.stop_typing()

    def _liste_umschalten(self, an: bool | None = None):
        an = (not self._liste_offen) if an is None else an
        self._liste_sichtbar(an)
        if an:
            self._zeichne_liste()
        self.fig.canvas.draw_idle()

    def _filter_geaendert(self, text):
        self._filter = text
        self._liste_scroll = 0.0
        self._zeichne_liste()
        self.fig.canvas.draw_idle()

    def _zeichne_liste(self):
        ax = self.liste_ax
        ax.cla()
        ax.set_facecolor(FARBEN["panel"])
        ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values():
            s.set_color(FARBEN["gitter_fein"])
        n_sicht = self.LISTE_ZEILEN
        kopf = 1.6                                  # Zeilen für Titel + Suchfeld
        ax.set_xlim(0, 1)
        ax.set_ylim(n_sicht + kopf, 0)
        ax.text(0.015, 0.55, "Weitere Funktionen", color=FARBEN["text"], fontsize=13, fontweight="bold",
                va="center")
        ax.text(0.015, 1.25, f"Antippen fügt die Funktion an der Cursorposition in {self._letztes_termfeld}(x) ein "
                             "(zuletzt benutztes Termfeld) · Mausrad oder Ziehen = blättern",
                color=FARBEN["text_dim"], fontsize=8.5, va="center")
        eintraege = self._eintraege()
        max_scroll = max(0, len(eintraege) - n_sicht)
        self._liste_scroll = min(max(self._liste_scroll, 0), max_scroll)
        start = int(self._liste_scroll)
        self._liste_sicht = []
        for k, (art, e) in enumerate(eintraege[start:start + n_sicht]):
            y = kopf + k + 0.5
            if art == "kat":
                ax.text(0.015, y + 0.12, e.upper(), color=FARBEN["gitter"], fontsize=9, fontweight="bold",
                        va="center")
                ax.plot([0.015, 0.97], [y + 0.42, y + 0.42], color=FARBEN["gitter_fein"], lw=0.6)
            else:
                name, vorlage, beschr, herkunft = e
                ax.text(0.03, y, vorlage, color=FARBEN["graph"], fontsize=11, family="DejaVu Sans Mono",
                        va="center")
                ax.text(0.33, y, beschr, color=FARBEN["text"], fontsize=10, va="center")
                ax.text(0.965, y, herkunft, color=FARBEN["text_dim"], fontsize=8, va="center", ha="right")
            self._liste_sicht.append((art, e))
        if not eintraege:
            ax.text(0.5, kopf + 2, "Keine Funktion gefunden.", color=FARBEN["text_dim"], ha="center")
        if max_scroll > 0:                          # Bildlaufleiste
            anteil = n_sicht / len(eintraege)
            y0 = kopf + (self._liste_scroll / len(eintraege)) * n_sicht
            ax.add_patch(plt.Rectangle((0.985, y0), 0.008, anteil * n_sicht, color=FARBEN["text_dim"],
                                       alpha=0.6))
        self._liste_kopf = kopf

    def _liste_zeile(self, ev):
        """Index der Listenzeile unter dem Mauszeiger (oder None)."""
        if ev.inaxes is not self.liste_ax or ev.ydata is None:
            return None
        k = int(ev.ydata - self._liste_kopf)
        return k if 0 <= k < len(self._liste_sicht) and ev.ydata >= self._liste_kopf else None

    def _einfuegen(self, vorlage: str):
        tb = self.term_boxen[self._letztes_termfeld]
        text = tb.text
        i = min(max(getattr(tb, "cursor_index", len(text)), 0), len(text))
        neu = text[:i] + vorlage + text[i:]
        self._liste_umschalten(False)
        tb.set_val(neu)                             # löst _term_eingabe für f bzw. g aus
        tb.cursor_index = i + len(vorlage)

    # ------------------------------------------------------------ Maus (Liste zuerst)
    def _druck(self, ev):
        for k, tb in self.term_boxen.items():          # zuletzt benutztes Termfeld merken
            if ev.inaxes is tb.ax:
                self._letztes_termfeld = k
        if self._liste_offen:
            if ev.inaxes is self.liste_ax:
                self._liste_druck = (ev.y, self._liste_scroll, False)
            return
        super()._druck(ev)

    def _bewegung(self, ev):
        if self._liste_offen:
            if self._liste_druck is not None:
                y0, s0, _ = self._liste_druck
                zeile_px = self.liste_ax.bbox.height / (self.LISTE_ZEILEN + 1.6)
                if abs(ev.y - y0) > 5:
                    self._liste_druck = (y0, s0, True)
                    self._liste_scroll = s0 + (ev.y - y0) / zeile_px
                    self._zeichne_liste()
                    self.fig.canvas.draw_idle()
            return
        super()._bewegung(ev)

    def _loslassen(self, ev):
        if self._liste_offen:
            druck, self._liste_druck = self._liste_druck, None
            if druck is not None and not druck[2]:
                k = self._liste_zeile(ev)
                if k is not None and self._liste_sicht[k][0] == "fn":
                    self._einfuegen(self._liste_sicht[k][1][1])
            return
        super()._loslassen(ev)

    def _scroll(self, ev):
        if self._liste_offen:
            if ev.inaxes is self.liste_ax:
                self._liste_scroll += -3 if ev.button == "up" else 3
                self._zeichne_liste()
                self.fig.canvas.draw_idle()
            return
        super()._scroll(ev)


def starte(term: str = STANDARD_TERM, block: bool = True, **kwargs) -> FunktionenExplorer:
    """Öffnet den Funktionen-Explorer mit dem angegebenen Term (zweite Funktion: term_g="…")."""
    ex = FunktionenExplorer(term, **kwargs)
    plt.show(block=block)
    return ex


if __name__ == "__main__":
    # python funktionen_explorer.py [--pearson] [Term]
    args = sys.argv[1:]
    design = "pearson" if "--pearson" in args else None
    args = [a for a in args if a != "--pearson"]
    starte(" ".join(args) if args else STANDARD_TERM, design=design)
