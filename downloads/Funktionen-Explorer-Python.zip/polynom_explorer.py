"""
polynom_explorer.py
===================

Interaktiver Funktionsplotter für ganzrationale Funktionen (Polynome) vom
Grad n = 0 … 20 (z. B. auch Taylorpolynome) – gestaltet im Stil der 3Blue1Brown-Videos
(schwarzer Hintergrund, blaues Koordinatengitter, kräftige Farbakzente,
Computer-Modern-Formelsatz).

Funktionen
----------
* Schieberegler für den Grad n
* Eingabemaske für alle Koeffizienten a0 … an. Erlaubt sind Rechenausdrücke
  mit + - * / ^, Klammern und Fakultät !, z. B. "0,5", "-3/4", "1/7!",
  "(-1)^3/(2*3+1)!", "2^5/5!". Koeffizienten der Form p/k! werden auch
  wieder als p/k! angezeigt (praktisch für Taylorpolynome).
* Polynomterm in mathematischer Notation
* Ein-/Ausblenden von Nullstellen, Extrempunkten, Wendepunkten, Integral
* Frei verschiebbare Tangente („Punkt P“): Punkt P mit Maus/Finger entlang des Graphen ziehen
  oder seine Koordinaten x_P bzw. y_P direkt eintragen (zu y_P wird die nächstgelegene Stelle mit f(x) = y_P gesucht),
  Tangentengleichung t_P(x) und Koordinaten von P werden laufend angezeigt
  (P rastet an Nullstellen, Extrem- und Wendestellen ein)
* Tangenten an Hoch-, Tief- und Wende-/Sattelpunkten per Knopfdruck:
  beschriftet im Graphen, Gleichungen als gesetzte Terme (t_H1(x) = …)
* Zwei Darstellungen: dunkel (3Blue1Brown-Stil) und hell (Pearson-Schulbuch);
  Wechselschalter „dunkel | hell“ oben rechts, außerdem umschaltbar mit set_design("pearson") / set_design("3b1b") oder beim Start mit design=…
* Funktionsleiste mit Wechselschaltern  F | f | f′ | f″ | f‴  (Stammfunktion mit F(0) = 0, Funktion, 1.–3. Ableitung):
  alle beliebig kombinierbar, jede eingeblendete Kurve mit eigener Farbe, eigenen Nullstellen, Extrem- und
  Wendepunkten und eigenem Integral; per Programm mit zeige_kurven(F=True, d1=True, …) bzw. beim Start mit kurven={…}
* Zwei Funktionen f und g: Termfelder „f(x) = …“ und „g(x) = …“ (Polynome wie (x-1)(x+2)², x^3 - 4x, 0,5x³),
  zweite Funktionsleiste  G | g | g′ | g″ | g‴, eigene Stützpunkte, Tangenten (gestrichelt), Punkt Q und
  Integralfläche für g. „Funktion f | Funktion g“ wählt, welche Funktion Grad-Regler, Koeffizienten
  (a_i bzw. b_i) und Punkt P bzw. Q bearbeiten.
* „Sekanten einblenden“: zwei Punkte A und B erscheinen unten links im sichtbaren Teil des Graphen der
  bearbeiteten Funktion; sie lassen sich entlang des Graphen ziehen oder über x_A, y_A, x_B, y_B eingeben.
  Steigungsdreieck mit Δx und Δy, Koordinaten von A und B sowie die Sekantengleichung s_AB(x) = m·x + n
  werden laufend angezeigt (per Programm: zeige_sekante(), set_sekantenpunkte(xa, xb), sekante)
* Trace-Modus (Knopf über dem Koordinatensystem): gestrichelte Senkrechte an der Stelle x mit Punkt auf der
  x-Achse und Punkten auf allen sichtbaren Graphen (mit Koordinaten); x bzw. y = f(x) auch eintragbar.
  Kurven, die bei laufendem Trace eingeschaltet werden (z. B. f′), entstehen als Spur hinter dem Trace-Punkt
  (per Programm: zeige_trace(), set_trace_x(x), trace)
* „▶ Abspielen“: der Trace-Punkt läuft gleichmäßig nach rechts (ganze Bildbreite in 8 s), Spuren wachsen mit
* „Schnittpunktberechnung“: Schnittpunkte aller sichtbaren Graphen (paarweise; Polynome exakt, sonst numerisch
  im sichtbaren Bereich); „y-Achsenabschnitt“: Schnittpunkte aller sichtbaren Graphen mit der y-Achse
* Knopf „⤓ Grafik als SVG“ rechts oberhalb des Koordinatensystems: speichert den Inhalt des Grafikfensters als
  Vektorgrafik; der Dateiname nennt die eingeblendeten Kurven und die aktiven Eigenschaften, z. B.
  "f_g'_Extrema_Tangente-Hochpunkte_Sekante.svg" (per Programm: speichere_svg(pfad=None), svg_dateiname)
* Eingabefelder für untere / obere Integrationsgrenze
  (orientiertes Integral + Flächeninhalt); die Grenzen lassen sich
  auch als Marken auf der x-Achse mit der Maus ziehen
* Knopfleiste  Obersumme | Untersumme | Trapezsumme | Mittensumme  mit den Feldern a (Untergrenze),
  b (Obergrenze) und n (Anzahl gleich breiter Teilintervalle, 1 … 1000; zusätzlich je ein Schieberegler unter der
  Grafik und unter den Feldern, logarithmisch geteilt): die Summe der bearbeiteten Funktion wird
  berechnet und als Rechtecke bzw. Trapeze gezeichnet (Gesamtwert oben rechts, Vergleich mit dem Integral).
  Fährt man mit der Maus über ein Rechteck/Trapez, erscheint sein Anteil an der Summe – absolut und in
  Prozent; beim Verlassen verschwindet die Anzeige (per Programm: zeige_summe("ober", n=8), summe;
  rein rechnerisch: riemann_summe(f, a, b, n, "trapez"))
* Maus-Interaktion im Koordinatensystem:
    - weiße Stützpunkte ziehen   -> Graph wird verformt (Interpolation),
                                    Koeffizienten werden neu berechnet
    - Graph selbst ziehen        -> Graph wird verschoben  f(x-dx)+dy
    - Marken a / b ziehen        -> Integrationsgrenzen verschieben
                                    (rasten an Nullstellen, Extrem-,
                                    Wendestellen und Gitterlinien ein)
    - Hintergrund ziehen         -> Ansicht verschieben
    - Mausrad                    -> Zoom

Verwendung als Unterprogramm
----------------------------
    from polynom_explorer import analysiere, PolynomExplorer, starte

    # rein rechnerisch (ohne Grafik), Koeffizienten aufsteigend a0, a1, …
    erg = analysiere([0, -4, 0, 1], a=-2, b=2)
    erg["nullstellen"], erg["extrema"], erg["wendepunkte"], erg["integral"]
    tangenten([0, -4, 0, 1])   # [{"typ": "H", "nr": 1, "x0": …, "y0": …, "m": …, "n": …}, …]

    # interaktiv
    ex = starte([0, -4, 0, 1])                    # blockierend
    ex = starte([0, -4, 0, 1], design="pearson")  # im Pearson-Schulbuchstil
    ex.set_design("3b1b")                         # Darstellung wechseln
    ex = PolynomExplorer(grad=4, on_change=print) # eigenes Programm
    ex.set_koeffizienten([1, 0, -2]);  ex.koeffizienten
    ex.zeige_kurven(F=True, d1=True, d2=True)    # Stammfunktion, f′ und f″ zusätzlich einblenden
    ex.analyse_kurven()                           # {"F": {…}, "f": {…}, "d1": {…}, "d2": {…}}
    koeffizienten_k([0, -4, 0, 1], 2)             # Koeffizienten von f″ (k = −1: Stammfunktion)
    polynom_aus_term("(x-1)(x+2)²")               # [-4, 0, 3, 1]

    # zweite Funktion g
    ex = PolynomExplorer(koeffizienten_g=[1, 0, -1], kurven_g={"f": True, "d1": True})
    ex.set_term("x^3 - 4x", "g");  ex.koeffizienten_g;  ex.term_g
    ex.zeige_kurven("g", F=True);  ex.analyse_kurven("g");  ex.analyse("g")
    ex.bearbeite("g")                             # Grad, Koeffizienten b_i und Punkt Q gehören jetzt zu g
    ex.set_tangentenpunkt(1.5, "g");  ex.tangente_q
    # on_change(erg_f, erg_g) wird nach jeder Änderung mit den Analysen von f und g aufgerufen
    ex.zeige_eigenschaften(nullstellen=True, extrema=True, stuetz=True)   # Start: nur der Graph von f
    ex.zeige_sekante(); ex.set_sekantenpunkte(-1, 2); ex.sekante
    ex.zeige_trace(); ex.zeige_kurven(d1=True); ex.set_trace_x(2); ex.trace   # f′ als Spur bis x = 2
    ex.abspielen(); ex.anhalten()                 # Trace-Punkt laufen lassen
    ex.zeige_eigenschaften(schnitt=True, yachse=True); ex.schnittpunkte; ex.y_abschnitte   # {"xA", "yA", "xB", "yB", "dx", "dy", "m", "n", …}
    ex.zeige_summe("ober", n=8); ex.summe["wert"]   # Obersumme O_8 der bearbeiteten Funktion; zeige_summe(None) blendet aus
    riemann_summe(lambda x: x**2, 0, 1, 4, "mitte")["wert"]   # 0.328125 (ohne Grafik)

Start als Programm:   python polynom_explorer.py [a0 a1 a2 …]
"""

from __future__ import annotations

import math
import os
import re
import sys
import textwrap
from contextlib import contextmanager
from fractions import Fraction
from typing import Callable, Iterable

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator, MaxNLocator
from matplotlib.widgets import Button, Slider, TextBox
from numpy.polynomial import polynomial as P
from numpy.polynomial import Polynomial

__all__ = ["analysiere", "tangente", "tangenten", "gerade_tex", "standard_polynom", "PolynomExplorer", "starte", "FARBEN",
           "FARBSCHEMATA", "DESIGN_NAMEN", "KURVEN", "KURVEN_G", "NAMEN", "koeffizienten_k", "polynom_klartext",
           "polynom_aus_term", "polynom_term_text", "PolynomTermFehler", "STANDARD_G", "riemann_summe", "SUMMEN_ARTEN",
           "SUMMEN_ZEICHEN", "SUMMEN_N_MAX"]

# --------------------------------------------------------------------------
# Farbschemata: 3Blue1Brown (Manim) und Pearson-Schulbuch
# --------------------------------------------------------------------------
FARBSCHEMATA: dict[str, dict] = {}

FARBSCHEMATA["3b1b"] = {
    "hintergrund": "#000000",
    "figur": "#000000",
    "panel": "#101418",
    "feld": "#1b2229",
    "feld_hover": "#26313b",
    "gitter": "#29ABCA",       # BLUE_D
    "gitter_fein": "#1C758A",  # BLUE_E
    "achsen": "#FFFFFF",
    "text": "#ECECEC",
    "text_dim": "#8A949E",
    "graph": "#58C4DD",        # BLUE_C
    "nullstelle": "#FC6255",   # RED_C
    "extremum": "#FFFF00",     # YELLOW_C
    "wendepunkt": "#83C167",   # GREEN_C
    "integral_pos": "#5CD0B3", # TEAL_C
    "integral_neg": "#C55F73", # MAROON_C
    "stuetz": "#FFFFFF",
    "t_hoch": "#F0AC5F",       # GOLD_C   – Tangenten an Hochpunkten
    "t_tief": "#B189C6",       # PURPLE_B – Tangenten an Tiefpunkten
    "t_wende": "#E46FD0",      # PINK     – Tangenten an Wende-/Sattelpunkten
    "t_frei": "#FF862F",       # ORANGE   – frei verschiebbare Tangente im Punkt P
    "sekante": "#C8E64C",      # Sekante durch A und B mit Steigungsdreieck
    "trace": "#E8E8E8",        # Trace-Modus: Senkrechte und Punkt auf der x-Achse
    "schnitt": "#F5A3FF",      # Schnittpunkte der Graphen
    "yachse": "#7FE3FF",       # y-Achsenabschnitte
    "summe": "#FFC857",        # Riemann-Summen: Rechtecke/Trapeze über der x-Achse
    "summe_neg": "#FF7A90",    # … unter der x-Achse
    "summe_alpha": 0.30,       # Deckkraft der Rechtecke/Trapeze
    "kurve_F": "#BBBBBB",      # GREY_B   – Stammfunktion F
    "kurve_d1": "#9A72AC",     # PURPLE_C – 1. Ableitung f′
    "kurve_d2": "#CD853F",     # LIGHT_BROWN – 2. Ableitung f″
    "kurve_d3": "#D147BD",     # PINK_D   – 3. Ableitung f‴
    "g_graph": "#FF8F6B",      # zweite Funktion g und ihre Kurven G, g′, g″, g‴
    "g_F": "#C9A88E",
    "g_d1": "#E6B450",
    "g_d2": "#7FD1AE",
    "g_d3": "#F28FB0",
    "aus": "#2a2f35",
    # Zeichenelemente, die vom Hintergrund abhängen
    "kontur": "#000000",       # Rand der Punkte und Marken
    "label_bg": "#000000",     # Hinterlegung der Beschriftungen
    "auf_farbe": "#000000",    # Schrift auf farbigen Knöpfen und Marken
    "rahmen": "#222222",       # Rahmen des Koordinatensystems
    "stuetz_fuellung": "none",
    "glanz": 0.18,             # Deckkraft des Leuchtsaums um den Graphen (0 = keiner)
    "graph_lw": 3.0,
    "flaeche_pos": 0.40, "flaeche_neg": 0.45,
    "pfeile": False,           # Pfeilspitzen an den Achsen
}

# Farbschema der Pearson-Mathematikbücher (wie in den Lernseiten „Grundlagen der Analysis“,
# „Analytische Geometrie“ usw.): weißes Blatt, helles Karogitter, dunkle Achsen mit Pfeilen,
# Graph in Pearson-Blau, gedeckte Akzentfarben.
FARBSCHEMATA["pearson"] = {
    "hintergrund": "#ffffff",
    "figur": "#eef1f9",
    "panel": "#ffffff",
    "feld": "#f4f6fb",
    "feld_hover": "#e7edfc",
    "gitter": "#aab8d4",
    "gitter_fein": "#d5dced",
    "achsen": "#1b2030",
    "text": "#1b2030",
    "text_dim": "#5b6478",
    "graph": "#2454c9",
    "nullstelle": "#0e7c66",
    "extremum": "#b23064",
    "wendepunkt": "#6d3fb0",
    "integral_pos": "#2454c9",
    "integral_neg": "#b5620a",
    "stuetz": "#1b2030",
    "t_hoch": "#b5620a",
    "t_tief": "#0e7490",
    "t_wende": "#8a6d1d",
    "t_frei": "#d9480f",
    "sekante": "#4d7c0f",
    "trace": "#334155",
    "schnitt": "#7c3aed",
    "yachse": "#0369a1",
    "summe": "#c026d3",
    "summe_neg": "#be123c",
    "summe_alpha": 0.20,
    "kurve_F": "#5b6478",
    "kurve_d1": "#0e7490",
    "kurve_d2": "#b5620a",
    "kurve_d3": "#8a6d1d",
    "g_graph": "#c2410c",
    "g_F": "#8a7766",
    "g_d1": "#a16207",
    "g_d2": "#047857",
    "g_d3": "#be185d",
    "aus": "#e3e8f3",
    "kontur": "#ffffff",
    "label_bg": "#ffffff",
    "auf_farbe": "#ffffff",
    "rahmen": "#dbe0ee",
    "stuetz_fuellung": "#ffffff",
    "glanz": 0.0,
    "graph_lw": 2.6,
    "flaeche_pos": 0.16, "flaeche_neg": 0.22,
    "pfeile": True,
}

DESIGN_NAMEN = {"3b1b": "dunkel (3Blue1Brown)", "pearson": "hell (Pearson-Schulbuch)"}

# Funktionsleiste: (Schlüssel, k, Name, Mathtext-Name, Farbschlüssel, Beschriftung)
# k = −1 Stammfunktion, 0 Funktion, 1 … 3 Ableitungen
KURVEN = [("F", -1, "F", "F", "kurve_F", "Stammfkt."), ("f", 0, "f", "f", "graph", "Funktion"),
          ("d1", 1, "f′", "f'", "kurve_d1", "1. Abl."), ("d2", 2, "f″", "f''", "kurve_d2", "2. Abl."),
          ("d3", 3, "f‴", "f'''", "kurve_d3", "3. Abl.")]

# zweite Funktion g mit Stammfunktion G und Ableitungen g′, g″, g‴
KURVEN_G = [("F", -1, "G", "G", "g_F", "Stammfkt."), ("f", 0, "g", "g", "g_graph", "Funktion"),
            ("d1", 1, "g′", "g'", "g_d1", "1. Abl."), ("d2", 2, "g″", "g''", "g_d2", "2. Abl."),
            ("d3", 3, "g‴", "g'''", "g_d3", "3. Abl.")]
# Namen je Funktion: Funktion, Stammfunktion, frei verschiebbarer Punkt, Koeffizientenbuchstabe
NAMEN = {"f": {"f": "f", "F": "F", "P": "P", "a": "a"}, "g": {"f": "g", "F": "G", "P": "Q", "a": "b"}}
STANDARD_G = [-2.0, 0.0, 0.5]          # g(x) = x²/2 − 2

# Aktuelle Palette. Wird beim Umschalten an Ort und Stelle aktualisiert, damit alle Module,
# die FARBEN importiert haben, automatisch die neuen Farben sehen.
FARBEN: dict = dict(FARBSCHEMATA["3b1b"])

N_MAX = 20


# --------------------------------------------------------------------------
# Zahlenformat (deutsch, mit Bruchdarstellung für "schöne" rationale Zahlen)
# --------------------------------------------------------------------------
_SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")


def _parse_zahl(s: str) -> float:
    """
    Wertet einen Rechenausdruck sicher aus (ohne eval).
    Erlaubt: Zahlen (Komma oder Punkt, auch 1e-5), + - * · × / : ^, Klammern,
    Fakultät n! (nur für ganze Zahlen 0 … 170).   Wirft ValueError bei Fehlern.
    """
    s = (s.strip().replace(" ", "").replace(",", ".").replace("−", "-")
         .replace("·", "*").replace("×", "*").replace(":", "/").replace("**", "^"))
    if not s:
        return 0.0
    pos = 0

    def sieh():
        return s[pos] if pos < len(s) else ""

    def ausdruck():
        nonlocal pos
        v = term()
        while sieh() in ("+", "-"):
            op = s[pos]; pos += 1
            r = term()
            v = v + r if op == "+" else v - r
        return v

    def term():
        nonlocal pos
        v = vorzeichen()
        while sieh() in ("*", "/"):
            op = s[pos]; pos += 1
            r = vorzeichen()
            if op == "/" and r == 0:
                raise ValueError("Division durch 0")
            v = v * r if op == "*" else v / r
        return v

    def vorzeichen():
        nonlocal pos
        if sieh() == "-":
            pos += 1
            return -vorzeichen()
        if sieh() == "+":
            pos += 1
            return vorzeichen()
        return potenz()

    def potenz():
        nonlocal pos
        basis = fakultaet()
        if sieh() == "^":
            pos += 1
            return float(basis ** vorzeichen())   # rechtsassoziativ
        return basis

    def fakultaet():
        nonlocal pos
        v = einfach()
        while sieh() == "!":
            pos += 1
            if v < 0 or abs(v - round(v)) > 1e-12 or v > 170:
                raise ValueError("Fakultät nur für ganze Zahlen 0 … 170")
            v = float(math.factorial(int(round(v))))
        return v

    def einfach():
        nonlocal pos
        if sieh() == "(":
            pos += 1
            v = ausdruck()
            if sieh() != ")":
                raise ValueError("Klammer fehlt")
            pos += 1
            return v
        m = re.match(r"\d+\.?\d*(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?", s[pos:])
        if not m:
            raise ValueError(f"Unerwartetes Zeichen an Stelle {pos + 1}")
        pos += len(m.group())
        return float(m.group())

    v = ausdruck()
    if pos != len(s) or not math.isfinite(v):
        raise ValueError("Ungültiger Ausdruck")
    return v


def _als_bruch(v: float, max_nenner: int = 12):
    if v == 0:
        return Fraction(0)
    if abs(v) >= 1e9:
        return None
    f = Fraction(v).limit_denominator(max_nenner)
    if f != 0 and abs(float(f) - v) < 1e-9 * abs(v):
        return f
    return None


def _als_fak_bruch(v: float):
    """Erkennt v = p / k!  (k = 4 … 20, p ganz, teilerfremd zu k!, |p| < 100). Rückgabe (p, k) oder None."""
    if v == 0:
        return None
    for k in range(4, N_MAX + 1):
        q = math.factorial(k)
        p = round(v * q)
        if p != 0 and abs(p) < 100 and math.gcd(abs(p), q) == 1 and abs(p / q - v) <= 1e-9 * abs(v):
            return p, k
    return None


def _wiss(v: float):
    """Mantisse und Exponent für sehr kleine/große Zahlen."""
    e = int(np.floor(np.log10(abs(v))))
    m = v / 10 ** e
    if round(abs(m), 2) >= 10:
        m, e = m / 10, e + 1
    return m, e


def _dez(v: float, stellen: int = 3) -> str:
    v = float(v)
    if v != 0 and (abs(v) < 1e-4 or abs(v) >= 1e9):      # wissenschaftliche Schreibweise
        m, e = _wiss(v)
        return f"{_dez(m, 2)}·10{str(e).translate(_SUP)}"
    if 0 < abs(v) < 10 ** (-stellen + 1):  # kleine Zahlen: 3 gültige Ziffern
        stellen = min(int(-np.floor(np.log10(abs(v)))) + 2, 12)
    v = round(v, stellen) + 0.0  # -0.0 vermeiden
    s = f"{v:.{stellen}f}".rstrip("0").rstrip(".")
    return s.replace(".", ",") if s not in ("", "-") else "0"


def _zahl_text(v: float) -> str:
    """Zahl für Eingabefelder: Bruch (auch p/k!) wenn möglich, sonst Dezimalzahl."""
    f = _als_bruch(v)
    if f is not None:
        return str(f.numerator) if f.denominator == 1 else f"{f.numerator}/{f.denominator}"
    pk = _als_fak_bruch(v)
    if pk is not None:
        return f"{pk[0]}/{pk[1]}!"
    if v != 0 and (abs(v) < 1e-4 or abs(v) >= 1e9):
        return f"{v:.5g}".replace(".", ",")
    return _dez(v, 4)


def _zahl_tex(betrag: float) -> str:
    f = _als_bruch(betrag)
    if f is not None and f.denominator != 1:
        return rf"\frac{{{f.numerator}}}{{{f.denominator}}}"
    pk = _als_fak_bruch(betrag) if f is None else None
    if pk is not None:
        return rf"\frac{{{pk[0]}}}{{{pk[1]}!}}"
    if f is None and betrag != 0 and (abs(betrag) < 1e-4 or abs(betrag) >= 1e9):
        m, e = _wiss(betrag)
        return rf"{_dez(m, 2).replace(',', '{,}')}\cdot 10^{{{e}}}"
    if f is not None:
        return str(f.numerator)
    return _dez(betrag, 3).replace(",", "{,}")


def polynom_tex(c: Iterable[float], name: str = "f", terme_pro_zeile: int = 6) -> list[str]:
    """Polynomterm als Liste von Mathtext-Zeilen (absteigende Potenzen)."""
    c = list(c)
    terme = []
    for i in range(len(c) - 1, -1, -1):
        a = float(c[i])
        if a == 0:
            continue
        vz = "-" if a < 0 else "+"
        betrag = abs(a)
        zahl = _zahl_tex(betrag)
        if zahl == "1" and i > 0:
            zahl = ""
        pot = "" if i == 0 else ("x" if i == 1 else f"x^{{{i}}}")
        terme.append((vz, zahl + pot))
    if not terme:
        terme = [("+", "0")]
    zeilen, akt = [], []
    for k, (vz, t) in enumerate(terme):
        if k == 0:
            akt.append(("-" if vz == "-" else "") + t)
        else:
            akt.append(f" {vz} {t}")
        if len(akt) == terme_pro_zeile and k < len(terme) - 1:
            zeilen.append("".join(akt))
            akt = []
    zeilen.append("".join(akt))
    out = [rf"${name}(x) = {zeilen[0]}$"]
    out += [rf"$\qquad\quad {z}$" for z in zeilen[1:]]
    return out


# --------------------------------------------------------------------------
# Mathematischer Kern (ohne Grafik nutzbar)
# --------------------------------------------------------------------------
def _trim(c) -> np.ndarray:
    c = np.asarray(c, dtype=float).copy()
    while len(c) > 1 and c[-1] == 0:
        c = c[:-1]
    return c


def _reelle_nullstellen(c) -> list[float]:
    """Reelle Nullstellen (mehrfache werden zusammengefasst)."""
    c = _trim(c)
    if len(c) == 1:
        return []
    kandidaten = []
    for z in np.roots(c[::-1]):
        if abs(z.imag) < 1e-3 * max(1.0, abs(z)):
            x = z.real
            skala = np.sum(np.abs(c) * np.abs(x) ** np.arange(len(c)))
            if abs(z.imag) < 1e-10 or abs(P.polyval(x, c)) <= 1e-7 * max(skala, 1e-300):
                kandidaten.append(x)
    kandidaten.sort()
    gruppen: list[list[float]] = []
    for x in kandidaten:
        if gruppen and abs(x - gruppen[-1][-1]) < 1e-4 * (1 + abs(x)):
            gruppen[-1].append(x)
        else:
            gruppen.append([x])
    res = [float(np.mean(g)) + 0.0 for g in gruppen]
    schranke = max([1.0] + [abs(x) for x in res])
    return [0.0 if abs(x) < 1e-12 * schranke else x for x in res]     # Rundungsreste wie 2,6·10⁻¹⁷ -> 0


def _vorzeichen_links_rechts(c, x, alle):
    abst = [abs(x - y) for y in alle if y != x]
    eps = max(min(min(abst) / 2 if abst else 1.0, 1e-2), 1e-6)
    return np.sign(P.polyval(x - eps, c)), np.sign(P.polyval(x + eps, c))


def analysiere(koeffizienten, a: float | None = None, b: float | None = None) -> dict:
    """
    Kurvendiskussion eines Polynoms.

    koeffizienten : a0, a1, …, an  (aufsteigend, f(x) = Σ ai·x^i)
    a, b          : optionale Integrationsgrenzen

    Rückgabe (dict):
      nullstellen : [x, …]
      extrema     : [(x, y, "Hochpunkt"|"Tiefpunkt"), …]
      sattelpunkte: [(x, y), …]
      wendepunkte : [(x, y), …]
      integral    : ∫_a^b f(x) dx   (oder None)
      flaeche     : Flächeninhalt zwischen Graph und x-Achse auf [a, b] (oder None)
      ableitung1/2: Koeffizienten von f', f''
    """
    c = _trim(koeffizienten)
    d1 = P.polyder(c) if len(c) > 1 else np.array([0.0])
    d2 = P.polyder(d1) if len(d1) > 1 else np.array([0.0])
    f = lambda x: float(P.polyval(x, c)) + 0.0

    null = _reelle_nullstellen(c) if np.any(c != 0) else []

    krit = _reelle_nullstellen(d1) if np.any(d1 != 0) else []
    extrema, sattel = [], []
    for x in krit:
        l, r = _vorzeichen_links_rechts(d1, x, krit)
        if l > 0 > r:
            extrema.append((x, f(x), "Hochpunkt"))
        elif l < 0 < r:
            extrema.append((x, f(x), "Tiefpunkt"))
        else:
            sattel.append((x, f(x)))

    w_kand = _reelle_nullstellen(d2) if np.any(d2 != 0) else []
    wende = []
    for x in w_kand:
        l, r = _vorzeichen_links_rechts(d2, x, w_kand)
        if l * r < 0:
            wende.append((x, f(x)))

    integral = flaeche = None
    if a is not None and b is not None:
        F = P.polyint(c)
        integral = float(P.polyval(b, F) - P.polyval(a, F))
        lo, hi = min(a, b), max(a, b)
        grenzen = [lo] + [x for x in null if lo < x < hi] + [hi]
        flaeche = float(sum(abs(P.polyval(q, F) - P.polyval(p, F))
                            for p, q in zip(grenzen[:-1], grenzen[1:])))

    return {
        "koeffizienten": c.tolist(),
        "grad": len(c) - 1,
        "nullstellen": null,
        "extrema": extrema,
        "sattelpunkte": sattel,
        "wendepunkte": wende,
        "integral": integral,
        "flaeche": flaeche,
        "ableitung1": d1.tolist(),
        "ableitung2": d2.tolist(),
    }


def tangente(koeffizienten, x0: float) -> dict:
    """Tangente in x0:  t(x) = m·x + n  mit  m = f'(x0),  n = f(x0) − m·x0."""
    c = np.asarray(koeffizienten, dtype=float)
    y0 = float(P.polyval(x0, c)) + 0.0
    m = float(P.polyval(x0, P.polyder(c))) + 0.0 if len(c) > 1 else 0.0
    return {"x0": float(x0), "y0": y0, "m": m, "n": y0 - m * x0 + 0.0}


def tangenten(koeffizienten, erg: dict | None = None) -> list[dict]:
    """
    Tangenten an allen Hoch-, Tief-, Wende- und Sattelpunkten.
    Rückgabe: Liste von dicts mit typ ("H", "T", "W", "S"), nr, x0, y0, m, n.
    Sattelpunkte sind Wendepunkte mit waagerechter Tangente und erhalten den Typ "S".
    """
    if erg is None:
        erg = analysiere(koeffizienten)
    out, zaehler = [], {"H": 0, "T": 0, "W": 0, "S": 0}
    for x, _y, typ in erg["extrema"]:
        t = tangente(koeffizienten, x)
        t["m"], t["n"] = 0.0, t["y0"]
        k = typ[0]
        zaehler[k] += 1
        out.append({"typ": k, "nr": zaehler[k], **t})
    for x, _y in erg["wendepunkte"]:
        sattel = any(abs(sx - x) < 1e-6 * (1 + abs(x)) for sx, _ in erg["sattelpunkte"])
        t = tangente(koeffizienten, x)
        if sattel:
            t["m"], t["n"] = 0.0, t["y0"]
        k = "S" if sattel else "W"
        zaehler[k] += 1
        out.append({"typ": k, "nr": zaehler[k], **t})
    return out


def gerade_tex(t: dict) -> str:
    """Tangentengleichung als Mathtext, z. B.  $t_{W_{1}}(x) = -\\frac{16}{5}x + 2$."""
    name = t.get("name") or rf"t_{{{t['typ']}_{{{t['nr']}}}}}"
    if t.get("existiert") is False:
        return rf"${name}$: keine Tangente (Knick)"
    if t.get("senkrecht"):
        x0 = t["x0"]
        return rf"${name}\colon\; x = {('-' if x0 < 0 else '') + _zahl_tex(abs(x0)) if x0 != 0 else '0'}$"
    klein = lambda v: abs(v) < 5e-12
    m, n = t["m"], t["n"]
    s = ""
    if not klein(m):
        betrag = abs(m)
        z = _zahl_tex(betrag)
        s = ("-" if m < 0 else "") + ("" if z == "1" else z) + "x"
    if not klein(n):
        s = (s + (" - " if n < 0 else " + ") + _zahl_tex(abs(n))) if s else ("-" if n < 0 else "") + _zahl_tex(abs(n))
    return rf"${name}(x) = {s or '0'}$"


# --------------------------------------------------------------------------
# Riemann-Summen: Ober-, Unter-, Trapez- und Mittensumme (identisch zu Summen.berechne im Browser)
# --------------------------------------------------------------------------
SUMMEN_ARTEN = {"ober": "Obersumme", "unter": "Untersumme", "trapez": "Trapezsumme", "mitte": "Mittensumme"}
SUMMEN_ZEICHEN = {"ober": "O", "unter": "U", "trapez": "T", "mitte": "M"}
SUMMEN_N_MAX = 1000
_GOLD = (math.sqrt(5) - 1) / 2


def riemann_summe(f, a: float, b: float, n: int, art: str = "ober", kritisch=None) -> dict:
    """
    Riemann-Summe von f über [a; b] mit n gleich breiten Teilintervallen.

    art      : "ober"   – größter Funktionswert je Teilintervall (Rechtecke)
               "unter"  – kleinster Funktionswert je Teilintervall (Rechtecke)
               "trapez" – Trapeze durch die Randpunkte (Höhe = Mittel der Randwerte)
               "mitte"  – Funktionswert in der Intervallmitte (Rechtecke)
    f        : Funktion, die numpy-Arrays verarbeitet (z. B. lambda x: x**2)
    kritisch : mögliche Extremstellen von f (Polynom: Nullstellen von f′) für eine exakte Ober-/Untersumme;
               None = numerisch (je Teilintervall abtasten und mit dem Goldenen Schnitt verfeinern)

    Ist b < a, wird über [b; a] summiert und das Vorzeichen umgekehrt (wie beim Integral).
    Rückgabe: {"art", "name", "zeichen", "n", "a", "b", "dx", "wert", "teile": [{"i", "x0", "x1", "xi", "h",
    ("y0", "y1" bei Trapezen), "wert", "anteil"}, …]};  anteil = wert / Gesamtsumme (nan, wenn die Summe 0 ist).
    Ist f in einem Teilintervall nicht definiert: {…, "fehlt": [x0, x1]} ohne "wert" und "teile".
    """
    if art not in SUMMEN_ARTEN:
        raise ValueError(f"Unbekannte Summe „{art}“ – möglich: {', '.join(SUMMEN_ARTEN)}")
    n = int(math.floor(float(n) + 0.5))
    if not (1 <= n <= SUMMEN_N_MAX):
        raise ValueError(f"n muss zwischen 1 und {SUMMEN_N_MAX} liegen")
    a, b = float(a), float(b)

    def fv(x):
        with np.errstate(all="ignore"):
            return np.asarray(f(np.asarray(x, dtype=float)), dtype=float)

    lo, hi = min(a, b), max(a, b)
    vz = -1.0 if b < a else 1.0
    dx = (hi - lo) / n
    m = max(16, min(400, math.ceil(8000 / n)))
    kopf = {"art": art, "name": SUMMEN_ARTEN[art], "zeichen": SUMMEN_ZEICHEN[art], "n": n, "a": a, "b": b, "dx": dx}
    idx = np.arange(n, dtype=float)
    X0 = lo + dx * idx
    X1 = lo + dx * (idx + 1)
    X1[-1] = hi
    endl = np.isfinite
    teile = []
    if art in ("trapez", "mitte"):
        if art == "trapez":
            Y0, Y1 = fv(X0), fv(X1)
            ok = endl(Y0) & endl(Y1)
        else:
            XM = (X0 + X1) / 2
            YM = fv(XM)
            ok = endl(YM)
        if not ok.all():
            k = int(np.argmin(ok))
            return {**kopf, "fehlt": [float(X0[k]), float(X1[k])]}
        for i in range(n):
            x0, x1 = float(X0[i]), float(X1[i])
            if art == "trapez":
                y0, y1 = float(Y0[i]), float(Y1[i])
                teile.append({"i": i + 1, "x0": x0, "x1": x1, "xi": None, "y0": y0, "y1": y1, "h": (y0 + y1) / 2})
            else:
                teile.append({"i": i + 1, "x0": x0, "x1": x1, "xi": float(XM[i]), "h": float(YM[i])})
    else:
        maximum = art == "ober"
        besser = (lambda p, q: p > q) if maximum else (lambda p, q: p < q)
        if kritisch is not None:                       # exakt: Ränder und kritische Stellen im Inneren
            krit = sorted(float(x) for x in kritisch)
            for i in range(n):
                u, v = float(X0[i]), float(X1[i])
                kand = [u, v] + [x for x in krit if u < x < v]
                ys = fv(np.array(kand))
                if not endl(ys).all():
                    return {**kopf, "fehlt": [u, v]}
                bx, by = u, float(ys[0])
                for x, y in zip(kand[1:], ys[1:]):
                    if besser(float(y), by):
                        bx, by = x, float(y)
                teile.append({"i": i + 1, "x0": u, "x1": v, "xi": bx, "h": by})
        else:                                          # numerisch, für alle Teilintervalle gleichzeitig
            YU, YV = fv(X0), fv(X1)
            J = np.arange(m, dtype=float)
            XS = X0[:, None] + (X1 - X0)[:, None] * J[None, :] / (m - 1)
            YS = fv(XS)
            ok = endl(YU) & endl(YV) & endl(YS).all(axis=1)
            if not ok.all():
                k = int(np.argmin(ok))
                return {**kopf, "fehlt": [float(X0[k]), float(X1[k])]}
            BX, BY = X0.copy(), YU.copy()

            def nimm(x, y):
                neu = endl(y) & besser(y, BY)
                BX[neu], BY[neu] = x[neu], y[neu]
            nimm(X1, YV)
            r = np.arange(n)
            jb = np.argmax(YS, axis=1) if maximum else np.argmin(YS, axis=1)
            nimm(XS[r, jb], YS[r, jb])
            lo_, hi_ = XS[r, np.maximum(jb - 1, 0)], XS[r, np.minimum(jb + 1, m - 1)]
            c, d = hi_ - _GOLD * (hi_ - lo_), lo_ + _GOLD * (hi_ - lo_)
            fc, fd = fv(c), fv(d)
            for _ in range(40):
                with np.errstate(invalid="ignore"):
                    w = besser(fc, fd)
                hi2, lo2 = np.where(w, d, hi_), np.where(w, lo_, c)
                c2 = np.where(w, hi2 - _GOLD * (hi2 - lo2), d)
                d2 = np.where(w, c, lo2 + _GOLD * (hi2 - lo2))
                fneu = fv(np.where(w, c2, d2))
                fc2, fd2 = np.where(w, fneu, fd), np.where(w, fc, fneu)
                lo_, hi_, c, d, fc, fd = lo2, hi2, c2, d2, fc2, fd2
            with np.errstate(invalid="ignore"):
                nimm(c, fc)
                nimm(d, fd)
            for i in range(n):
                teile.append({"i": i + 1, "x0": float(X0[i]), "x1": float(X1[i]), "xi": float(BX[i]), "h": float(BY[i])})
    summe = betrag = 0.0
    for t in teile:
        t["wert"] = vz * t["h"] * (t["x1"] - t["x0"])
        summe += t["wert"]
        betrag += abs(t["wert"])
    null = abs(summe) <= 1e-12 * betrag
    for t in teile:
        t["anteil"] = math.nan if null else t["wert"] / summe
    return {**kopf, "wert": summe, "teile": teile}


def koeffizienten_k(koeffizienten, k: int) -> np.ndarray:
    """Koeffizienten der Stammfunktion (k = −1, mit F(0) = 0) bzw. der k-ten Ableitung (k = 0 … 3 …)."""
    c = np.asarray(koeffizienten, dtype=float)
    if k < 0:
        return _trim(P.polyint(c))
    for _ in range(k):
        c = P.polyder(c) if len(c) > 1 else np.array([0.0])
    return _trim(c)


def polynom_klartext(c) -> str:
    """Polynom als lesbarer Text, z. B. „4/5·x³ − 16/5·x“."""
    teile = []
    for i in range(len(c) - 1, -1, -1):
        a = float(c[i])
        if a == 0:
            continue
        z = _zahl_text(abs(a))
        pot = "" if i == 0 else ("x" if i == 1 else "x" + str(i).translate(_SUP))
        teile.append(("−" if a < 0 else "+", z if i == 0 else (pot if z == "1" else f"{z}·{pot}")))
    if not teile:
        return "0"
    return ("−" if teile[0][0] == "−" else "") + teile[0][1] + "".join(f" {v} {t}" for v, t in teile[1:])


class PolynomTermFehler(ValueError):
    """Ungültiger Polynomterm (Meldung auf Deutsch, mit Stelle)."""


_PT_OPS = {"·": "*", "×": "*", "÷": "/", ":": "/", "−": "-"}
_PT_RE = re.compile(r"\s+|((?:\d+(?:[.,]\d+)?|[.,]\d+)(?:[eE][+-]?\d+)?)|([A-Za-z]+)|([-+*/^()!·×÷:−²³])")


def polynom_aus_term(text: str) -> list[float]:
    """
    Polynomterm -> Koeffizienten a0, a1, … (aufsteigend), z. B. "(x-1)(x+2)²" -> [-4, 0, 3, 1].
    Erlaubt: Zahlen (Komma oder Punkt), x, + − · * / : ^ ** ² ³, Klammern, implizite Multiplikation,
    n! für Zahlen. Geteilt wird nur durch Zahlen; höchstens Grad 20 (wie PolyTerm.parse im Browser).
    """
    s = str(text).replace("**", "^")
    t, pos = [], 0
    while pos < len(s):
        m = _PT_RE.match(s, pos)
        if not m or m.end() == pos:
            raise PolynomTermFehler(f"Unbekanntes Zeichen „{s[pos]}“ an Stelle {pos + 1}")
        if m.group(1) is not None:
            t.append(("zahl", float(m.group(1).replace(",", ".")), pos))
        elif m.group(2) is not None:
            if m.group(2).lower() != "x":
                raise PolynomTermFehler(f"„{m.group(2)}“ ist hier nicht erlaubt – nur Polynome aus x, Zahlen, "
                                        f"+ − · / ^ und Klammern (Stelle {pos + 1})")
            t.append(("x", 0, pos))
        elif m.group(3) is not None:
            t.append(("op", _PT_OPS.get(m.group(3), m.group(3)), pos))
        pos = m.end()
    t.append(("ende", 0, len(s)))
    i = 0

    def trim(p):
        p = list(p)
        while len(p) > 1 and p[-1] == 0:
            p.pop()
        return p

    def add(p, q, v):
        return [(p[k] if k < len(p) else 0) + v * (q[k] if k < len(q) else 0) for k in range(max(len(p), len(q)))]

    def mul(p, q):
        r = [0.0] * (len(p) + len(q) - 1)
        for k, x in enumerate(p):
            for j, y in enumerate(q):
                r[k + j] += x * y
        return r

    def ist(o):
        return t[i][0] == "op" and t[i][1] == o

    def fehler(msg):
        raise PolynomTermFehler(f"{msg} (Stelle {t[i][2] + 1})")

    def pruefe(p):
        if len(trim(p)) - 1 > N_MAX:
            raise PolynomTermFehler(f"Höchstens Grad {N_MAX} erlaubt.")
        return p

    def zahl_oder(p, msg):
        q = trim(p)
        if len(q) > 1:
            fehler(msg)
        return q[0]

    def ausdruck():
        nonlocal i
        p = term()
        while ist("+") or ist("-"):
            o = t[i][1]
            i += 1
            p = add(p, term(), 1 if o == "+" else -1)
        return p

    def startet_faktor():
        return t[i][0] in ("zahl", "x") or ist("(")

    def term():
        nonlocal i
        p = vorz()
        while True:
            if ist("*"):
                i += 1
                p = pruefe(mul(p, vorz()))
            elif ist("/"):
                i += 1
                d = zahl_oder(vorz(), "Geteilt werden darf nur durch Zahlen (sonst kein Polynom)")
                if d == 0:
                    fehler("Division durch 0")
                p = [a / d for a in p]
            elif startet_faktor():
                p = pruefe(mul(p, potenz()))
            else:
                return p

    def vorz():
        nonlocal i
        if ist("-"):
            i += 1
            return [-a for a in vorz()]
        if ist("+"):
            i += 1
            return vorz()
        return potenz()

    def potenz():
        nonlocal i
        b = postfix()
        if not ist("^"):
            return b
        i += 1
        e = zahl_oder(vorz(), "Der Exponent muss eine natürliche Zahl sein")
        if not (e >= 0) or e != math.floor(e):
            fehler("Der Exponent muss eine natürliche Zahl sein")
        if (len(trim(b)) - 1) * e > N_MAX:
            raise PolynomTermFehler(f"Höchstens Grad {N_MAX} erlaubt.")
        r = [1.0]
        for _ in range(int(e)):
            r = mul(r, b)
        return r

    def postfix():
        nonlocal i
        p = primaer()
        while True:
            if ist("!"):
                i += 1
                v = zahl_oder(p, "Fakultät nur für natürliche Zahlen")
                if v < 0 or v != math.floor(v) or v > 170:
                    fehler("Fakultät nur für natürliche Zahlen")
                p = [float(math.factorial(int(v)))]
            elif ist("²") or ist("³"):
                e = 2 if t[i][1] == "²" else 3
                i += 1
                r = [1.0]
                for _ in range(e):
                    r = pruefe(mul(r, p))
                p = r
            else:
                return p

    def primaer():
        nonlocal i
        art, w, _ = t[i]
        if art == "zahl":
            i += 1
            return [w]
        if art == "x":
            i += 1
            return [0.0, 1.0]
        if ist("("):
            i += 1
            p = ausdruck()
            if not ist(")"):
                fehler("Schließende Klammer „)“ fehlt")
            i += 1
            return p
        if art == "ende":
            fehler("Term endet unerwartet")
        fehler(f"Unerwartetes „{w}“")

    if t[0][0] == "ende":
        raise PolynomTermFehler("Der Term ist leer.")
    p = ausdruck()
    if t[i][0] != "ende":
        fehler(f"Unerwartetes „{t[i][1]}“")
    return [float(a) + 0.0 for a in trim(p)]


def polynom_term_text(c) -> str:
    """Koeffizienten -> Term zum Eintippen, z. B. „4/5·x^3 - 16/5·x“ (Gegenstück zu polynom_aus_term)."""
    teile = []
    for i in range(len(c) - 1, -1, -1):
        a = float(c[i])
        if a == 0:
            continue
        z = _zahl_text(abs(a))
        pot = "" if i == 0 else ("x" if i == 1 else f"x^{i}")
        teile.append(("-" if a < 0 else "+", z if i == 0 else (pot if z == "1" else f"{z}·{pot}")))
    if not teile:
        return "0"
    return ("-" if teile[0][0] == "-" else "") + teile[0][1] + "".join(f" {v} {t}" for v, t in teile[1:])


def _gerade_text(m: float, n: float) -> str:
    """Geradengleichung als Text, z. B. „−0,5x + 1“ (wie geradeText im Browser)."""
    klein = lambda v: abs(v) < 5e-12
    t = ""
    if not klein(m):
        t = ("−" if m < 0 else "") + ("" if _dez(abs(m), 2) == "1" else _dez(abs(m), 2)) + "x"
    if not klein(n):
        t = t + (" − " if n < 0 else " + ") + _dez(abs(n), 2) if t else _dez(n, 2)
    return t or "0"


def standard_polynom(n: int) -> list[float]:
    """Gut sichtbares Beispielpolynom vom Grad n (symmetrisch verteilte Nullstellen)."""
    n = int(n)
    if n == 0:
        return [2.0]
    if n == 1:
        return [1.0, 0.5]
    r = {2: 1.5, 3: 2.0, 4: 2.5}.get(n, 3.0)
    wurzeln = np.linspace(-r, r, n)
    c = P.polyfromroots(wurzeln)
    xs = np.linspace(wurzeln[0], wurzeln[-1], 800)
    k = 2.5 / np.max(np.abs(P.polyval(xs, c)))
    expo = np.floor(np.log10(k))
    k = round(k / 10 ** expo) * 10 ** expo  # "runder" Leitkoeffizient
    c = c * k
    c[np.abs(c) < 1e-12 * np.max(np.abs(c))] = 0.0   # Rundungsreste (z. B. 1e-17) entfernen
    return c.tolist()


# --------------------------------------------------------------------------
# Interaktive Grafik
# --------------------------------------------------------------------------
class PolynomExplorer:
    """
    Interaktives Fenster mit zwei Funktionen f und g. Kann in jedes Python-Programm eingebunden werden.

    Jede Funktion hat ihren eigenen Zustand (Koeffizienten, Stützpunkte, Punkt P bzw. Q, Funktionsleiste …).
    Die Routinen arbeiten auf dem „geladenen“ Zustand (Attribute c, n, stuetz_x, …); _lade(k) wechselt
    zwischen f und g. Außerhalb einer Berechnung ist immer die bearbeitete Funktion (self.akt) geladen.
    """

    # Attribute, die je Funktion getrennt gespeichert werden (dazu zeige["t_frei"] = Punkt P bzw. Q an)
    _FN_FELDER = ("c", "n", "stuetz_x", "stuetz_y", "t_x", "_tp", "_tang", "_kv", "kd", "erg")

    def __init__(self, koeffizienten=None, grad: int = 3, fig=None,
                 untere_grenze: float = -1.0, obere_grenze: float = 1.0,
                 x_bereich=(-6.5, 6.5), y_bereich=(-4.0, 4.0),
                 on_change: Callable[[dict, dict], None] | None = None, design: str | None = None,
                 kurven: dict | None = None, koeffizienten_g=None, kurven_g: dict | None = None):
        matplotlib.rcParams["mathtext.fontset"] = "cm"
        if design is not None:
            if design not in FARBSCHEMATA:
                raise ValueError(f"Unbekanntes Design „{design}“ – möglich: {', '.join(FARBSCHEMATA)}")
            FARBEN.update(FARBSCHEMATA[design])
        self.design = next((k for k, v in FARBSCHEMATA.items() if v["hintergrund"] == FARBEN["hintergrund"]), "3b1b")
        self._neutrale_knoepfe: list = []
        self.a, self.b = float(untere_grenze), float(obere_grenze)
        self.xlim, self.ylim = list(x_bereich), list(y_bereich)
        self.on_change = on_change
        # Beim Start ist nur der Graph von f zu sehen; alles Weitere wird über die Knöpfe eingeblendet
        self.zeige = {"nullstellen": False, "extrema": False, "wende": False, "integral": False, "stuetz": False, "trace": False, "schnitt": False, "yachse": False,
                      "t_hoch": False, "t_tief": False, "t_wende": False, "t_frei": False, "sekante": False,
                      # Riemann-Summen (höchstens eine eingeschaltet): Obersumme, Untersumme, Trapezsumme, Mittensumme
                      "s_ober": False, "s_unter": False, "s_trapez": False, "s_mitte": False}
        self.summe_n = 8                        # Anzahl der gleich breiten Teilintervalle
        self._summe = None                      # berechnete Summe der bearbeiteten Funktion
        self._sum_hover = None                  # Index des Rechtecks/Trapezes unter dem Mauszeiger
        self._sum_patches = None                # PolyCollection der Rechtecke/Trapeze
        self._sum_tip = None
        self._sum_meldung = ""
        self._trace = {"x": 0.0, "spur": {}}   # Trace-Modus; spur: "f:d1" -> überstrichene x-Intervalle
        self._tr_meldung = ""
        self._timer = None
        self._spielt = False
        self._schnitte: list = []
        self.sek = {"xA": -1.0, "xB": 1.0}      # Sekante durch A und B (gehört zur bearbeiteten Funktion)
        self._sk = None
        self._sek_meldung = ""
        self._sperre = False
        self._drag = None
        self._p_meldung = ""
        self._status_fehler = ""
        # Zustände von g und f anlegen (f zuletzt, f bleibt geladen)
        self._fn: dict[str, dict] = {"f": {}, "g": {}}
        self.akt = "f"
        if koeffizienten is None:
            koeffizienten = standard_polynom(grad)
        kv_f = {"F": False, "f": True, "d1": False, "d2": False, "d3": False}
        kv_f.update({k: bool(v) for k, v in (kurven or {}).items() if k in kv_f})
        kv_g = {"F": False, "f": False, "d1": False, "d2": False, "d3": False}
        kv_g.update({k: bool(v) for k, v in (kurven_g or {}).items() if k in kv_g})
        for k, c, kv in (("g", STANDARD_G if koeffizienten_g is None else koeffizienten_g, kv_g),
                         ("f", koeffizienten, kv_f)):
            self._geladen = k
            self._fn_anlegen(k, c, kv)
            self._fn[k] = {p: getattr(self, p) for p in self._FN_FELDER}
            self._fn[k]["t_frei"] = False

        self.fig = fig if fig is not None else plt.figure(figsize=(15, 8.6))
        try:
            self.fig.canvas.manager.set_window_title("Polynom-Explorer")
        except Exception:
            pass
        self.fig.patch.set_facecolor(FARBEN["figur"])
        self._baue_oberflaeche()
        self._verbinde_maus()
        self.aktualisiere()

    # ------------------------------------------------------------ zwei Funktionen f und g
    def _fn_anlegen(self, k: str, c, kurven: dict) -> None:
        """Zustand einer Funktion anlegen (abgeleitete Explorer setzen hier zusätzlich ihren Term)."""
        c = np.asarray(c, dtype=float)
        if len(c) > N_MAX + 1:
            raise ValueError(f"Höchstens Grad {N_MAX} erlaubt.")
        self.c, self.n = c, len(c) - 1
        self.t_x = 1.0                 # x-Stelle des frei verschiebbaren Tangentenpunkts P bzw. Q
        self._tp, self._tang, self.kd, self.erg = None, [], [], None
        self._kv = kurven              # Funktionsleiste: welche Kurven eingeblendet sind (F, f, f′, f″, f‴)
        self._stuetz_verteilen()

    def _lade(self, k: str) -> None:
        if k not in NAMEN:
            raise ValueError(f"Unbekannte Funktion „{k}“ – möglich: f, g")
        if k == self._geladen:
            return
        alt = self._fn[self._geladen]
        for p in self._FN_FELDER:
            alt[p] = getattr(self, p)
        alt["t_frei"] = self.zeige["t_frei"]
        neu = self._fn[k]
        for p in self._FN_FELDER:
            setattr(self, p, neu[p])
        self.zeige["t_frei"] = neu["t_frei"]
        self._geladen = k

    @contextmanager
    def _mit(self, k: str):
        """Funktion k vorübergehend laden:  with self._mit("g"): …"""
        vorher = self._geladen
        self._lade(k)
        try:
            yield
        finally:
            self._lade(vorher)

    @property
    def _nm(self) -> dict:
        return NAMEN[self._geladen]

    def _kurven_liste(self):
        return KURVEN if self._geladen == "f" else KURVEN_G

    def _g_sichtbar(self) -> bool:
        with self._mit("g"):
            return any(self._kv.values())

    # ------------------------------------------------------------ public API (fn = "f" oder "g")
    @property
    def koeffizienten(self) -> list[float]:
        with self._mit("f"):
            return self.c.tolist()

    @property
    def koeffizienten_g(self) -> list[float]:
        with self._mit("g"):
            return self.c.tolist()

    def set_koeffizienten(self, koeffizienten, fn: str = "f") -> None:
        c = np.asarray(koeffizienten, dtype=float)
        if len(c) > N_MAX + 1:
            raise ValueError(f"Höchstens Grad {N_MAX} erlaubt.")
        with self._mit(fn):
            self.c = c
            if len(c) - 1 != self.n:
                self.n = len(c) - 1
                self._stuetz_verteilen()
            else:
                self.stuetz_y = P.polyval(self.stuetz_x, self.c)
            self._polynom_geaendert()
        self.aktualisiere()

    @property
    def term(self) -> str:
        with self._mit("f"):
            return self._term_text()

    @property
    def term_g(self) -> str:
        with self._mit("g"):
            return self._term_text()

    def set_term(self, text: str, fn: str = "f") -> None:
        """Funktionsterm setzen, z. B. set_term("(x-1)(x+2)²", "g") (wirft ValueError bei ungültigem Term)."""
        with self._mit(fn):
            self._term_setzen(text)
        self._termfeld_setzen(text, fn)
        self.aktualisiere()

    def set_grenzen(self, a: float, b: float) -> None:
        self.a, self.b = float(a), float(b)
        self.aktualisiere()

    def analyse(self, fn: str = "f") -> dict:
        with self._mit(fn):
            return self._analyse()

    def bearbeite(self, fn: str) -> None:
        """Wählt, ob Grad, Koeffizienten und Punkt P/Q zu f oder g gehören (wie „Bearbeiten: f | g“)."""
        self._setze_akt(fn)

    @property
    def bearbeitet(self) -> str:
        return self.akt

    def zeige_fenster(self, block: bool = True) -> None:
        plt.show(block=block)

    def set_design(self, design: str) -> None:
        """Darstellung wechseln: "3b1b" (3Blue1Brown, dunkel) oder "pearson" (Pearson-Schulbuch, hell)."""
        if design not in FARBSCHEMATA:
            raise ValueError(f"Unbekanntes Design „{design}“ – möglich: {', '.join(FARBSCHEMATA)}")
        alt = dict(FARBEN)
        FARBEN.update(FARBSCHEMATA[design])
        self.design = design
        self._design_anwenden(alt)
        self.aktualisiere()

    def design_wechseln(self) -> str:
        """Zwischen den beiden Darstellungen umschalten; gibt das neue Design zurück."""
        self.set_design("pearson" if self.design == "3b1b" else "3b1b")
        return self.design

    def zeige_kurven(self, fn: str = "f", **wahl) -> None:
        """Funktionsleiste programmgesteuert schalten, z. B. zeige_kurven(F=True, d1=True, f=False)
        oder für g: zeige_kurven("g", f=True, d1=True). Schlüssel: F (Stammfunktion), f, d1, d2, d3."""
        with self._mit(fn):
            for k, v in wahl.items():
                if k not in self._kv:
                    raise ValueError(f"Unbekannte Kurve „{k}“ – möglich: {', '.join(self._kv)}")
                war, self._kv[k] = self._kv[k], bool(v)
                if war != self._kv[k]:
                    self._spur_schalten(fn, k, self._kv[k])
        self._kurven_knoepfe_stil()
        self.aktualisiere()

    @property
    def kurven(self) -> dict:
        with self._mit("f"):
            return dict(self._kv)

    @property
    def kurven_g(self) -> dict:
        with self._mit("g"):
            return dict(self._kv)

    def analyse_kurven(self, fn: str = "f") -> dict:
        """Analyse aller eingeblendeten Kurven einer Funktion: {"F": {…}, "f": {…}, "d1": {…}, …}."""
        with self._mit(fn):
            return {d["schl"]: d["erg"] for d in self._kurven_daten(True, self._analyse())}

    def zeige_tangenten(self, hoch: bool | None = None, tief: bool | None = None, wende: bool | None = None,
                        frei: bool | None = None, fn: str | None = None):
        """Tangenten ein-/ausblenden (None = unverändert). hoch/tief/wende gelten für f und g;
        frei = Tangente im Punkt P (an f) bzw. Q (an g) der Funktion fn (Standard: die bearbeitete)."""
        for schl, wert in (("t_hoch", hoch), ("t_tief", tief), ("t_wende", wende)):
            if wert is not None:
                self.zeige[schl] = bool(wert)
        if frei is not None:
            with self._mit(fn or self.akt):
                if frei and not self.zeige["t_frei"]:
                    self._p_sichtbar_machen()
                self.zeige["t_frei"] = bool(frei)
        self._schalter_stil()
        self.aktualisiere()

    def tangenten_von(self, fn: str = "f") -> list[dict]:
        with self._mit(fn):
            return list(self._tang or [])

    @property
    def tangenten(self) -> list[dict]:
        """Tangenten an Hoch-, Tief-, Wende- und Sattelpunkten von f."""
        return self.tangenten_von("f")

    @property
    def tangente_p(self):
        with self._mit("f"):
            return dict(self._tp) if self._tp else None

    @property
    def tangente_q(self):
        with self._mit("g"):
            return dict(self._tp) if self._tp else None

    def zeige_eigenschaften(self, **wahl) -> None:
        """Anzeigen ein-/ausblenden, z. B. zeige_eigenschaften(nullstellen=True, extrema=True, stuetz=True).
        Schlüssel: nullstellen, extrema, wende, integral, stuetz (Punkte zum Verformen des Graphen),
        schnitt (Schnittpunkte der Graphen), yachse (y-Achsenabschnitte)."""
        for k, v in wahl.items():
            if k not in ("nullstellen", "extrema", "wende", "integral", "stuetz", "schnitt", "yachse"):
                raise ValueError(f"Unbekannte Anzeige „{k}“ – möglich: nullstellen, extrema, wende, integral, stuetz, "
                                 "schnitt, yachse")
            self.zeige[k] = bool(v)
        self._schalter_stil()
        self.aktualisiere()

    def zeige_stuetzpunkte(self, an: bool = True) -> None:
        """Punkte zum Verformen des Graphen (Stützpunkte) ein-/ausblenden."""
        self.zeige_eigenschaften(stuetz=an)

    @property
    def anzeigen(self) -> dict:
        return {k: self.zeige[k] for k in ("nullstellen", "extrema", "wende", "integral", "stuetz", "schnitt", "yachse")}

    def abspielen(self) -> None:
        """Trace-Punkt gleichmäßig nach rechts laufen lassen (ganze Bildbreite in 8 s)."""
        self._abspielen(True)

    def anhalten(self) -> None:
        self._abspielen(False)

    @property
    def spielt(self) -> bool:
        return self._spielt

    @property
    def schnittpunkte(self) -> list[dict]:
        """Schnittpunkte aller sichtbaren Graphen: [{"x", "y", "a", "b"}, …] (a, b = Kurvennamen)."""
        return [{"x": q["x"], "y": q["y"], "a": q["A"]["name"], "b": q["B"]["name"]} for q in self._schnittpunkte_berechnen()]

    @property
    def y_abschnitte(self) -> list[dict]:
        """Schnittpunkte aller sichtbaren Graphen mit der y-Achse: [{"kurve", "y"}, …]."""
        return [{"kurve": d["name"], "y": y} for d, y in self._y_abschnitte_berechnen()]

    def zeige_trace(self, an: bool = True) -> None:
        """Trace-Modus ein-/ausschalten (Startpunkt unten links im Grafikfenster)."""
        self.zeige["trace"] = bool(an)
        self._trace["spur"] = {}
        if an:
            self._trace_platzieren()
        self._schalter_stil()
        self.aktualisiere()

    def set_trace_x(self, x: float) -> None:
        """Trace-Punkt an die Stelle x bewegen (Spur-Kurven wachsen mit)."""
        if not self.zeige["trace"]:
            self.zeige["trace"] = True
            self._trace["spur"] = {}
            self._schalter_stil()
        self._trace_setzen(float(x))
        self.aktualisiere()

    @property
    def trace(self):
        """{"x", "werte": {"f": …, "f′": …}, "spur": {"f:d1": [[a, b], …]}} (None, wenn der Trace-Modus aus ist)."""
        if not self.zeige["trace"]:
            return None
        return {"x": self._trace["x"], "werte": {d["name"]: y for d, y in self._trace_werte()},
                "spur": {k: [list(i) for i in v] for k, v in self._trace["spur"].items()}}

    @trace.setter
    def trace(self, wert):
        self._trace = wert

    def zeige_summe(self, art: str | None = "ober", n: int | None = None) -> None:
        """Riemann-Summe der bearbeiteten Funktion einblenden: art = "ober", "unter", "trapez", "mitte"
        oder None (ausblenden); n = Anzahl der gleich breiten Teilintervalle (1 … 1000)."""
        if art is not None and art not in SUMMEN_ARTEN:
            raise ValueError(f"Unbekannte Summe „{art}“ – möglich: {', '.join(SUMMEN_ARTEN)}")
        if n is not None:
            self._n_setzen(n)
        for k in SUMMEN_ARTEN:
            self.zeige["s_" + k] = k == art
        self._sum_hover = None
        self._schalter_stil()
        self.aktualisiere()

    def set_teilintervalle(self, n: int) -> None:
        """Anzahl der Teilintervalle für die Summen setzen (1 … 1000)."""
        self._n_setzen(n)
        self.aktualisiere()

    @property
    def summe_art(self):
        """Eingeblendete Summe ("ober", "unter", "trapez", "mitte") oder None."""
        return next((k for k in SUMMEN_ARTEN if self.zeige["s_" + k]), None)

    @property
    def summe(self):
        """Eingeblendete Summe der bearbeiteten Funktion: {"art", "name", "zeichen", "n", "a", "b", "dx", "wert",
        "integral", "fn", "teile": [{"i", "x0", "x1", "xi", "h", "wert", "anteil"}, …]} oder None."""
        s = self._summe_berechnen()
        if s is None:
            return None
        return {**s, "teile": [dict(t) for t in s.get("teile", [])]} if "teile" in s else dict(s)

    @property
    def svg_dateiname(self) -> str:
        """Dateiname (ohne .svg) aus den eingeblendeten Kurven und den aktiven Eigenschaften,
        z. B. "f_g'_Extrema_Tangente-Hochpunkte_Sekante"."""
        striche = lambda t: t.replace("‴", "'''").replace("″", "''").replace("′", "'")
        kurven = []
        for k in ("f", "g"):
            with self._mit(k):
                kurven += [striche(name) for schl, _k, name, *_ in self._kurven_liste() if self._kv[schl]]
        z = self.zeige
        e = [t for schl, t in (("nullstellen", "Nullstellen"), ("extrema", "Extrema"), ("wende", "Wendepunkte"),
                               ("integral", "Integral"), ("schnitt", "Schnittpunkte"), ("yachse", "y-Achsenabschnitte"),
                               ("t_hoch", "Tangente-Hochpunkte"), ("t_tief", "Tangente-Tiefpunkte"),
                               ("t_wende", "Tangente-Wendepunkte")) if z[schl]]
        for k in ("f", "g"):
            with self._mit(k):
                if self.zeige["t_frei"]:
                    e.append("Tangente-" + NAMEN[k]["P"])
        if z["sekante"]:
            e.append("Sekante")
        if self.summe_art:
            e.append(f"{SUMMEN_ARTEN[self.summe_art]}-n{self.summe_n}")
        if z["trace"]:
            e.append("Trace")
        if z["stuetz"]:
            e.append("Verformungspunkte")
        name = "_".join((kurven or [NAMEN[self.akt]["f"]]) + e)
        return re.sub(r'[\\/:*?"<>|\s]+', "-", name)[:200]

    def speichere_svg(self, pfad: str | None = None) -> str:
        """Inhalt des Grafikfensters (Koordinatensystem mit allem Eingeblendeten) als Vektorgrafik speichern.
        Ohne pfad: im aktuellen Ordner unter svg_dateiname + ".svg". Gibt den Pfad zurück."""
        if pfad is None:
            pfad = os.path.join(os.getcwd(), self.svg_dateiname + ".svg")
        tip = self._sum_tip.get_visible() if self._sum_tip is not None else False
        if tip:
            self._sum_tip.set_visible(False)
        self.fig.canvas.draw()
        ausschnitt = self.ax.get_window_extent().transformed(self.fig.dpi_scale_trans.inverted())
        self.fig.savefig(pfad, format="svg", bbox_inches=ausschnitt, facecolor=FARBEN["hintergrund"],
                         metadata={"Title": os.path.splitext(os.path.basename(pfad))[0]})
        if tip:
            self._sum_tip.set_visible(True)
        self.status.set_text(f"Grafik gespeichert: {pfad}")
        self.status.set_color(FARBEN["text_dim"])
        self.fig.canvas.draw_idle()
        return pfad

    def zeige_sekante(self, an: bool = True) -> None:
        """Sekante durch A und B auf der bearbeiteten Funktion ein-/ausblenden (A, B werden unten links platziert)."""
        an = bool(an)
        if an and not self.zeige["sekante"]:
            self._sek_platzieren()
        self.zeige["sekante"] = an
        self._schalter_stil()
        self.aktualisiere()

    def set_sekantenpunkte(self, xa: float, xb: float) -> None:
        """A und B auf die Stellen xa und xb setzen (und die Sekante einblenden)."""
        self.sek["xA"], self.sek["xB"] = float(xa), float(xb)
        self.zeige["sekante"] = True
        self._sek_meldung = ""
        self._schalter_stil()
        self.aktualisiere()

    @property
    def sekante(self):
        """{"xA", "yA", "xB", "yB", "dx", "dy", "m", "n", "fn"} der Sekante durch A und B (None, wenn ausgeblendet)."""
        s = self._sekante_berechnen()
        return dict(s) if s else None

    def set_tangentenpunkt(self, x: float, fn: str | None = None) -> None:
        """Punkt P (fn = "f") bzw. Q (fn = "g") auf die Stelle x setzen und seine Tangente einblenden."""
        with self._mit(fn or self.akt):
            self.t_x = float(x)
            self.zeige["t_frei"] = True
        self._schalter_stil()
        self.aktualisiere()

    # ------------------------------------------------------------ Hooks (für abgeleitete Explorer,
    # z. B. den Funktionen-Explorer, der beliebige Terme statt Polynome darstellt)
    def _polynom_modus(self) -> bool:
        return True

    def _kritische_stellen(self):
        """Mögliche Extremstellen der geladenen Funktion für Ober-/Untersummen (Polynom: Nullstellen von f′).
        None bedeutet: numerisch suchen (abgeleitete Explorer für allgemeine Funktionen)."""
        d1 = P.polyder(self.c) if len(self.c) > 1 else np.array([0.0])
        return _reelle_nullstellen(d1) if np.any(d1 != 0) else []

    def _f(self, x):
        """Funktionswert(e) der geladenen Funktion."""
        return P.polyval(x, self.c)

    def _analyse(self, mit_grenzen: bool = True) -> dict:
        return analysiere(self.c, self.a, self.b) if mit_grenzen else analysiere(self.c)

    def _tangenten_berechnen(self, erg: dict) -> list[dict]:
        return tangenten(self.c, erg)

    def _tangente_in(self, x0: float) -> dict:
        """Tangente an der Stelle x0 (abgeleitete Explorer berechnen sie numerisch)."""
        return tangente(self.c, x0)

    def _term_text(self) -> str:
        """Term der geladenen Funktion zum Eintippen."""
        return polynom_term_text(self.c)

    def _term_setzen(self, text: str) -> None:
        """Term aus dem Termfeld übernehmen (geladene Funktion); wirft ValueError bei ungültigem Term."""
        c = polynom_aus_term(text)
        self.c, self.n = np.asarray(c, dtype=float), len(c) - 1
        self._stuetz_verteilen()

    def _kopf_text(self) -> str:
        return f"{self._nm['f']}: Grad n = {self.n}"

    def _status_text(self, kurz: bool = False) -> str:
        return ""

    def _tangente_p_berechnen(self):
        y0 = float(np.asarray(self._f(np.array([self.t_x])), dtype=float)[0])
        if not np.isfinite(y0):
            return None
        t = self._tangente_in(self.t_x)
        if np.isfinite(t.get("m", np.nan)) and abs(t["m"]) < 1e-9:     # Rundungsrauschen (z. B. an Extrema)
            t["m"], t["n"] = 0.0, y0
        P_ = self._nm["P"]
        t.update({"typ": P_, "nr": "", "name": f"t_{P_}", "x0": float(self.t_x), "y0": y0, "fn": self._geladen})
        return t

    def _kurven_daten(self, mit_grenzen: bool = True, erg_f: dict | None = None) -> list[dict]:
        """Eingeblendete Kurven der geladenen Funktion mit Funktion, Analyse und Term (Polynom: exakt)."""
        out = []
        for schl, k, name, tex, farbe, _ in self._kurven_liste():
            if not self._kv[schl]:
                continue
            c = np.asarray(self.c, dtype=float) if k == 0 else koeffizienten_k(self.c, k)
            if k == 0 and erg_f is not None:
                erg = erg_f
            else:
                erg = analysiere(c, self.a, self.b) if mit_grenzen else analysiere(c)
            out.append({"schl": schl, "k": k, "name": name, "tex": tex, "farbe": farbe, "c": c, "fn": self._geladen,
                        "f": (lambda x, c=c: P.polyval(x, c)), "erg": erg,
                        "text": polynom_klartext(c) + (f", {name}(0) = 0" if k < 0 else "")})
        return out

    def _term_zeilen(self) -> list[str]:
        return polynom_tex(self.c, name=self._nm["f"], terme_pro_zeile=6 if self.n <= 11 else 8)[:4]

    def _graph_drag_start(self):
        return (self.c.copy(), self.stuetz_x.copy(), self.stuetz_y.copy())

    def _graph_drag(self, start, dx: float, dy: float) -> None:
        """Graph um (dx, dy) verschieben:  g(x) = f(x − dx) + dy."""
        c0, sx0, sy0 = start
        neu = (Polynomial(c0)(Polynomial([-dx, 1.0]))).coef
        c = np.zeros(self.n + 1)
        c[:len(neu)] = neu[: self.n + 1]
        c[0] += dy
        self.c = c
        self.stuetz_x, self.stuetz_y = sx0 + dx, sy0 + dy
        self._polynom_geaendert()

    def _zahl_lesen(self, txt: str) -> float:
        return _parse_zahl(txt)

    def _polynom_geaendert(self) -> None:
        """Wird aufgerufen, wenn die Koeffizienten der geladenen Funktion über die Bedienelemente geändert wurden."""
        self._termfeld_setzen(polynom_term_text(self.c))

    def _zeichne_zusatz(self) -> None:
        """Platz für zusätzliche Zeichenelemente abgeleiteter Klassen (geladene Funktion)."""

    def _kurve(self, xs, g=None):
        """Funktionswerte zum Zeichnen (g: andere Funktion als f); Sprünge/Polstellen werden als Lücke (nan) markiert."""
        with np.errstate(all="ignore"):
            ys = np.asarray((g or self._f)(xs), dtype=float)
        ys = np.where(np.isfinite(ys), ys, np.nan)
        h = self.ylim[1] - self.ylim[0]
        sprung = np.abs(np.diff(ys)) > 1.5 * h
        aussen = (np.abs(ys[:-1] - (self.ylim[0] + self.ylim[1]) / 2) > h / 2) | \
                 (np.abs(ys[1:] - (self.ylim[0] + self.ylim[1]) / 2) > h / 2)
        luecke = np.where(sprung & aussen & (np.sign(ys[:-1] - (self.ylim[0] + self.ylim[1]) / 2)
                                              != np.sign(ys[1:] - (self.ylim[0] + self.ylim[1]) / 2)))[0]
        if luecke.size:
            xs = np.insert(xs.astype(float), luecke + 1, np.nan)
            ys = np.insert(ys, luecke + 1, np.nan)
        return xs, ys

    # ------------------------------------------------------------ aufbau
    def _stil_textbox(self, tb: TextBox):
        tb.color, tb.hovercolor = FARBEN["feld"], FARBEN["feld_hover"]
        tb.ax.set_facecolor(FARBEN["feld"])
        for s in tb.ax.spines.values():
            s.set_color(FARBEN["gitter_fein"])
        tb.text_disp.set_color(FARBEN["text"])
        tb.label.set_color(FARBEN["text"])
        tb.label.set_fontsize(12)

    def _knopf(self, rect, text, farbe, aktiv=True):
        ax = self.fig.add_axes(rect)
        btn = Button(ax, text, color=farbe if aktiv else FARBEN["aus"],
                     hovercolor=FARBEN["feld_hover"])
        btn.label.set_color(FARBEN["auf_farbe"] if aktiv and farbe != FARBEN["feld"] else FARBEN["text"])
        btn.label.set_fontsize(10)
        btn.label.set_fontweight("bold")
        for s in ax.spines.values():
            s.set_color(farbe if farbe != FARBEN["feld"] else FARBEN["gitter_fein"])
        if farbe == FARBEN["feld"]:
            self._neutrale_knoepfe.append(btn)
        return btn

    @staticmethod
    def _neutral_stil(btn):
        btn.color, btn.hovercolor = FARBEN["feld"], FARBEN["feld_hover"]
        btn.ax.set_facecolor(btn.color)
        btn.label.set_color(FARBEN["text"])
        for s in btn.ax.spines.values():
            s.set_color(FARBEN["gitter_fein"])

    @staticmethod
    def _auswahl_stil(knoepfe: dict, aktiv: str, farben: dict):
        """Optionsfeld-Knöpfe (genau einer aktiv), z. B. dunkel | hell oder f | g."""
        for name, btn in knoepfe.items():
            an, farbe = name == aktiv, farben[name]
            btn.color = farbe if an else FARBEN["feld"]
            btn.hovercolor = btn.color if an else FARBEN["feld_hover"]
            btn.ax.set_facecolor(btn.color)
            btn.label.set_color(FARBEN["auf_farbe"] if an else FARBEN["text_dim"])
            for sp in btn.ax.spines.values():
                sp.set_color(farbe if an else FARBEN["gitter_fein"])

    def _design_knoepfe_stil(self):
        self._auswahl_stil(self._design_knoepfe, self.design, {k: FARBEN["graph"] for k in self._design_knoepfe})

    def _wahl_knoepfe_stil(self):
        self._auswahl_stil(self._wahl_knoepfe, self.akt, {"f": FARBEN["graph"], "g": FARBEN["g_graph"]})

    def _kurven_knoepfe_stil(self):
        for fn, knoepfe in self.kurven_knoepfe.items():
            with self._mit(fn):
                for schl, _k, _n, _t, farbschl, _b in self._kurven_liste():
                    btn = knoepfe[schl]
                    farbe = FARBEN[farbschl]
                    btn.hovercolor = FARBEN["feld_hover"]
                    for sp in btn.ax.spines.values():
                        sp.set_color(farbe)
                    self._knopf_stil(btn, farbe, self._kv[schl])
        self.fig.canvas.draw_idle()

    def _kurve_umschalten(self, fn, schl):
        with self._mit(fn):
            self._kv[schl] = not self._kv[schl]
            self._spur_schalten(fn, schl, self._kv[schl])
        self._kurven_knoepfe_stil()
        self.aktualisiere()

    def _schalter_stil(self):
        """Ein-/Ausblende-Knöpfe nach self.zeige färben (Punkt P/Q: bearbeitete Funktion)."""
        for schl, (btn, farbe) in self.knoepfe.items():
            self._knopf_stil(btn, farbe, self.zeige[schl])
        self.fig.canvas.draw_idle()

    def _alle_textboxen(self) -> list:
        return (list(self.boxen) + [self.box_a, self.box_b, self.box_n, self.box_px, self.box_py] + list(self.term_boxen.values())
                + list(self.sek_boxen.values()) + list(self.trace_boxen.values()))

    def _design_anwenden(self, alt: dict) -> None:
        """Alle Bedienelemente auf die aktuelle Palette umfärben (alt = vorherige Palette)."""
        from matplotlib.colors import same_color
        self.fig.patch.set_facecolor(FARBEN["figur"])
        self._panel.set_facecolor(FARBEN["panel"])
        for tb in self._alle_textboxen():
            self._stil_textbox(tb)
            tb.ax.set_facecolor(FARBEN["feld_hover"] if tb.capturekeystrokes else FARBEN["feld"])
        self._termboxen_stil()
        # Schieberegler
        sl = self.slider
        sl.ax.set_facecolor(FARBEN["feld"])
        sl.poly.set_color(FARBEN["gitter"])
        if hasattr(sl, "track"):
            sl.track.set_facecolor(FARBEN["feld"])
        if hasattr(sl, "_handle"):
            sl._handle.set_markerfacecolor(FARBEN["extremum"])
            sl._handle.set_markeredgecolor(FARBEN["kontur"])
        sl.label.set_color(FARBEN["text"])
        sl.valtext.set_color(FARBEN["extremum"])
        self._n_regler_stil()
        # farbige Schalter
        for schl, (btn, _alt_farbe) in self.knoepfe.items():
            farbe = FARBEN[self._knopf_farbschluessel[schl]]
            self.knoepfe[schl] = (btn, farbe)
            for s in btn.ax.spines.values():
                s.set_color(farbe)
            btn.hovercolor = FARBEN["feld_hover"]
            self._knopf_stil(btn, farbe, self.zeige[schl])
        for btn in self._neutrale_knoepfe:
            self._neutral_stil(btn)
        self._design_knoepfe_stil()
        self._wahl_knoepfe_stil()
        self._kurven_knoepfe_stil()
        # Beschriftungen der Figur (Term, Hinweise, Ergebnisse, Status …)
        reihenfolge = ["text", "text_dim"] + [k for k in alt if k not in ("text", "text_dim")]
        for t in self.fig.texts:
            c = t.get_color()
            for k in reihenfolge:
                if isinstance(alt[k], str) and alt[k] != "none" and same_color(c, alt[k]):
                    t.set_color(FARBEN[k])
                    break

    def _termboxen_stil(self):
        for k, tb in self.term_boxen.items():
            tb.label.set_fontsize(15)
            tb.text_disp.set_fontsize(13)
            tb.label.set_color(FARBEN["text"] if k == "f" else FARBEN["g_graph"])

    def _baue_oberflaeche(self):
        fig = self.fig
        self.ax = fig.add_axes([0.035, 0.115, 0.60, 0.66])

        # Termfelder f(x) = …, g(x) = …  (Polynome, z. B. (x-1)(x+2)², auch über Grad und Koeffizienten)
        self.term_boxen: dict[str, TextBox] = {}
        self._letztes_termfeld = "f"
        for k, rect in (("f", [0.075, 0.935, 0.45, 0.042]), ("g", [0.075, 0.888, 0.45, 0.040])):
            with self._mit(k):
                text = self._term_text()
            tb = TextBox(fig.add_axes(rect), rf"${k}(x) =$ ", initial=text)
            self._stil_textbox(tb)
            tb.on_text_change(lambda t, k=k: self._term_eingabe(k, t))
            tb.on_submit(lambda t, k=k: self._term_eingabe(k, t))
            tb.cursor_index = len(text)
            self.term_boxen[k] = tb
        self._termboxen_stil()
        self.status = fig.text(0.075, 0.871, "", color=FARBEN["text_dim"], fontsize=9, va="center")

        # Funktionsterme (Formelsatz); f in Textfarbe, g in seiner Kurvenfarbe
        self.term_texte = [fig.text(0.035, 0.83, "", color=FARBEN["text"], fontsize=17, va="center")
                           for _ in range(4)]

        # rechter Bereich (Panel)
        panel = self._panel = fig.add_axes([0.66, 0.0, 0.34, 1.0])
        panel.set_facecolor(FARBEN["panel"])
        panel.set_xticks([]); panel.set_yticks([])
        for s in panel.spines.values():
            s.set_visible(False)
        panel.set_zorder(-10)
        panel.set_navigate(False)

        # Wechselschalter für die Darstellung (dunkel = 3Blue1Brown-Stil | hell = Pearson-Schulbuch)
        self._design_knoepfe = {}
        for k, (name, text) in enumerate([("3b1b", "dunkel"), ("pearson", "hell")]):
            ax = fig.add_axes([0.68 + k * 0.152, 0.958, 0.147, 0.030])
            btn = Button(ax, text)
            btn.label.set_fontsize(10)
            btn.label.set_fontweight("bold")
            btn.on_clicked(lambda _e, d=name: self.set_design(d) if d != self.design else None)
            self._design_knoepfe[name] = btn
        self._design_knoepfe_stil()

        # Grad-Schieberegler (der bearbeiteten Funktion)
        sax = fig.add_axes([0.72, 0.915, 0.13, 0.03])
        sax.set_facecolor(FARBEN["feld"])
        self.slider = Slider(sax, r"Grad $n$", 0, N_MAX, valinit=self.n, valstep=1,
                             color=FARBEN["gitter"], initcolor="none",
                             track_color=FARBEN["feld"],
                             handle_style={"facecolor": FARBEN["extremum"], "edgecolor": FARBEN["kontur"], "size": 12})
        self.slider.label.set_color(FARBEN["text"]); self.slider.label.set_fontsize(13)
        self.slider.valtext.set_color(FARBEN["extremum"]); self.slider.valtext.set_fontsize(13)
        self.slider.valtext.set_position((1.07, 0.5))
        self.slider.on_changed(self._grad_geaendert)

        # Bearbeiten: f | g  (Grad, Koeffizienten und Punkt P bzw. Q gehören zur gewählten Funktion)
        self._wahl_knoepfe = {}
        for k, fn in enumerate(("f", "g")):
            btn = Button(fig.add_axes([0.876 + k * 0.054, 0.912, 0.051, 0.036]), f"Funktion ${fn}$")
            btn.label.set_fontsize(9)
            btn.label.set_fontweight("bold")
            btn.on_clicked(lambda _e, fn=fn: self._setze_akt(fn) if fn != self.akt else None)
            self._wahl_knoepfe[fn] = btn
        self._wahl_knoepfe_stil()

        self._koeff_titel = fig.text(0.68, 0.868, "", color=FARBEN["text_dim"], fontsize=10)
        self._koeff_beispiel = "(z. B. 0,5   -3/4   1/7!   (-1)^3/3!)"

        # Koeffizienten-Eingabe a0 … a20 (bzw. b0 … b20 für g): 4 Spalten × 6 Zeilen
        self.boxen: list[TextBox] = []
        for i in range(N_MAX + 1):
            spalte, zeile = divmod(i, 6)
            rect = [0.698 + spalte * 0.075, 0.826 - zeile * 0.0365, 0.050, 0.030]
            tb = TextBox(fig.add_axes(rect), rf"$a_{{{i}}}$ ", initial="0")
            self._stil_textbox(tb)
            tb.on_submit(lambda txt, i=i: self._koeff_eingabe(i, txt))
            self.boxen.append(tb)

        # Funktionsleisten: Wechselschalter F | f | f′ | f″ | f‴  und  G | g | g′ | g″ | g‴
        self.kurven_knoepfe = {"f": {}, "g": {}}
        for fn, y in (("f", 0.596), ("g", 0.551)):
            for i, (schl, k, name, tex, farbschl, beschr) in enumerate(KURVEN if fn == "f" else KURVEN_G):
                ax = fig.add_axes([0.675 + i * 0.0625, y, 0.058, 0.040])
                btn = Button(ax, f"${tex}$\n{beschr}", hovercolor=FARBEN["feld_hover"])
                btn.label.set_fontsize(8)
                btn.label.set_fontweight("bold")
                btn.label.set_linespacing(1.1)
                btn.on_clicked(lambda _e, fn=fn, s=schl: self._kurve_umschalten(fn, s))
                self.kurven_knoepfe[fn][schl] = btn
        self._kurven_knoepfe_stil()

        # Ein-/Ausblende-Knöpfe
        self.knoepfe = {}
        self._knopf_farbschluessel = {"nullstellen": "nullstelle", "extrema": "extremum", "wende": "wendepunkt",
                                      "integral": "integral_pos", "t_hoch": "t_hoch", "t_tief": "t_tief",
                                      "t_wende": "t_wende", "t_frei": "t_frei", "schnitt": "schnitt", "yachse": "yachse"}
        for k, (schl, txt) in enumerate([("nullstellen", "Null-\nstellen"), ("extrema", "Extrema"),
                                         ("wende", "Wende-\npunkte"), ("integral", "Integral"),
                                         ("schnitt", "Schnittpunkt-\nberechnung"), ("yachse", "y-Achsen-\nabschnitt")]):
            farbe = FARBEN[self._knopf_farbschluessel[schl]]
            btn = self._knopf([0.675 + k * 0.0515, 0.503, 0.0490, 0.040], txt, farbe)
            btn.label.set_fontsize(7.6 if schl in ("schnitt", "yachse") else 8.5)
            btn.on_clicked(lambda _e, s=schl: self._umschalten(s))
            self.knoepfe[schl] = (btn, farbe)

        # Sekante durch A und B: Knopf „Sekanten einblenden“ und Koordinatenfelder x_A, y_A, x_B, y_B
        self._knopf_farbschluessel["sekante"] = "sekante"
        farbe = FARBEN["sekante"]
        btn = self._knopf([0.675, 0.458, 0.0735, 0.036], "Sekanten\neinblenden", farbe)
        btn.label.set_fontsize(8.5)
        btn.on_clicked(lambda _e: self._umschalten("sekante"))
        self.knoepfe["sekante"] = (btn, farbe)
        self._knopf_stil(btn, farbe, False)
        self.sek_boxen = {}
        for k, schl in enumerate(("xA", "yA", "xB", "yB")):
            tb = TextBox(fig.add_axes([0.775 + k * 0.052, 0.460, 0.036, 0.032]), rf"${schl[0]}_{schl[1]}$ ", initial="")
            self._stil_textbox(tb)
            tb.label.set_fontsize(10)
            tb.on_submit(lambda t, schl=schl: self._sek_eingabe(schl[0], schl[1], t))
            self.sek_boxen[schl] = tb

        # Knopf über dem Koordinatensystem: Punkte zum Verformen des Graphen (Stützpunkte) ein-/ausblenden
        self._knopf_farbschluessel["stuetz"] = "stuetz"
        farbe = FARBEN["stuetz"]
        btn = self._knopf([0.533, 0.888, 0.102, 0.040], "Punkte zum\nVerformen", farbe)
        btn.label.set_fontsize(8.5)
        btn.on_clicked(lambda _e: self._umschalten("stuetz"))
        self.knoepfe["stuetz"] = (btn, farbe)

        # Trace-Modus: Knopf über dem Koordinatensystem, darunter die Felder x und y = f(x)
        self._knopf_farbschluessel["trace"] = "trace"
        farbe = FARBEN["trace"]
        btn = self._knopf([0.533, 0.842, 0.050, 0.036], "Trace-\nModus", farbe)
        btn.label.set_fontsize(8.5)
        btn.on_clicked(lambda _e: self._umschalten("trace"))
        self.knoepfe["trace"] = (btn, farbe)
        self._play_knopf = self._knopf([0.585, 0.842, 0.050, 0.036], "▶ Abspielen", FARBEN["feld"])
        self._play_knopf.label.set_fontsize(8.5)
        self._play_knopf.on_clicked(lambda _e: self._abspielen(not self._spielt))
        # Knopf rechts oberhalb des Koordinatensystems: Inhalt des Grafikfensters als Vektorgrafik (SVG) speichern
        self._svg_knopf = self._knopf([0.545, 0.779, 0.090, 0.021], "⤓ Grafik als SVG", FARBEN["feld"])
        self._svg_knopf.label.set_fontsize(8)
        self._svg_knopf.on_clicked(lambda _e: self.speichere_svg())
        self.trace_boxen = {}
        for k, (schl, beschr) in enumerate((("x", r"$x$ = "), ("y", r"$y$ = "))):
            tb = TextBox(fig.add_axes([0.553 + k * 0.052, 0.800, 0.032, 0.030]), beschr, initial="")
            self._stil_textbox(tb)
            tb.label.set_fontsize(10)
            tb.on_submit(lambda t, schl=schl: self._trace_eingabe(schl, t))
            self.trace_boxen[schl] = tb

        # Tangenten-Knöpfe (anfangs aus); H/T/W gelten für f und g, Punkt P/Q für die bearbeitete Funktion
        fig.text(0.68, 0.450, "Tangenten an (f und g)", color=FARBEN["text_dim"], fontsize=10, va="top")
        for k, (schl, txt) in enumerate([("t_hoch", "Hochpunkten"), ("t_tief", "Tiefpunkten"),
                                         ("t_wende", "Wende/Sattel"), ("t_frei", "Punkt P ↔")]):
            farbe = FARBEN[schl]
            btn = self._knopf([0.675 + k * 0.0775, 0.395, 0.0735, 0.040], txt, farbe)
            btn.label.set_fontsize(9)
            btn.on_clicked(lambda _e, s=schl: self._umschalten(s))
            self.knoepfe[schl] = (btn, farbe)
            self._knopf_stil(btn, farbe, False)

        # Koordinaten des Tangentenpunkts P bzw. Q direkt eingeben (x -> y = f(x); y -> passende Stelle x)
        self.box_px = TextBox(fig.add_axes([0.705, 0.352, 0.10, 0.032]), r"$x_P$ = ", initial=_zahl_text(self.t_x))
        self.box_py = TextBox(fig.add_axes([0.850, 0.352, 0.10, 0.032]), r"$y_P$ = ", initial="")
        for tb in (self.box_px, self.box_py):
            self._stil_textbox(tb)
        self.box_px.on_submit(lambda t: self._p_eingabe("x", t))
        self.box_py.on_submit(lambda t: self._p_eingabe("y", t))

        b1 = self._knopf([0.675, 0.311, 0.150, 0.034], "Ansicht anpassen", FARBEN["feld"])
        b1.on_clicked(lambda _e: self.ansicht_anpassen())
        b2 = self._knopf([0.831, 0.311, 0.150, 0.034], "Zurücksetzen", FARBEN["feld"])
        b2.on_clicked(lambda _e: self._zuruecksetzen())
        self._hilfsknoepfe = (b1, b2)

        # Integral und Riemann-Summen: Knopfleiste Obersumme | Untersumme | Trapezsumme | Mittensumme,
        # darunter Untergrenze a, Obergrenze b und Anzahl n der Teilintervalle
        fig.text(0.68, 0.293, "Integral und Summen  (a, b auch im Graphen ziehbar)", color=FARBEN["text_dim"], fontsize=10)
        for k, (art, txt) in enumerate(SUMMEN_ARTEN.items()):
            schl = "s_" + art
            self._knopf_farbschluessel[schl] = "summe"
            farbe = FARBEN["summe"]
            btn = self._knopf([0.675 + k * 0.0775, 0.247, 0.0735, 0.036], txt, farbe)
            btn.label.set_fontsize(8.5)
            btn.on_clicked(lambda _e, s=schl: self._umschalten(s))
            self.knoepfe[schl] = (btn, farbe)
            self._knopf_stil(btn, farbe, False)
        for x, txt in ((0.682, "Untergrenze"), (0.792, "Obergrenze"), (0.902, "Teilintervalle")):
            fig.text(x, 0.2335, txt, color=FARBEN["text_dim"], fontsize=7.5, va="bottom")
        self.box_a = TextBox(fig.add_axes([0.700, 0.200, 0.075, 0.030]), r"$a$ = ", initial=_zahl_text(self.a))
        self.box_b = TextBox(fig.add_axes([0.810, 0.200, 0.075, 0.030]), r"$b$ = ", initial=_zahl_text(self.b))
        self.box_n = TextBox(fig.add_axes([0.920, 0.200, 0.055, 0.030]), r"$n$ = ", initial=str(self.summe_n))
        for tb in (self.box_a, self.box_b, self.box_n):
            self._stil_textbox(tb)
        self.box_a.on_submit(lambda t: self._grenze_eingabe("a", t))
        self.box_b.on_submit(lambda t: self._grenze_eingabe("b", t))
        self.box_n.on_submit(self._n_eingabe)

        # Schieberegler für die Anzahl n der Teilintervalle (logarithmisch 1 … 1000): unter der Grafik und unter a, b, n
        self.n_regler = []
        for rect, beschr in (([0.105, 0.072, 0.45, 0.022], r"Teilintervalle $n$"), ([0.715, 0.166, 0.215, 0.018], r"$n$")):
            sax = fig.add_axes(rect)
            sl = Slider(sax, beschr, 0.0, math.log10(SUMMEN_N_MAX), valinit=math.log10(self.summe_n), color=FARBEN["summe"],
                        initcolor="none", track_color=FARBEN["feld"],
                        handle_style={"facecolor": FARBEN["summe"], "edgecolor": FARBEN["kontur"], "size": 11})
            sl.label.set_fontsize(11)
            sl.valtext.set_fontsize(11)
            sl.valtext.set_text(str(self.summe_n))
            sl.on_changed(self._n_regler_bewegt)
            self.n_regler.append(sl)
        self._n_regler_stil()

        # Ergebnis-Anzeige
        self.info = fig.text(0.675, 0.150, "", color=FARBEN["text"], fontsize=8.2,
                             family="DejaVu Sans Mono", va="top", linespacing=1.28)
        self.info2 = fig.text(0.838, 0.150, "", color=FARBEN["text"], fontsize=8.2,      # zweite Spalte (mehrere Kurven)
                              family="DejaVu Sans Mono", va="top", linespacing=1.28)

        self._hinweis = fig.text(
            0.035, 0.030,
            "Termfelder f(x), g(x): Polynome wie x^3 - 4x oder (x-1)(x+2)²  ·  Funktion f | g: was Grad, Koeffizienten und "
            "Punkt P/Q bearbeiten\nMaus:  Kreise = Graph von f bzw. g verformen  ·  Graph = verschieben  ·  Punkt P/Q = "
            "Tangente entlang des Graphen  ·  A/B = Sekante  ·  Start: nur Graph von f, Rest über die Knöpfe  ·  Marken a / b = Integrationsgrenzen  ·  Hintergrund = Ansicht  ·  Mausrad = Zoom"
            "\nSummen:  Ober-, Unter-, Trapez-, Mittensumme über [a; b] mit n Teilintervallen (n auch über die Schieberegler, 1 … 1000)  ·  Maus über ein Rechteck bzw. "
            "Trapez = sein Anteil an der Summe (absolut und in Prozent)",
            color=FARBEN["text_dim"], fontsize=8.2, va="center", linespacing=1.4)
        self._schalter_stil()
        self._akt_beschriften()

    def _akt_beschriften(self):
        """Beschriftungen an die bearbeitete Funktion anpassen (a_i / b_i, P / Q, f / g)."""
        nm = NAMEN[self.akt]
        for i, tb in enumerate(self.boxen):
            tb.label.set_text(rf"${nm['a']}_{{{i}}}$ ")
        self.box_px.label.set_text(rf"$x_{nm['P']}$ = ")
        self.box_py.label.set_text(rf"$y_{nm['P']}$ = ")
        self.knoepfe["t_frei"][0].label.set_text(f"Punkt {nm['P']} ↔")
        self.slider.label.set_text(rf"Grad ${nm['f']}$")
        self._koeff_titel.set_text(rf"Koeffizienten von ${nm['f']}$  {self._koeff_beispiel}")

    def _setze_akt(self, k: str) -> None:
        if k not in NAMEN:
            raise ValueError(f"Unbekannte Funktion „{k}“ – möglich: f, g")
        self._lade(k)
        self.akt = k
        self._p_meldung = ""
        if self.zeige["sekante"] and not (np.isfinite(self._wert(self.sek["xA"])) and np.isfinite(self._wert(self.sek["xB"]))):
            self._sek_platzieren()
        self._akt_beschriften()
        self._wahl_knoepfe_stil()
        self._schalter_stil()
        self.aktualisiere()

    # ------------------------------------------------------------ zeichnen
    def _zeichne_koordinatensystem(self):
        ax = self.ax
        ax.cla()
        ax.set_facecolor(FARBEN["hintergrund"])
        ax.set_xlim(*self.xlim); ax.set_ylim(*self.ylim)
        for achse in (ax.xaxis, ax.yaxis):
            achse.set_major_locator(MaxNLocator(nbins=14, steps=[1, 2, 5, 10], integer=False))
            achse.set_minor_locator(AutoMinorLocator(2))
        ax.grid(which="major", color=FARBEN["gitter"], linewidth=1.0, alpha=0.55)
        ax.grid(which="minor", color=FARBEN["gitter_fein"], linewidth=0.6, alpha=0.45)
        ax.tick_params(which="both", length=0, colors=FARBEN["text_dim"], labelsize=9)
        for s in ax.spines.values():
            s.set_color(FARBEN["rahmen"])
        ax.axhline(0, color=FARBEN["achsen"], lw=1.8, zorder=2)
        ax.axvline(0, color=FARBEN["achsen"], lw=1.8, zorder=2)
        if FARBEN["pfeile"]:                       # Pfeilspitzen wie im Schulbuch
            if self.ylim[0] < 0 < self.ylim[1]:
                ax.plot([self.xlim[1]], [0], marker=">", ms=10, color=FARBEN["achsen"], clip_on=False, zorder=2)
            if self.xlim[0] < 0 < self.xlim[1]:
                ax.plot([0], [self.ylim[1]], marker="^", ms=10, color=FARBEN["achsen"], clip_on=False, zorder=2)
        # Achsenbeschriftung an den Achsen (Manim-Stil)
        def zahl_achse(v):
            return _dez(v, 2)
        xt = [t for t in ax.get_xticks() if self.xlim[0] < t < self.xlim[1] and abs(t) > 1e-12]
        yt = [t for t in ax.get_yticks() if self.ylim[0] < t < self.ylim[1] and abs(t) > 1e-12]
        dy = (self.ylim[1] - self.ylim[0]) * 0.012
        dx = (self.xlim[1] - self.xlim[0]) * 0.008
        y0 = min(max(0.0, self.ylim[0] + 4 * dy), self.ylim[1] - 2 * dy)
        x0 = min(max(0.0, self.xlim[0] + 4 * dx), self.xlim[1] - 6 * dx)
        for t in xt:
            ax.plot([t, t], [y0 - dy, y0 + dy], color=FARBEN["achsen"], lw=1.2, zorder=2)
            ax.text(t, y0 - 2.2 * dy, zahl_achse(t), color=FARBEN["text"], fontsize=10,
                    ha="center", va="top", zorder=2)
        for t in yt:
            ax.plot([x0 - dx, x0 + dx], [t, t], color=FARBEN["achsen"], lw=1.2, zorder=2)
            ax.text(x0 - 2 * dx, t, zahl_achse(t), color=FARBEN["text"], fontsize=10,
                    ha="right", va="center", zorder=2)
        ax.set_xticklabels([]); ax.set_yticklabels([])
        ax.text(self.xlim[1] - dx, y0 + 2 * dy, "$x$", color=FARBEN["text"], fontsize=16, ha="right", va="bottom")
        ax.text(x0 + 2 * dx, self.ylim[1] - dy, "$y$", color=FARBEN["text"], fontsize=16, ha="left", va="top")

    def _platziere(self, erzeuge, kandidaten):
        """
        Setzt eine Beschriftung an die erste Kandidatenposition, an der sie vollständig im
        Koordinatensystem liegt und keine bereits gesetzte Beschriftung überdeckt.
        Passt keine Position, entfällt die Beschriftung (die Werte stehen trotzdem im Infobereich).
        """
        try:
            renderer = self.fig.canvas.get_renderer()
        except Exception:          # Backend ohne Renderer-Zugriff: erste Position nehmen
            return erzeuge(kandidaten[0])
        ax_bb = self.ax.bbox
        for kand in kandidaten:
            art = erzeuge(kand)
            bb = art.get_window_extent(renderer)
            innen = (bb.x0 >= ax_bb.x0 + 2 and bb.x1 <= ax_bb.x1 - 2 and
                     bb.y0 >= ax_bb.y0 + 2 and bb.y1 <= ax_bb.y1 - 2)
            if innen and not any(bb.overlaps(b) for b in self._belegt):
                self._belegt.append(bb)
                return art
            art.remove()
        return None

    def _punkt(self, x, y, farbe, label, ring=None):
        ax = self.ax
        ax.plot([x], [y], "o", ms=9, color=farbe, mec=FARBEN["kontur"], mew=1.2, zorder=6)
        if ring is not None:                 # Punkte aller Kurven außer f: Ring in der Kurvenfarbe
            ax.plot([x], [y], "o", ms=14, mfc="none", mec=ring, mew=2.0, zorder=6)
        if not (self.xlim[0] <= x <= self.xlim[1] and self.ylim[0] <= y <= self.ylim[1]):
            return
        def erzeuge(k):
            (dx, dy), ha, va = k
            return ax.annotate(label, (x, y), xytext=(dx, dy), textcoords="offset points",
                               ha=ha, va=va, color=farbe, fontsize=9.5, zorder=7,
                               bbox=dict(boxstyle="round,pad=0.2", fc=FARBEN["label_bg"], ec="none", alpha=0.72))
        self._platziere(erzeuge, [((7, 6), "left", "bottom"), ((7, -6), "left", "top"),
                                  ((-7, 6), "right", "bottom"), ((-7, -6), "right", "top")])

    def aktualisiere(self):
        # Analyse beider Funktionen (Ergebnisse bleiben im jeweiligen Zustand gespeichert)
        for k in ("f", "g"):
            self._lade(k)
            self.erg = self._analyse()
            self._tang = self._tangenten_berechnen(self.erg)
            self.kd = self._kurven_daten(True, self.erg)
            self._tp = self._tangente_p_berechnen() if self.zeige["t_frei"] and self._kv["f"] else None
        self._lade(self.akt)
        self._sk = self._sekante_berechnen()
        self._summe = self._summe_berechnen()
        if self._summe is None or self._summe.get("fehlt") or (self._sum_hover or 0) >= len(self._summe["teile"]):
            self._sum_hover = None
        self._schnitte = self._schnittpunkte_berechnen() if self.zeige["schnitt"] else []
        self._belegt = []
        self._zeichne_koordinatensystem()
        ax = self.ax

        # Integralflächen: f in den Integralfarben, g in seiner Kurvenfarbe (blasser)
        if self.zeige["integral"]:
            for k in ("g", "f"):
                with self._mit(k):
                    if not self._kv["f"]:
                        continue
                    lo, hi = sorted((self.a, self.b))
                    if self.erg["integral"] is None:       # Funktion im Intervall nicht überall definiert
                        lo = hi
                    xi = np.linspace(lo, hi, 600)
                    with np.errstate(all="ignore"):
                        yi = np.asarray(self._f(xi), dtype=float)
                    yi = np.where(np.isfinite(yi), yi, np.nan)
                    if k == "f":
                        fp, fn_, al_p, al_n, rand = (FARBEN["integral_pos"], FARBEN["integral_neg"], FARBEN["flaeche_pos"],
                                                     FARBEN["flaeche_neg"], FARBEN["integral_pos"])
                    else:
                        fp = fn_ = rand = FARBEN["g_graph"]
                        al_p, al_n = 0.6 * FARBEN["flaeche_pos"], 0.6 * FARBEN["flaeche_neg"]
                    ax.fill_between(xi, yi, 0, where=yi >= 0, interpolate=True, color=fp, alpha=al_p, lw=0, zorder=3)
                    ax.fill_between(xi, yi, 0, where=yi < 0, interpolate=True, color=fn_, alpha=al_n, lw=0, zorder=3)
                    for g in (self.a, self.b):
                        ax.plot([g, g], [0, self._fy(g)], color=rand, lw=1.4, ls="--", zorder=4)

        # Riemann-Summe der bearbeiteten Funktion (Rechtecke bzw. Trapeze, Gesamtwert oben rechts)
        self._zeichne_summe()

        # Graphen: zuerst Stammfunktionen und Ableitungen, dann g, zuletzt f mit leichtem "Glow" obenauf
        alle = []
        for k in ("f", "g"):
            with self._mit(k):
                alle += list(self.kd)
        rang = lambda d: 0 if d["k"] != 0 else (1 if d["fn"] == "g" else 2)
        for d in sorted(alle, key=rang):
            xs, ys = self._kurve(np.linspace(self.xlim[0], self.xlim[1], 1600), d["f"])
            sp = self._spur_von(d)
            if sp:                                       # Spur: nur der vom Trace-Punkt überstrichene Bereich
                tol = 0.6 * (self.xlim[1] - self.xlim[0]) / ax.bbox.width
                drin = np.zeros(xs.shape, dtype=bool)
                for a_, b_ in sp:
                    drin |= (xs >= a_ - tol) & (xs <= b_ + tol)
                ys = np.where(drin, ys, np.nan)
            farbe = FARBEN[d["farbe"]]
            if d["k"] == 0 and FARBEN["glanz"] > 0:
                ax.plot(xs, ys, color=farbe, lw=7, alpha=FARBEN["glanz"], zorder=4, solid_capstyle="round")
            ax.plot(xs, ys, color=farbe, lw=FARBEN["graph_lw"] * (1 if d["k"] == 0 else 0.85),
                    zorder=4.8 + 0.1 * rang(d), solid_capstyle="round")

        self._zeichne_tangentenliste()
        for k in ("f", "g"):
            with self._mit(k):
                if self._tp is not None:
                    tp, P_ = self._tp, self._nm["P"]
                    self._punkt(tp["x0"], tp["y0"], FARBEN["t_frei"], f"{P_}({_dez(tp['x0'], 2)}|{_dez(tp['y0'], 2)})",
                                None if k == "f" else FARBEN["g_graph"])
                    ax.plot([tp["x0"]], [tp["y0"]], "o", ms=17, mfc="none", mec=FARBEN["t_frei"], mew=1.6,
                            alpha=0.7, zorder=6)      # Griff: zeigt an, dass P bzw. Q ziehbar ist
        for d in alle:   # Punkte aller Kurven außer f tragen den Kurvennamen und einen Ring in Kurvenfarbe
            ist_f = d["fn"] == "f" and d["k"] == 0
            sp = self._spur_von(d)
            drin = lambda x, sp=sp: not sp or any(a_ - 1e-9 <= x <= b_ + 1e-9 for a_, b_ in sp)
            e, v = d["erg"], ("" if ist_f else d["name"] + ": ")
            ring = None if ist_f else FARBEN[d["farbe"]]
            if self.zeige["nullstellen"]:
                for k, x in enumerate(e["nullstellen"], 1):
                    if drin(x):
                        self._punkt(x, 0.0, FARBEN["nullstelle"], f"{v}N$_{{{k}}}$({_dez(x, 2)}|0)", ring)
            if self.zeige["extrema"]:
                for x, y, typ in e["extrema"]:
                    if drin(x):
                        self._punkt(x, y, FARBEN["extremum"], f"{v}{typ[0]}({_dez(x, 2)}|{_dez(y, 2)})", ring)
                for x, y in e["sattelpunkte"]:
                    if drin(x):
                        self._punkt(x, y, FARBEN["extremum"], f"{v}S({_dez(x, 2)}|{_dez(y, 2)})", ring)
            if self.zeige["wende"]:
                for x, y in e["wendepunkte"]:
                    if drin(x):
                        self._punkt(x, y, FARBEN["wendepunkt"], f"{v}W({_dez(x, 2)}|{_dez(y, 2)})", ring)

        # Schnittpunkte der Graphen und y-Achsenabschnitte
        for q in self._schnitte:
            self._punkt(q["x"], q["y"], FARBEN["schnitt"], f"{q['A']['name']} ∩ {q['B']['name']}: ({_dez(q['x'], 2)}|{_dez(q['y'], 2)})")
        if self.zeige["yachse"]:
            for d, y in self._y_abschnitte_berechnen():
                if np.isfinite(y):
                    self._punkt(0.0, y, FARBEN["yachse"], f"{d['name']}: (0|{_dez(y, 2)})", FARBEN[d["farbe"]])

        # Tangenten (Linien + Beschriftungen; Tangenten an g gestrichelt)
        for k in ("g", "f"):
            with self._mit(k):
                self._zeichne_tangenten()

        # Trace-Modus und Sekante durch A und B mit Steigungsdreieck
        self._zeichne_trace()
        self._zeichne_sekante()

        # Integrationsgrenzen als ziehbare Marken auf der x-Achse (auch bei eingeblendeter Summe)
        if self.zeige["integral"] or self._summe is not None:
            self._zeichne_grenzmarken()

        for k in ("g", "f"):
            with self._mit(k):
                if self._kv["f"]:
                    self._zeichne_zusatz()
                    # Stützpunkte (ziehbar, nur bei Polynomen): weiß für f, in der Kurvenfarbe für g
                    if self._polynom_modus() and self.zeige["stuetz"]:
                        ax.plot(self.stuetz_x, self.stuetz_y, "o", ms=8, mfc=FARBEN["stuetz_fuellung"],
                                mec=FARBEN["stuetz"] if k == "f" else FARBEN["g_graph"], mew=1.8, zorder=8)

        ax.set_xlim(*self.xlim); ax.set_ylim(*self.ylim)

        # Terme + Eingabefelder + Info
        self._setze_term()
        self._boxen_aktualisieren()
        self._info_setzen(self._info_text())
        self.fig.canvas.draw_idle()
        if self.on_change is not None:
            with self._mit("f"):
                erg_f = self.erg
            with self._mit("g"):
                erg_g = self.erg
            self.on_change(erg_f, erg_g)

    def _info_setzen(self, info: str) -> None:
        """Ergebnisse anzeigen; mehrere Kurven (Blöcke, getrennt durch "\x1e") werden auf zwei Spalten verteilt."""
        teile = info.split("\n\x1e\n") if "\x1e" in info else [info]
        teile = [t.strip("\n\x1e") for t in teile]
        teile = [t for t in teile if t]
        if len(teile) <= 1:
            links, rechts = (teile[0] if teile else ""), ""
            zeilen = links.count("\n") + 1
            groesse = min(8.2, max(3.8, 96 / zeilen))
        else:
            kopf, kurven, rest = teile[0], teile[1:], ""
            if not kurven[-1].startswith("▶"):            # Tangente in P/Q, Hinweise
                rest = kurven.pop()
            n = lambda t: t.count("\n") + 1
            gesamt = n(kopf) + sum(n(t) for t in kurven) + (n(rest) if rest else 0)
            links_t, rechts_t, z = [kopf], [], n(kopf)
            for t in kurven:                              # Blöcke nicht teilen; links bis zur Hälfte füllen
                if z + n(t) / 2 <= gesamt / 2 or not rechts_t and len(links_t) == 1:
                    links_t.append(t); z += n(t)
                else:
                    rechts_t.append(t)
            (rechts_t if rechts_t else links_t).append(rest) if rest else None
            links, rechts = "\n".join(links_t), "\n".join(rechts_t)
            zeilen = max(links.count("\n"), rechts.count("\n")) + 1
            groesse = min(7.4, max(3.8, 96 / zeilen))
        self.info.set_text(links)
        self.info.set_fontsize(groesse)
        self.info2.set_text(rechts)
        self.info2.set_fontsize(groesse)

    def _setze_term(self) -> None:
        """Terme von f (und g, falls eingeblendet) im Formelsatz über dem Koordinatensystem."""
        g_an = self._g_sichtbar()
        zeilen = []
        for k in (("f", "g") if g_an else ("f",)):
            with self._mit(k):
                z = self._term_zeilen()
            zeilen += [(t, FARBEN["text"] if k == "f" else FARBEN["g_graph"]) for t in z[:2 if g_an else 4]]
        n = len(zeilen)
        groesse = {1: 17, 2: 15, 3: 12, 4: 10.5}[n]
        ys = [0.828] if n == 1 else list(np.linspace(0.84, 0.795, n))
        for k, txt in enumerate(self.term_texte):
            if k < n:
                txt.set_position((0.035, ys[k]))
                txt.set_fontsize(groesse)
                txt.set_text(zeilen[k][0])
                txt.set_color(zeilen[k][1])
            else:
                txt.set_text("")
        if self._status_fehler:
            self.status.set_text(self._status_fehler)
            self.status.set_color(FARBEN["nullstelle"])
        else:
            teile = []
            for k in (("f", "g") if g_an else ("f",)):
                with self._mit(k):
                    teile.append(self._status_text(kurz=g_an))
            teile = [t for t in teile if t]
            self.status.set_text("  ·  ".join(teile) + (f"  ·  x ∈ [{_dez(self.xlim[0], 2)}; {_dez(self.xlim[1], 2)}]"
                                                         if teile else ""))
            self.status.set_color(FARBEN["text_dim"])

    def _tangenten_sichtbar(self) -> list[dict]:
        """Sichtbare Tangenten der geladenen Funktion (für g mit Index g: t_gH₁)."""
        if not self._kv.get("f", True):
            return []
        wahl = {"H": "t_hoch", "T": "t_tief", "W": "t_wende", "S": "t_wende"}
        sicht = [t for t in (self._tang or []) if self.zeige[wahl[t["typ"]]]]
        if self._geladen == "g":
            sicht = [{**t, "name": rf"t_{{g{t['typ']}_{{{t['nr']}}}}}"} for t in sicht]
        if self._tp is not None:
            sicht.append(self._tp)
        return sicht

    @staticmethod
    def _t_farbe(typ):
        return {"H": FARBEN["t_hoch"], "T": FARBEN["t_tief"], "P": FARBEN["t_frei"], "Q": FARBEN["t_frei"]}.get(
            typ, FARBEN["t_wende"])

    def _zeichne_tangenten(self):
        """Tangenten der geladenen Funktion; an g gestrichelt."""
        ax = self.ax
        sicht = self._tangenten_sichtbar()
        ls = (0, (6, 4)) if self._geladen == "g" else "-"
        (x0, x1), (y0, y1) = self.xlim, self.ylim
        for k, t in enumerate(sicht):
            farbe = self._t_farbe(t["typ"])
            if t.get("existiert") is False:
                continue
            if t.get("senkrecht"):
                ax.axvline(t["x0"], color=farbe, lw=2.0, alpha=0.95, zorder=4.5, ls=ls)
                def erzeuge(kand, t=t, farbe=farbe):
                    frac, ox = kand
                    yl = y0 + (y1 - y0) * frac
                    return ax.annotate(gerade_tex(t), (t["x0"], yl), xytext=(ox, 0), textcoords="offset points",
                                       ha="left" if ox > 0 else "right", va="center", color=farbe, fontsize=12,
                                       zorder=9, bbox=dict(boxstyle="round,pad=0.25", fc=FARBEN["label_bg"], ec=farbe,
                                                           lw=0.8, alpha=0.8))
                self._platziere(erzeuge, [(f, ox) for f in (0.85, 0.15, 0.7, 0.3) for ox in (10, -10)])
                continue
            ax.axline((t["x0"], t["y0"]), slope=t["m"], color=farbe, lw=2.0, alpha=0.95, zorder=4.5, ls=ls)
            # sichtbares Stück der Geraden bestimmen und Beschriftung darauf setzen
            g = lambda x, t=t: t["m"] * x + t["n"]
            if abs(t["m"]) < 1e-12:
                if not (y0 < t["n"] < y1):
                    continue
                xa, xb = x0, x1
            else:
                xs = sorted([(y0 - t["n"]) / t["m"], (y1 - t["n"]) / t["m"]])
                xa, xb = max(x0, xs[0]), min(x1, xs[1])
                if xa >= xb:
                    continue
            def erzeuge(kand, t=t, farbe=farbe, g=g, xa=xa, xb=xb):
                frac, oy = kand
                xl = xa + (xb - xa) * frac
                return ax.annotate(gerade_tex(t), (xl, g(xl)), xytext=(0, oy), textcoords="offset points",
                                   ha="center", va="bottom" if oy > 0 else "top", color=farbe, fontsize=12,
                                   zorder=9, bbox=dict(boxstyle="round,pad=0.25", fc=FARBEN["label_bg"], ec=farbe,
                                                       lw=0.8, alpha=0.8))
            self._platziere(erzeuge, [(f, oy) for f in (0.82, 0.18, 0.65, 0.35, 0.5) for oy in (12, -12)])

    def _zeichne_tangentenliste(self):
        """Gleichungen (f und g) gesammelt oben links; der Platz wird reserviert, damit Beschriftungen ausweichen."""
        ax, sicht = self.ax, []
        for k in ("f", "g"):
            with self._mit(k):
                sicht += self._tangenten_sichtbar()
        if not sicht:
            return
        kuenstler = [ax.annotate("Tangentengleichungen", (0, 1), xycoords="axes fraction", xytext=(10, -12),
                                 textcoords="offset points", va="top", color=FARBEN["text_dim"],
                                 fontsize=9.5, zorder=10)]
        for i, t in enumerate(sicht):
            kuenstler.append(ax.annotate(
                gerade_tex(t) + f"   ({_dez(t['x0'], 3)} | {_dez(t['y0'], 3)})", (0, 1),
                xycoords="axes fraction", xytext=(10, -32 - 24 * i), textcoords="offset points",
                va="top", color=self._t_farbe(t["typ"]), fontsize=13, zorder=10,
                bbox=dict(boxstyle="round,pad=0.2", fc=FARBEN["label_bg"], ec="none", alpha=0.75)))
        try:
            r = self.fig.canvas.get_renderer()
            self._belegt += [k.get_window_extent(r) for k in kuenstler]
        except Exception:
            pass

    def _grenz_marken_y(self) -> float:
        h = self.ylim[1] - self.ylim[0]
        return min(max(0.0, self.ylim[0] + 0.03 * h), self.ylim[1] - 0.03 * h)

    def _zeichne_grenzmarken(self):
        ax, ym = self.ax, self._grenz_marken_y()
        for g, name in ((self.a, "a"), (self.b, "b")):
            ax.plot([g], [ym], "s", ms=17, color=FARBEN["integral_pos"], mec=FARBEN["kontur"], mew=1.2, zorder=11)
            ax.text(g, ym, f"${name}$", color=FARBEN["auf_farbe"], fontsize=13, ha="center", va="center", zorder=12)
            if self._drag is not None and self._drag[0] == "grenze" and self._drag[1] == name:
                oben = self._fy(g) < 0
                ax.annotate(f"${name}$ = {_dez(g, 3)}", (g, ym), xytext=(0, 16 if oben else -16),
                            textcoords="offset points", ha="center", va="bottom" if oben else "top",
                            color=FARBEN["integral_pos"], fontsize=11, zorder=12,
                            bbox=dict(boxstyle="round,pad=0.25", fc=FARBEN["label_bg"], ec="none", alpha=0.8))

    def _info_text(self) -> str:
        """Ergebnisse aller eingeblendeten Kurven von f und g (Text für den Infobereich)."""
        def block(titel, eintraege):
            zeilen = [f"{titel} ({len(eintraege)}):"]
            if not eintraege:
                return zeilen + ["   –"]
            txt = "   ".join(eintraege)
            return zeilen + ["   " + z for z in textwrap.wrap(txt, 52)]

        g_an = self._g_sichtbar()
        z, kd = [], []
        for k in (("f", "g") if g_an else ("f",)):
            with self._mit(k):
                z.append(self._kopf_text())
                kd += list(self.kd)
        kopfzeilen = len(z)
        # nur f selbst eingeblendet: ausführlich wie bisher, sonst je Kurve kompakt mit Kopfzeile
        gruppiert = not (len(kd) == 1 and kd[0]["fn"] == "f" and kd[0]["k"] == 0)
        if not kd:
            z.append("Keine Funktion eingeblendet (Funktionsleisten).")
        for d in kd:
            e, name = d["erg"], d["name"]
            if d.get("c") is not None and not np.any(np.asarray(d["c"]) != 0):
                nullfkt = [f"{name} ist die Nullfunktion."]
            else:
                nullfkt = []
            if gruppiert:
                # Block je Kurve, abgetrennt durch eine Zeile "\x1e" (_info_setzen verteilt die Blöcke auf zwei Spalten)
                def kurz(kuerzel, eintraege):
                    return textwrap.wrap(f"{kuerzel} " + ("  ".join(eintraege) if eintraege else "–"), 36,
                                         subsequent_indent="   ")
                z += ["\x1e"] + textwrap.wrap(f"▶ {name}(x) = {d['text']}", 36, subsequent_indent="   ") + nullfkt
                if self.zeige["nullstellen"]:
                    z += kurz("N:", [_dez(x, 3) for x in e["nullstellen"]])
                if self.zeige["extrema"]:
                    z += kurz("E:", [f"{t[0]}({_dez(x, 3)}|{_dez(y, 3)})" for x, y, t in e["extrema"]] +
                              [f"S({_dez(x, 3)}|{_dez(y, 3)})" for x, y in e["sattelpunkte"]])
                if self.zeige["wende"]:
                    z += kurz("W:", [f"({_dez(x, 3)}|{_dez(y, 3)})" for x, y in e["wendepunkte"]])
                if self.zeige["integral"]:
                    kw = lambda v: _dez(v, 4) if v is not None else "–"
                    z += [f"∫ = {kw(e['integral'])}   A = {kw(e['flaeche'])}"]
                continue
            z += nullfkt
            if self.zeige["nullstellen"]:
                z += block("Nullstellen", [f"x{k}={_dez(x, 3)}" for k, x in enumerate(e["nullstellen"], 1)])
            if self.zeige["extrema"]:
                ex = [f"{t[0]}({_dez(x, 3)}|{_dez(y, 3)})" for x, y, t in e["extrema"]]
                ex += [f"S({_dez(x, 3)}|{_dez(y, 3)})" for x, y in e["sattelpunkte"]]
                z += block("Extrempunkte", ex)
            if self.zeige["wende"]:
                z += block("Wendepunkte", [f"W({_dez(x, 3)}|{_dez(y, 3)})" for x, y in e["wendepunkte"]])
            if self.zeige["integral"]:
                z += [f"Integral von {_dez(self.a, 3)} bis {_dez(self.b, 3)}:",
                      f"   ∫ {name}(x) dx = {_dez(e['integral'], 4) if e['integral'] is not None else 'nicht berechenbar'}",
                      f"   Flächeninhalt A = {_dez(e['flaeche'], 4) if e['flaeche'] is not None else 'nicht berechenbar'}"]
        if gruppiert:
            if self.zeige["integral"]:
                z.insert(kopfzeilen, f"Integrale von a = {_dez(self.a, 3)} bis b = {_dez(self.b, 3)}")
            z.append("\x1e")
        z += self._summe_text()
        for k in ("f", "g"):
            with self._mit(k):
                tp, nm = self._tp, self._nm
            if tp is None:
                continue
            if tp.get("existiert") is False:
                st = "keine Tangente (Knick)"
            elif tp.get("senkrecht"):
                st = "senkrechte Tangente"
            else:
                st = f"m = {nm['f']}'(x₀) = {_dez(tp['m'], 4)}"
            z += [f"Tangente in {nm['P']}({_dez(tp['x0'], 3)}|{_dez(tp['y0'], 3)}):", f"   {st}"]
        if self._p_meldung:
            z += ["   ⚠ " + w for w in textwrap.wrap(self._p_meldung, 50)]
        sk = self._sk
        if sk is not None:
            nm = NAMEN[sk["fn"]]["f"]
            z += [f"Sekante an {nm} durch A und B:"]
            if sk.get("fehlt"):
                z += [f"   {nm} an x_A oder x_B nicht definiert"]
            else:
                z += [f"   A({_dez(sk['xA'], 3)}|{_dez(sk['yA'], 3)})  B({_dez(sk['xB'], 3)}|{_dez(sk['yB'], 3)})",
                      f"   Δx = {_dez(sk['dx'], 4)}   Δy = {_dez(sk['dy'], 4)}"]
                if sk.get("gleich"):
                    z += ["   A und B fallen zusammen – keine Sekante"]
                else:
                    z += [f"   m = Δy/Δx = {_dez(sk['m'], 4)}", f"   s_AB(x) = {_gerade_text(sk['m'], sk['n'])}"]
        if self._sek_meldung:
            z += ["   ⚠ " + w for w in textwrap.wrap(self._sek_meldung, 50)]
        if self.zeige["schnitt"]:
            n_k = sum(len(self._fn_kd(k)) for k in ("f", "g"))
            z += [f"Schnittpunkte der Graphen ({len(self._schnitte)}):"]
            if n_k < 2:
                z += ["   mindestens zwei Graphen einblenden"]
            elif not self._schnitte:
                z += ["   keine im sichtbaren Bereich"]
            z += [f"   {q['A']['name']} ∩ {q['B']['name']}: ({_dez(q['x'], 3)}|{_dez(q['y'], 3)})" for q in self._schnitte]
        if self.zeige["yachse"]:
            z += ["y-Achsenabschnitte:"]
            z += [f"   {d['name']}(0) = {_dez(y, 3) if np.isfinite(y) else 'nicht definiert'}" for d, y in self._y_abschnitte_berechnen()]
        if self.zeige["trace"]:
            x = self._trace["x"]
            z += [f"Trace an der Stelle x = {_dez(x, 3)}:"]
            for d, y in self._trace_werte():
                z += [f"   {d['name']}({_dez(x, 3)}) = {_dez(y, 4) if np.isfinite(y) else 'nicht definiert'}"
                      + ("   (Spur)" if self._spur_von(d) else "")]
            if self._tr_meldung:
                z += ["   ⚠ " + w for w in textwrap.wrap(self._tr_meldung, 50)]
        return "\n".join(z)

    def _boxen_aktualisieren(self):
        """Felder der bearbeiteten (geladenen) Funktion, Grenzen und beide Termfelder nachführen."""
        self._sperre = True
        for i, tb in enumerate(self.boxen):
            sichtbar = i <= self.n
            tb.ax.set_visible(sichtbar)
            if sichtbar:
                s = _zahl_text(self.c[i])
                if tb.text != s and not tb.capturekeystrokes:
                    tb.set_val(s)
        if int(round(self.slider.val)) != self.n:
            self.slider.set_val(self.n)
        for tb, v in ((self.box_a, self.a), (self.box_b, self.b)):
            if not tb.capturekeystrokes and tb.text != _zahl_text(v):
                tb.set_val(_zahl_text(v))
        if not self.box_n.capturekeystrokes and self.box_n.text != str(self.summe_n):
            self.box_n.set_val(str(self.summe_n))
        for sl in getattr(self, "n_regler", []):          # beide Schieberegler auf n nachführen
            if self._regler_n(sl.val) != self.summe_n:
                sl.set_val(math.log10(self.summe_n))
            sl.valtext.set_text(str(self.summe_n))
        # Koordinaten von P bzw. Q (auch beim Ziehen laufend aktualisiert)
        yp = float(np.asarray(self._f(np.array([self.t_x])), dtype=float)[0])
        for tb, txt in ((self.box_px, _zahl_text(self.t_x)), (self.box_py, _zahl_text(yp) if np.isfinite(yp) else "–")):
            if not tb.capturekeystrokes and tb.text != txt:
                tb.set_val(txt)
        tr_an = self.zeige["trace"]
        for schl, tb in self.trace_boxen.items():
            tb.ax.set_visible(tr_an)
            if tr_an and not tb.capturekeystrokes:
                x = self._trace["x"]
                y = self._wert(x) if self._kv["f"] else float("nan")
                txt = _zahl_text(x) if schl == "x" else (_zahl_text(y) if np.isfinite(y) else "–")
                if tb.text != txt:
                    tb.set_val(txt)
        sek_an = self.zeige["sekante"]
        for schl, tb in self.sek_boxen.items():
            tb.ax.set_visible(sek_an)
            if sek_an and not tb.capturekeystrokes:
                x = self.sek["x" + schl[1]]
                y = self._wert(x)
                txt = _zahl_text(x) if schl[0] == "x" else (_zahl_text(y) if np.isfinite(y) else "–")
                if tb.text != txt:
                    tb.set_val(txt)
        self._sperre = False
        for k in ("f", "g"):
            with self._mit(k):
                self._termfeld_setzen(self._term_text(), k)

    def _termfeld_setzen(self, text: str, k: str | None = None):
        """Termfeld von f bzw. g (Standard: geladene Funktion) setzen, ohne eine Eingabe auszulösen."""
        tb = getattr(self, "term_boxen", {}).get(k or self._geladen)
        if tb is None or tb.capturekeystrokes or tb.text == text:
            return
        sperre, self._sperre = self._sperre, True
        tb.set_val(text)
        tb.cursor_index = len(text)
        self._sperre = sperre

    # ------------------------------------------------------------ ereignisse
    def _term_eingabe(self, k: str, text: str) -> None:
        """Eingabe im Termfeld f(x) = … bzw. g(x) = …"""
        if self._sperre:
            return
        self._letztes_termfeld = k
        try:
            with self._mit(k):
                self._term_setzen(text)
                if k == "g" and not any(self._kv.values()):      # g sichtbar machen
                    self._kv["f"] = True
        except ValueError as e:
            self._status_fehler = f"⚠ {k}(x): {e}"
            self.status.set_text(self._status_fehler)
            self.status.set_color(FARBEN["nullstelle"])
            self.fig.canvas.draw_idle()
            return
        self._status_fehler = ""
        self._kurven_knoepfe_stil()
        self.aktualisiere()

    def _stuetz_verteilen(self):
        """Verteilt n+1 Stützpunkte so, dass alle im sichtbaren Teil des Graphen liegen."""
        breite = self.xlim[1] - self.xlim[0]
        hoehe = self.ylim[1] - self.ylim[0]
        xs = np.linspace(self.xlim[0] + 0.04 * breite, self.xlim[1] - 0.04 * breite, 2000)
        ys = P.polyval(xs, self.c)
        sichtbar = xs[(ys > self.ylim[0] + 0.04 * hoehe) & (ys < self.ylim[1] - 0.04 * hoehe)]
        if sichtbar.size < 50:
            sichtbar = xs
        if self.n == 0:
            self.stuetz_x = np.array([np.median(sichtbar)])
        else:
            q = np.linspace(0.04, 0.96, self.n + 1)
            self.stuetz_x = sichtbar[(q * (sichtbar.size - 1)).astype(int)].copy()
        self.stuetz_y = P.polyval(self.stuetz_x, self.c)

    def _stuetz_alle(self):
        for k in ("f", "g"):
            with self._mit(k):
                if self._polynom_modus():
                    self._stuetz_verteilen()

    def _grad_geaendert(self, val):
        if self._sperre:
            return
        n = int(round(val))
        if n == self.n:
            return
        self.n = n
        self.c = np.asarray(standard_polynom(n), dtype=float)
        self._stuetz_verteilen()
        self._polynom_geaendert()
        self.aktualisiere()

    def _koeff_eingabe(self, i, txt):
        if self._sperre:
            return
        try:
            self.c[i] = self._zahl_lesen(txt)
        except ValueError:
            pass  # ungültig -> alter Wert wird wieder angezeigt
        self.stuetz_y = P.polyval(self.stuetz_x, self.c)
        self._polynom_geaendert()
        self.aktualisiere()

    def _stellen_mit_wert(self, y: float) -> list[float]:
        """Alle Stellen x mit f(x) = y (Polynom: exakt über die Nullstellen von f − y)."""
        c = np.asarray(self.c, dtype=float).copy()
        c[0] -= y
        if not np.any(c[1:] != 0):                 # konstante Funktion
            return [self.t_x] if abs(c[0]) < 1e-12 else []
        return _reelle_nullstellen(c)

    def _p_eingabe(self, welche: str, txt: str) -> None:
        """x_P oder y_P (bzw. x_Q, y_Q) eingegeben: Punkt setzen, Tangente einblenden, Ansicht nachführen."""
        if self._sperre:
            return
        self._p_meldung = ""
        fn, P_ = self._nm["f"], self._nm["P"]
        try:
            v = self._zahl_lesen(txt)
        except ValueError:
            self._p_meldung = "Ungültige Eingabe"
            self.aktualisiere()
            return
        if welche == "x":
            y = float(np.asarray(self._f(np.array([v])), dtype=float)[0])
            if not np.isfinite(y):
                self._p_meldung = f"{fn}(x) bei x = {_dez(v, 3)} nicht definiert"
                self.aktualisiere()
                return
            self.t_x = float(v)
        else:
            stellen = self._stellen_mit_wert(v)
            if not stellen:
                self._p_meldung = f"y = {_dez(v, 3)} wird von {fn} nicht angenommen"
                self.aktualisiere()
                return
            self.t_x = float(min(stellen, key=lambda x: abs(x - self.t_x)))
            if len(stellen) > 1:
                self._p_meldung = f"{len(stellen)} Stellen mit {fn}(x) = {_dez(v, 3)}, die zu {P_} nächste gewählt"
        # Punkt in den sichtbaren Bereich holen (Ansicht verschieben, Maßstab bleibt)
        yp = float(np.asarray(self._f(np.array([self.t_x])), dtype=float)[0])
        bx, by = self.xlim[1] - self.xlim[0], self.ylim[1] - self.ylim[0]
        if not (self.xlim[0] < self.t_x < self.xlim[1] and self.ylim[0] < yp < self.ylim[1]):
            self.xlim = [self.t_x - bx / 2, self.t_x + bx / 2]
            self.ylim = [yp - by / 2, yp + by / 2]
            self._stuetz_alle()
        self.zeige["t_frei"] = True
        self._schalter_stil()
        self.aktualisiere()

    def _grenze_eingabe(self, welche, txt):
        if self._sperre:
            return
        try:
            setattr(self, welche, self._zahl_lesen(txt))
        except ValueError:
            pass
        self.aktualisiere()

    @staticmethod
    def _knopf_stil(btn, farbe, an):
        btn.color = farbe if an else FARBEN["aus"]
        btn.ax.set_facecolor(btn.color)
        btn.label.set_color(FARBEN["auf_farbe"] if an else FARBEN["text_dim"])

    def _umschalten(self, schl, farbe=None):
        self.zeige[schl] = not self.zeige[schl]
        if schl == "t_frei" and self.zeige[schl]:
            self._p_sichtbar_machen()
        if schl == "trace":
            if not self.zeige[schl]:
                self._abspielen(False)
            self._trace["spur"] = {}
            self._tr_meldung = ""
            if self.zeige[schl]:
                self._trace_platzieren()
        if schl == "sekante":
            self._sek_meldung = ""
            if self.zeige[schl]:
                self._sek_platzieren()
        if schl.startswith("s_"):                      # höchstens eine Summe gleichzeitig
            for k in SUMMEN_ARTEN:
                if "s_" + k != schl:
                    self.zeige["s_" + k] = False
            self._sum_hover = None
            self._sum_meldung = ""
            self._schalter_stil()
        btn, farbe = self.knoepfe[schl]
        self._knopf_stil(btn, farbe, self.zeige[schl])
        self.aktualisiere()

    def _zuruecksetzen(self):
        self.xlim, self.ylim = [-6.5, 6.5], [-4.0, 4.0]
        self.a, self.b = -1.0, 1.0
        for k, c in (("f", None), ("g", STANDARD_G)):
            with self._mit(k):
                self.c = np.asarray(standard_polynom(self.n) if c is None else c, dtype=float)
                self.n = len(self.c) - 1
                self._stuetz_verteilen()
                self._polynom_geaendert()
        self._status_fehler = ""
        self.aktualisiere()

    # ------------------------------------------------------------ Sekante durch A und B
    def _wert(self, x: float) -> float:
        """Funktionswert der geladenen Funktion (nan, wo nicht definiert)."""
        try:
            with np.errstate(all="ignore"):
                return float(np.asarray(self._f(np.array([float(x)])), dtype=float)[0])
        except Exception:
            return float("nan")

    def _fn_kd(self, k: str) -> list:
        with self._mit(k):
            return list(self.kd)

    def _kurven_wert(self, d: dict, x: float) -> float:
        try:
            with np.errstate(all="ignore"):
                return float(np.asarray(d["f"](np.array([float(x)])), dtype=float).ravel()[0])
        except Exception:
            return float("nan")

    def _im_spur(self, d: dict, x: float) -> bool:
        sp = self._spur_von(d)
        return not sp or any(a_ - 1e-9 <= x <= b_ + 1e-9 for a_, b_ in sp)

    def _nullstellen_numerisch(self, g, x0: float, x1: float) -> list[float]:
        """Nullstellen von g im Bereich [x0; x1] (nur für allgemeine Funktionen; der Polynom-Explorer braucht das nicht)."""
        return []

    def _schnittpunkte_berechnen(self) -> list[dict]:
        """Schnittpunkte aller sichtbaren Graphen (paarweise; Polynome exakt, sonst numerisch) im sichtbaren Bereich."""
        L = self._fn_kd("f") + self._fn_kd("g")
        x0, x1 = self.xlim
        res = []
        for i in range(len(L)):
            for j in range(i + 1, len(L)):
                A, B = L[i], L[j]
                if A.get("c") is not None and B.get("c") is not None:
                    ca, cb = np.asarray(A["c"], dtype=float), np.asarray(B["c"], dtype=float)
                    n = max(len(ca), len(cb))
                    d = np.zeros(n)
                    d[:len(ca)] += ca
                    d[:len(cb)] -= cb
                    sk = max(1e-300, float(np.max(np.abs(ca))), float(np.max(np.abs(cb))))
                    if np.all(np.abs(d) <= 1e-12 * sk):
                        continue                                   # gleiche Graphen
                    d[np.abs(d) <= 1e-13 * sk] = 0.0
                    d = _trim(d)
                    xs = _reelle_nullstellen(d) if len(d) > 1 else []
                else:
                    def g(x, A=A, B=B):
                        with np.errstate(all="ignore"):
                            return np.asarray(A["f"](np.asarray(x, dtype=float)), dtype=float) - \
                                np.asarray(B["f"](np.asarray(x, dtype=float)), dtype=float)
                    xs = []
                    for x in self._nullstellen_numerisch(g, x0, x1):
                        a, b = self._kurven_wert(A, x), self._kurven_wert(B, x)
                        if np.isfinite(a) and np.isfinite(b) and abs(a - b) <= 1e-6 * (1 + abs(a) + abs(b)):
                            xs.append(x)
                for x in xs:
                    if not (x0 <= x <= x1) or not self._im_spur(A, x) or not self._im_spur(B, x):
                        continue
                    y = self._kurven_wert(A, x)
                    if np.isfinite(y):
                        res.append({"x": 0.0 if abs(x) < 1e-12 else float(x), "y": 0.0 if abs(y) < 1e-12 else y, "A": A, "B": B})
        return sorted(res, key=lambda q: q["x"])

    def _y_abschnitte_berechnen(self) -> list:
        """[(Kurve, y), …]: Schnittpunkte aller sichtbaren Graphen mit der y-Achse."""
        out = []
        for d in self._fn_kd("f") + self._fn_kd("g"):
            if self._im_spur(d, 0.0):
                y = self._kurven_wert(d, 0.0)
                out.append((d, 0.0 if abs(y) < 1e-12 else y))
        return out

    def _abspielen(self, an: bool) -> None:
        """Trace-Punkt gleichmäßig nach rechts laufen lassen (ganze Bildbreite in 8 s), am rechten Rand anhalten."""
        if an:
            if not self.zeige["trace"]:
                self.zeige["trace"] = True
                self._trace["spur"] = {}
                self._trace_platzieren()
                self._schalter_stil()
            ende = self.xlim[0] + 0.97 * (self.xlim[1] - self.xlim[0])
            if self._trace["x"] >= ende - 1e-9:          # am rechten Rand: von vorn beginnen, Spuren neu aufbauen
                self._trace_platzieren()
                x = self._trace["x"]
                for sid in self._trace["spur"]:
                    self._trace["spur"][sid] = [[x, x]]
            if self._timer is None:
                self._timer = self.fig.canvas.new_timer(interval=40)
                self._timer.add_callback(self._abspiel_schritt)
            self._spielt = True
            self._timer.start()
        else:
            self._spielt = False
            if self._timer is not None:
                self._timer.stop()
        if hasattr(self, "_play_knopf"):
            self._play_knopf.label.set_text("‖ Anhalten" if self._spielt else "▶ Abspielen")
            self.fig.canvas.draw_idle()

    def _abspiel_schritt(self) -> None:
        if not self._spielt or not self.zeige["trace"]:
            self._abspielen(False)
            return
        breite = self.xlim[1] - self.xlim[0]
        ende = self.xlim[0] + 0.97 * breite
        x = min(self._trace["x"] + breite * 0.040 / 8.0, ende)
        self._trace_setzen(x)
        self.aktualisiere()
        if x >= ende:
            self._abspielen(False)

    def _spur_von(self, d: dict):
        """Überstrichene x-Intervalle einer Spur-Kurve (None, wenn die Kurve vollständig gezeichnet wird)."""
        if not self.zeige["trace"]:
            return None
        return self._trace["spur"].get(f"{d['fn']}:{d['schl']}")

    def _spur_schalten(self, fn: str, schl: str, an: bool) -> None:
        """Kurve bei laufendem Trace eingeschaltet -> Spur ab der Trace-Stelle; ausgeschaltet -> Spur löschen."""
        sid = f"{fn}:{schl}"
        if not self.zeige["trace"] or not an:
            self._trace["spur"].pop(sid, None)
            return
        x = self._trace["x"]
        self._trace["spur"][sid] = [[x, x]]

    def _trace_setzen(self, x: float) -> None:
        """Trace-Punkt nach x bewegen; der überstrichene Bereich wird allen Spuren hinzugefügt."""
        lo, hi = sorted((self._trace["x"], x))
        for sid, iv in self._trace["spur"].items():
            neu = []
            for a_, b_ in sorted(iv + [[lo, hi]]):
                if neu and a_ <= neu[-1][1]:
                    neu[-1][1] = max(neu[-1][1], b_)
                else:
                    neu.append([a_, b_])
            self._trace["spur"][sid] = neu
        self._trace["x"] = x

    def _trace_platzieren(self) -> None:
        """Startpunkt des Trace unten links im Grafikfenster (auf eine Viertel-Gitterweite gerundet)."""
        x = self.xlim[0] + 0.15 * (self.xlim[1] - self.xlim[0])
        ticks = self.ax.xaxis.get_major_locator().tick_values(*self.xlim) if hasattr(self, "ax") else []
        schritt = (ticks[1] - ticks[0]) / 4 if len(ticks) > 1 else 0.25
        self._trace["x"] = float(round(x / schritt) * schritt) + 0.0

    def _trace_achse_y(self) -> float:
        h = self.ylim[1] - self.ylim[0]
        return min(max(0.0, self.ylim[0] + 0.02 * h), self.ylim[1] - 0.02 * h)

    def _trace_werte(self) -> list:
        """[(Kurve, y), …] aller sichtbaren Kurven von f und g an der Trace-Stelle."""
        x, out = self._trace["x"], []
        for k in ("f", "g"):
            with self._mit(k):
                for d in self.kd:
                    try:
                        with np.errstate(all="ignore"):
                            y = float(np.asarray(d["f"](np.array([x])), dtype=float).ravel()[0])
                    except Exception:
                        y = float("nan")
                    out.append((d, y))
        return out

    def _trace_eingabe(self, welche: str, txt: str) -> None:
        """x bzw. y = f(x) des Trace-Punkts eingegeben (y: nächstgelegene Stelle der bearbeiteten Funktion)."""
        if self._sperre:
            return
        self._tr_meldung = ""
        fn = NAMEN[self.akt]["f"]
        try:
            v = self._zahl_lesen(txt)
        except ValueError:
            self._tr_meldung = "Ungültige Eingabe"
            self.aktualisiere()
            return
        if welche == "x":
            self._trace_setzen(float(v))
        elif not self._kv["f"]:
            self._tr_meldung = f"{fn} ist ausgeblendet – y bezieht sich auf {fn}(x)"
        else:
            stellen = self._stellen_mit_wert(v)
            if not stellen:
                self._tr_meldung = f"y = {_dez(v, 3)} wird von {fn} nicht angenommen"
            else:
                alt = self._trace["x"]
                self._trace_setzen(float(min(stellen, key=lambda x: abs(x - alt))))
                if len(stellen) > 1:
                    self._tr_meldung = f"{len(stellen)} Stellen mit {fn}(x) = {_dez(v, 3)}, nächste gewählt"
        self.aktualisiere()

    def _zeichne_trace(self) -> None:
        """Gestrichelte Senkrechte an der Trace-Stelle, Punkt auf der x-Achse und auf allen sichtbaren Graphen."""
        if not self.zeige["trace"]:
            return
        ax, col, x = self.ax, FARBEN["trace"], self._trace["x"]
        ym = self._trace_achse_y()
        ax.axvline(x, color=col, lw=1.4, ls=(0, (6, 5)), alpha=0.85, zorder=8.5)
        werte = [(d, y) for d, y in self._trace_werte() if np.isfinite(y)]
        for d, y in werte:
            ax.plot([x], [y], "o", ms=9, color=FARBEN[d["farbe"]], mec=FARBEN["kontur"], mew=1.2, zorder=10)
        ax.plot([x], [ym], "o", ms=10, color=col, mec=FARBEN["kontur"], mew=1.2, zorder=10)
        gross = self._drag is not None and self._drag[0] == "trace"
        ax.plot([x], [ym], "o", ms=20 if gross else 17, mfc="none", mec=col, mew=1.6, alpha=0.75, zorder=10)

        def etikett(text, farbe, y, versaetze):
            def erzeuge(k):
                ox, oy = k
                return ax.annotate(text, (x, y), xytext=(ox, oy), textcoords="offset points",
                                   ha="left" if ox > 0 else "right", va="center", color=farbe, fontsize=9.5, zorder=11,
                                   bbox=dict(boxstyle="round,pad=0.2", fc=FARBEN["label_bg"], ec="none", alpha=0.85))
            self._platziere(erzeuge, versaetze)
        etikett(f"({_dez(x, 2)}|0)", col, ym, [(9, -12), (-9, -12), (9, 12), (-9, 12)])
        for d, y in werte:
            if self.ylim[0] <= y <= self.ylim[1]:
                etikett(f"{d['name']}: ({_dez(x, 2)}|{_dez(y, 2)})", FARBEN[d["farbe"]], y,
                        [(9, 9), (-9, 9), (9, -9), (-9, -9), (9, 22), (-9, 22), (9, -22), (-9, -22)])

    # ------------------------------------------------------------ Riemann-Summen
    def _n_setzen(self, n) -> None:
        try:
            k = int(str(n).strip()) if not isinstance(n, (int, np.integer)) else int(n)
        except ValueError:
            raise ValueError(f"n muss eine ganze Zahl von 1 bis {SUMMEN_N_MAX} sein") from None
        if not (1 <= k <= SUMMEN_N_MAX) or (isinstance(n, float) and n != k):
            raise ValueError(f"n muss eine ganze Zahl von 1 bis {SUMMEN_N_MAX} sein")
        self.summe_n = k
        self._sum_hover = None
        self._sum_meldung = ""

    @staticmethod
    def _regler_n(wert: float) -> int:
        """Stellung des (logarithmischen) Schiebereglers -> n = 1 … 1000."""
        return max(1, min(SUMMEN_N_MAX, int(math.floor(10 ** float(wert) + 0.5))))

    def _n_regler_bewegt(self, wert) -> None:
        """Schieberegler für n bewegt: n setzen, den anderen Regler und das Feld n nachführen."""
        if self._sperre:
            return
        n = self._regler_n(wert)
        for sl in self.n_regler:
            sl.valtext.set_text(str(n))
        if n == self.summe_n:
            self.fig.canvas.draw_idle()
            return
        self.summe_n, self._sum_hover, self._sum_meldung = n, None, ""
        self._sperre = True
        for sl in self.n_regler:
            if self._regler_n(sl.val) != n:
                sl.set_val(math.log10(n))
            sl.valtext.set_text(str(n))
        self._sperre = False
        self.aktualisiere()

    def _n_regler_stil(self) -> None:
        for sl in getattr(self, "n_regler", []):
            sl.ax.set_facecolor(FARBEN["feld"])
            sl.poly.set_color(FARBEN["summe"])
            if hasattr(sl, "track"):
                sl.track.set_facecolor(FARBEN["feld"])
            if hasattr(sl, "_handle"):
                sl._handle.set_markerfacecolor(FARBEN["summe"])
                sl._handle.set_markeredgecolor(FARBEN["kontur"])
            sl.label.set_color(FARBEN["text"])
            sl.valtext.set_color(FARBEN["summe"])

    def _n_eingabe(self, txt: str) -> None:
        """Anzahl n der Teilintervalle eingegeben."""
        if self._sperre:
            return
        try:
            self._n_setzen(txt)
            self._sum_meldung = ""
        except ValueError as e:
            self._sum_meldung = str(e)
        self.aktualisiere()

    def _summe_berechnen(self):
        """Eingeblendete Riemann-Summe der geladenen (bearbeiteten) Funktion oder None."""
        art = self.summe_art
        if art is None or not self._kv["f"]:
            return None
        r = riemann_summe(self._f, self.a, self.b, self.summe_n, art, self._kritische_stellen())
        r["fn"] = self._geladen
        r["integral"] = self.erg["integral"] if self.erg else None
        return r

    def _summe_text(self) -> list[str]:
        art = self.summe_art
        if art is None:
            return []
        fn, s = NAMEN[self.akt]["f"], self._summe
        z = [f"{SUMMEN_ARTEN[art]} von {fn} über [{_dez(self.a, 3)}; {_dez(self.b, 3)}]:"]
        if self._sum_meldung:
            z += ["   ⚠ " + self._sum_meldung]
        if s is None:
            return z + [f"   {fn} ist ausgeblendet (Funktionsleiste)"]
        if s.get("fehlt"):
            x0, x1 = s["fehlt"]
            return z + [f"   {fn} in [{_dez(x0, 3)}; {_dez(x1, 3)}] nicht überall definiert"]
        zn = f"{s['zeichen']}_{s['n']}"
        z += [f"   n = {s['n']}   Δx = {_dez(s['dx'], 4)}   {zn} = {_dez(s['wert'], 6)}"]
        if s.get("integral") is not None:
            z += [f"   ∫ {fn}(x) dx = {_dez(s['integral'], 6)}   {zn} − ∫ = {_dez(s['wert'] - s['integral'], 6)}"]
        if self.a > self.b:
            z += ["   a > b: Vorzeichen umgekehrt (wie beim Integral)"]
        return z + ["   Maus über ein " + ("Trapez" if art == "trapez" else "Rechteck") + ": Anteil an der Summe"]

    def _zeichne_summe(self) -> None:
        """Rechtecke bzw. Trapeze der Summe, Stellen ξ (bis n = 60), Gesamtwert oben rechts und die (unsichtbare) Anteil-Anzeige."""
        from matplotlib.collections import PolyCollection
        self._sum_patches, self._sum_tip = None, None
        s = self._summe
        if s is None or s.get("fehlt"):
            return
        ax, wenige = self.ax, s["n"] <= 60
        flaechen = []
        for t in s["teile"]:
            if s["art"] == "trapez":
                flaechen.append([(t["x0"], 0.0), (t["x0"], t["y0"]), (t["x1"], t["y1"]), (t["x1"], 0.0)])
            else:
                flaechen.append([(t["x0"], 0.0), (t["x0"], t["h"]), (t["x1"], t["h"]), (t["x1"], 0.0)])
        # alle Rechtecke/Trapeze in einer Sammlung (schnell auch bei n = 500); das Feld unter der Maus wird hervorgehoben
        self._sum_patches = PolyCollection(flaechen, closed=True, zorder=3.6)
        ax.add_collection(self._sum_patches)
        self._patch_stil(self._sum_hover)
        if wenige and s["art"] != "trapez":
            for t in s["teile"]:
                ax.plot([t["xi"]], [t["h"]], "o", ms=5, color=FARBEN["summe_neg"] if t["h"] < 0 else FARBEN["summe"],
                        mec=FARBEN["kontur"], mew=0.8, zorder=3.7)
        zeile2 = f"n = {s['n']}  ·  Δx = {_dez(s['dx'], 4)}"
        if s.get("integral") is not None:
            zeile2 += f"  ·  ∫ = {_dez(s['integral'], 4)}"
        kasten = ax.annotate(f"{s['name']} ${s['zeichen']}_{{{s['n']}}}$ = {_dez(s['wert'], 4)}\n{zeile2}", (1, 1),
                             xycoords="axes fraction", xytext=(-10, -10), textcoords="offset points", ha="right", va="top",
                             color=FARBEN["summe"], fontsize=11, zorder=12, linespacing=1.5,
                             bbox=dict(boxstyle="round,pad=0.4", fc=FARBEN["label_bg"], ec=FARBEN["summe"], lw=1.0, alpha=0.88))
        try:
            self._belegt.append(kasten.get_window_extent(self.fig.canvas.get_renderer()))
        except Exception:
            pass
        self._sum_tip = ax.annotate("", (0, 0), xytext=(14, 14), textcoords="offset points", fontsize=9.5, zorder=20,
                                    color=FARBEN["text"], linespacing=1.45, visible=False, annotation_clip=False,
                                    bbox=dict(boxstyle="round,pad=0.45", fc=FARBEN["panel"], ec=FARBEN["summe"], lw=1.2, alpha=0.96))
        if self._sum_hover is not None:
            self._tip_setzen(self._sum_hover)

    def _patch_stil(self, hover=None) -> None:
        """Farben der Rechtecke/Trapeze setzen (über/unter der x-Achse); hover = hervorgehobenes Feld."""
        from matplotlib.colors import to_rgba
        s, pc = self._summe, self._sum_patches
        if pc is None or s is None or s.get("fehlt"):
            return
        dicke = 1.4 if s["n"] <= 60 else 0.8
        fl, rand, lw = [], [], []
        for i, t in enumerate(s["teile"]):
            farbe = FARBEN["summe_neg"] if t["h"] < 0 else FARBEN["summe"]
            an = i == hover
            fl.append(to_rgba(farbe, min(1.0, 2.2 * FARBEN["summe_alpha"]) if an else FARBEN["summe_alpha"]))
            rand.append(to_rgba(farbe, 1.0))
            lw.append(2.6 if an else dicke)
        pc.set_facecolors(fl)
        pc.set_edgecolors(rand)
        pc.set_linewidths(lw)

    def _summe_treffer(self, x: float, y: float):
        """Index des Rechtecks/Trapezes, über dem (x, y) liegt (oder None)."""
        s = self._summe
        if s is None or s.get("fehlt"):
            return None
        tol = 3 * (self.ylim[1] - self.ylim[0]) / max(self.ax.bbox.height, 1)
        for i, t in enumerate(s["teile"]):
            if x < t["x0"] or x > t["x1"]:
                continue
            if s["art"] == "trapez":
                breite = t["x1"] - t["x0"]
                oben = t["y0"] + (t["y1"] - t["y0"]) * (x - t["x0"]) / breite if breite else t["y0"]
            else:
                oben = t["h"]
            return i if min(0.0, oben) - tol <= y <= max(0.0, oben) + tol else None
        return None

    def _tip_setzen(self, i: int) -> None:
        """Anteil-Anzeige am Rechteck/Trapez i (absolut und in Prozent)."""
        s, tip = self._summe, self._sum_tip
        if tip is None or s is None or s.get("fehlt"):
            return
        t, fn = s["teile"][i], NAMEN[s["fn"]]["f"]
        form = "Trapez" if s["art"] == "trapez" else "Rechteck"
        if s["art"] == "trapez":
            hoehe = f"{fn}({_dez(t['x0'], 3)}) = {_dez(t['y0'], 4)},  {fn}({_dez(t['x1'], 3)}) = {_dez(t['y1'], 4)}"
        else:
            hoehe = f"Höhe {fn}({_dez(t['xi'], 3)}) = {_dez(t['h'], 4)}"
        pz = f"{_dez(100 * t['anteil'], 2)} %" if np.isfinite(t["anteil"]) else "–"
        tip.set_text(f"{form} {i + 1} von {s['n']}:  [{_dez(t['x0'], 3)}; {_dez(t['x1'], 3)}]\n{hoehe}\n"
                     f"Anteil: {_dez(t['wert'], 4)}  =  {pz}  von  {s['zeichen']}_{s['n']} = {_dez(s['wert'], 4)}")
        xm = (t["x0"] + t["x1"]) / 2
        ym = t["h"] if s["art"] != "trapez" else (t["y0"] + t["y1"]) / 2
        rechts = (xm - self.xlim[0]) / (self.xlim[1] - self.xlim[0]) > 0.6
        oben = (ym - self.ylim[0]) / (self.ylim[1] - self.ylim[0]) > 0.7
        tip.xy = (xm, min(max(ym, self.ylim[0]), self.ylim[1]))
        tip.set_position((-14 if rechts else 14, -14 if oben else 14))
        tip.set_ha("right" if rechts else "left")
        tip.set_va("top" if oben else "bottom")
        tip.set_visible(True)

    def _summe_hover(self, ev) -> None:
        """Mauszeiger über einem Rechteck/Trapez: hervorheben und Anteil zeigen; sonst Anzeige ausblenden."""
        i = None
        if ev is not None and getattr(ev, "inaxes", None) is self.ax and ev.xdata is not None:
            i = self._summe_treffer(ev.xdata, ev.ydata)
        if i == self._sum_hover:
            return
        self._sum_hover = i
        self._patch_stil(i)
        if i is not None:
            self._tip_setzen(i)
        elif self._sum_tip is not None:
            self._sum_tip.set_visible(False)
        self.fig.canvas.draw_idle()

    def _sek_platzieren(self) -> bool:
        """A und B unten links im gerade sichtbaren Teil des Graphen der bearbeiteten Funktion platzieren."""
        (x0, x1), (y0, y1) = self.xlim, self.ylim
        bx, by = x1 - x0, y1 - y0
        xs = x0 + bx * (0.1 + 0.8 * np.arange(401) / 400)
        with np.errstate(all="ignore"):
            ys = np.asarray(self._f(xs), dtype=float)
        ok = np.isfinite(ys) & (ys > y0 + 0.1 * by) & (ys < y1 - 0.1 * by)
        vis = [(float(x), float(y)) for x, y in zip(xs[ok], ys[ok])]
        if len(vis) < 2:
            self.sek["xA"], self.sek["xB"] = x0 + 0.2 * bx, x0 + 0.42 * bx
            return False
        A = min(vis, key=lambda q: (q[0] - x0) / bx + (q[1] - y0) / by)          # klein = unten links
        pool = ([q for q in vis if q[0] > A[0] + 0.08 * bx] or [q for q in vis if q[0] < A[0] - 0.08 * bx]
                or [q for q in vis if q[0] != A[0]])
        richtung = 1.0 if pool[0][0] > A[0] else -1.0
        naechster = lambda ziel: min(pool, key=lambda q: abs(q[0] - ziel))
        B = None
        for t in (0.25, 0.2, 0.3, 0.15, 0.35, 0.4, 0.5):    # möglichst so, dass Δy gut sichtbar ist
            q = naechster(A[0] + richtung * t * bx)
            if abs(q[1] - A[1]) >= 0.1 * by:
                B = q
                break
        if B is None:
            B = naechster(A[0] + richtung * 0.25 * bx)
        ticks = self.ax.xaxis.get_major_locator().tick_values(*self.xlim) if hasattr(self, "ax") else []
        schritt = (ticks[1] - ticks[0]) / 4 if len(ticks) > 1 else 0.25           # Viertel-Gitterweite
        def rund(x):
            r = float(round(x / schritt) * schritt) + 0.0
            return r if np.isfinite(self._wert(r)) else float(x)
        self.sek["xA"], self.sek["xB"] = rund(A[0]), rund(B[0])
        if self.sek["xA"] == self.sek["xB"]:
            self.sek["xB"] = B[0]
        return True

    def _sekante_berechnen(self):
        """Sekante durch A(x_A | f(x_A)) und B(x_B | f(x_B)) der geladenen (bearbeiteten) Funktion."""
        if not self.zeige["sekante"] or not self._kv["f"]:
            return None
        xA, xB = self.sek["xA"], self.sek["xB"]
        yA, yB = self._wert(xA), self._wert(xB)
        d = {"xA": xA, "yA": yA, "xB": xB, "yB": yB, "fn": self._geladen}
        if not (np.isfinite(yA) and np.isfinite(yB)):
            return {**d, "fehlt": True}
        xA, xB = float(xA), float(xB)
        d["xA"], d["xB"] = xA, xB
        dx, dy = xB - xA, yB - yA
        if abs(dx) < 1e-12:
            return {**d, "dx": 0.0, "dy": dy, "gleich": True}
        m = dy / dx
        m = 0.0 if abs(m) < 1e-12 else m
        n = yA - m * xA
        n = 0.0 if abs(n) < 1e-12 else n
        return {**d, "dx": dx, "dy": dy, "m": m, "n": n}

    def _sek_eingabe(self, welche: str, P_: str, txt: str) -> None:
        """x_A, y_A, x_B oder y_B eingegeben (y: nächstgelegene Stelle mit f(x) = y)."""
        if self._sperre:
            return
        self._sek_meldung = ""
        fn, key = NAMEN[self.akt]["f"], "x" + P_
        try:
            v = self._zahl_lesen(txt)
        except ValueError:
            self._sek_meldung = "Ungültige Eingabe"
            self.aktualisiere()
            return
        if welche == "x":
            if not np.isfinite(self._wert(v)):
                self._sek_meldung = f"{fn}(x) bei x = {_dez(v, 3)} nicht definiert"
            else:
                self.sek[key] = float(v)
        else:
            stellen = self._stellen_mit_wert(v)
            if not stellen:
                self._sek_meldung = f"y = {_dez(v, 3)} wird von {fn} nicht angenommen"
            else:
                alt = self.sek[key]
                self.sek[key] = float(min(stellen, key=lambda x: abs(x - alt)))
                if len(stellen) > 1:
                    self._sek_meldung = f"{len(stellen)} Stellen mit {fn}(x) = {_dez(v, 3)}, die zu {P_} nächste gewählt"
        self.aktualisiere()

    def _zeichne_sekante(self):
        """Sekante, Steigungsdreieck (Δx waagerecht von A aus, Δy senkrecht bis B), Punkte A, B und Beschriftungen."""
        s = self._sk
        if s is None or s.get("fehlt"):
            return
        ax, col = self.ax, FARBEN["sekante"]
        xA, yA, xB, yB = s["xA"], s["yA"], s["xB"], s["yB"]

        def schild(text, kandidaten, groesse=11):
            def erzeuge(k):
                (x, y), (ox, oy), ha, va = k
                return ax.annotate(text, (x, y), xytext=(ox, oy), textcoords="offset points", ha=ha, va=va,
                                   color=col, fontsize=groesse, zorder=9.5,
                                   bbox=dict(boxstyle="round,pad=0.25", fc=FARBEN["label_bg"], ec=col, lw=0.8, alpha=0.88))
            self._platziere(erzeuge, kandidaten)

        if not s.get("gleich"):
            m, n, dx = s["m"], s["n"], s["dx"]
            ax.axline((xA, yA), slope=m, color=col, lw=2.0, alpha=0.9, zorder=4.6)
            ax.fill([xA, xB, xB], [yA, yA, yB], color=col, alpha=0.15, lw=0, zorder=4.55)
            ax.plot([xA, xB, xB], [yA, yA, yB], color=col, lw=1.8, zorder=4.7)
            bb = ax.bbox
            rx = 9 * (self.xlim[1] - self.xlim[0]) / bb.width
            ry = 9 * (self.ylim[1] - self.ylim[0]) / bb.height
            if abs(xA - xB) > 2.5 * rx and abs(yB - yA) > 2.5 * ry:          # rechter Winkel
                ux, uy = np.sign(xA - xB), np.sign(yB - yA)
                ax.plot([xB + ux * rx, xB + ux * rx, xB], [yA, yA + uy * ry, yA + uy * ry], color=col, lw=1.1, zorder=4.7)
            # Δx und Δy jeweils außerhalb des Dreiecks
            unten = ((0, -12), "center", "top")
            oben = ((0, 12), "center", "bottom")
            reihen = [unten, oben] if yB > yA else [oben, unten]
            schild(f"Δx = {_dez(s['dx'], 2)}", [(((xA + xB) / 2, yA),) + r for r in reihen])
            rechts, links = ((10, 0), "left", "center"), ((-10, 0), "right", "center")
            seiten = [rechts, links] if xB > xA else [links, rechts]
            schild(f"Δy = {_dez(s['dy'], 2)}", [((xB, (yA + yB) / 2),) + r for r in seiten])
            g = lambda x: m * x + n
            gl = gerade_tex({"name": r"s_{AB}", "m": m, "n": n})
            schild(gl, [((xA + t * dx, g(xA + t * dx)), (0, oy), "center", "bottom" if oy > 0 else "top")
                        for t in (-0.45, 1.45, -0.9, 1.9, -0.2, 1.2, 0.5) for oy in (12, -12)], groesse=12)
        for P_, x, y in (("A", xA, yA), ("B", xB, yB)):
            ax.plot([x], [y], "o", ms=10, color=col, mec=FARBEN["kontur"], mew=1.2, zorder=9)
            gross = self._drag is not None and self._drag[0] == "sekpunkt" and self._drag[1] == P_
            ax.plot([x], [y], "o", ms=20 if gross else 17, mfc="none", mec=col, mew=1.6, alpha=0.75, zorder=9)
            links = (P_ == "A") == (xA <= xB)
            h = "right" if links else "left"
            ox = -12 if links else 12
            schild(f"{P_}({_dez(x, 2)}|{_dez(y, 2)})",
                   [((x, y), (ox, oy), h, "center") for oy in (14, -14)] +
                   [((x, y), (-ox, oy), "left" if links else "right", "center") for oy in (14, -14)] +
                   [((x, y), (0, oy), "center", "bottom" if oy > 0 else "top") for oy in (18, -18)])

    def _p_sichtbar_machen(self):
        """P bzw. Q in den sichtbaren Bereich holen, falls er außerhalb liegt oder die Funktion dort nicht definiert ist."""
        def ok(x):
            y = float(np.asarray(self._f(np.array([x])), dtype=float)[0])
            return np.isfinite(y) and self.xlim[0] < x < self.xlim[1] and self.ylim[0] < y < self.ylim[1]
        if ok(self.t_x):
            return
        b = self.xlim[1] - self.xlim[0]
        for q in (0.6, 0.4, 0.7, 0.3, 0.8, 0.2, 0.5, 0.9, 0.1):
            if ok(self.xlim[0] + q * b):
                self.t_x = self.xlim[0] + q * b
                return

    def _fang(self, x: float, pixel: float = 8.0) -> float:
        """Einrasten an Nullstellen, Extrem-/Wendestellen (geladene Funktion) und halben Gitterlinien."""
        erg = self._analyse(False)
        schritt = self.ax.xaxis.get_major_locator().tick_values(*self.xlim)
        schritt = (schritt[1] - schritt[0]) / 2 if len(schritt) > 1 else 0.5
        ziele = list(erg["nullstellen"]) + [p[0] for p in erg["extrema"]] + \
            [p[0] for p in erg["wendepunkte"]] + [round(x / schritt) * schritt]
        px_pro_einheit = self.ax.bbox.width / (self.xlim[1] - self.xlim[0])
        beste, ergebnis = pixel, x
        for z in ziele:
            d = abs(z - x) * px_pro_einheit
            if d < beste:
                beste, ergebnis = d, z
        return ergebnis

    def _fy(self, x: float) -> float:
        """Einzelner Funktionswert; nicht definierte Stellen liefern 0 (für Hilfslinien)."""
        try:
            with np.errstate(all="ignore"):
                y = float(np.asarray(self._f(np.array([float(x)])), dtype=float)[0])
        except Exception:
            return 0.0
        return y if np.isfinite(y) else 0.0

    def ansicht_anpassen(self):
        kd = []
        for k in ("f", "g"):
            with self._mit(k):
                kd += self._kurven_daten(False, self._analyse(False))      # alle eingeblendeten Kurven
        if not kd:
            with self._mit("f"):
                kd = [{"erg": self._analyse(False), "f": self._f}]
        xp, yp = [], [0.0]
        for d in kd:
            e = d["erg"]
            xp += list(e["nullstellen"]) + [p[0] for p in e["extrema"]] + [p[0] for p in e["wendepunkte"]]
            yp += [p[1] for p in e["extrema"]] + [p[1] for p in e["wendepunkte"]]
        xp += [self.a, self.b]
        lo, hi = (min(xp), max(xp)) if xp else (-3, 3)
        mitte, halb = (lo + hi) / 2, max((hi - lo) / 2 + 1.0, 3.0)
        self.xlim = [mitte - halb * 1.15, mitte + halb * 1.15]
        if len(yp) < 3:  # keine charakteristischen Punkte -> Kurvenverlauf nutzen
            for d in kd:
                with np.errstate(all="ignore"):
                    yv = np.asarray(d["f"](np.linspace(mitte - halb, mitte + halb, 400)), dtype=float)
                yv = yv[np.isfinite(yv)]
                if yv.size:
                    yp += [float(np.percentile(yv, 10)), float(np.percentile(yv, 90))]
        ylo, yhi = min(yp), max(yp)
        rand = max((yhi - ylo) * 0.15, 1.0)
        self.ylim = [ylo - rand, yhi + rand]
        self._stuetz_alle()
        self.aktualisiere()

    def _verbinde_maus(self):
        cv = self.fig.canvas
        cv.mpl_connect("button_press_event", self._druck)
        cv.mpl_connect("motion_notify_event", self._bewegung)
        cv.mpl_connect("button_release_event", self._loslassen)
        cv.mpl_connect("scroll_event", self._scroll)
        cv.mpl_connect("axes_leave_event", lambda _ev: self._summe_hover(None))
        cv.mpl_connect("figure_leave_event", lambda _ev: self._summe_hover(None))

    def _druck(self, ev):
        for k, tb in self.term_boxen.items():          # zuletzt benutztes Termfeld merken
            if ev.inaxes is tb.ax:
                self._letztes_termfeld = k
        if ev.inaxes is not self.ax or ev.xdata is None:
            return
        if self._sum_hover is not None:                 # Anteil-Anzeige ausblenden, solange gezogen wird
            self._summe_hover(None)
        tr = self.ax.transData
        if ev.button == 1 and self.zeige["trace"]:      # Trace-Punkt bzw. Senkrechte ziehen
            x = self._trace["x"]
            px, py = tr.transform((x, self._trace_achse_y()))
            treffer = np.hypot(px - ev.x, py - ev.y) < 14 or abs(px - ev.x) < 5
            for _d, y in self._trace_werte():
                if np.isfinite(y) and np.hypot(px - ev.x, tr.transform((x, y))[1] - ev.y) < 14:
                    treffer = True
            if treffer:
                self._drag = ("trace",)
                self.aktualisiere()
                return
        sk = self._sk
        if ev.button == 1 and sk is not None and not sk.get("fehlt"):
            for P_ in ("B", "A"):                       # Sekantenpunkte A und B
                x = self.sek["x" + P_]
                px, py = tr.transform((x, self._fy(x)))
                if np.hypot(px - ev.x, py - ev.y) < 14:
                    self._drag = ("sekpunkt", P_)
                    self.aktualisiere()
                    return
        if ev.button == 1:
            for k in ("f", "g"):                        # Punkt P (an f) bzw. Q (an g)
                with self._mit(k):
                    tp = self._tp
                if tp is not None:
                    px, py = tr.transform((tp["x0"], tp["y0"]))
                    if np.hypot(px - ev.x, py - ev.y) < 14:
                        self._drag = ("tpunkt", k)
                        return
        if ev.button == 1 and (self.zeige["integral"] or self._summe is not None):
            ym = self._grenz_marken_y()
            for name in ("b", "a"):
                g = getattr(self, name)
                px, py = tr.transform((g, ym))
                auf_marke = np.hypot(px - ev.x, py - ev.y) < 14
                y_lo, y_hi = sorted((tr.transform((g, 0))[1], tr.transform((g, self._fy(g)))[1]))
                auf_linie = abs(px - ev.x) < 7 and y_lo < ev.y < y_hi
                if auf_marke or auf_linie:
                    self._drag = ("grenze", name)
                    self.aktualisiere()
                    return
        if ev.button == 1:
            beste, bd = None, 12.0                      # Stützpunkte von f und g
            for k in ("f", "g"):
                with self._mit(k):
                    if self.zeige["stuetz"] and self._polynom_modus() and self._kv["f"]:
                        pix = tr.transform(np.column_stack([self.stuetz_x, self.stuetz_y]))
                        d = np.hypot(pix[:, 0] - ev.x, pix[:, 1] - ev.y)
                        if d.min() < bd:
                            bd, beste = float(d.min()), ("stuetz", int(d.argmin()), k)
            if beste:
                self._drag = beste
                return
            naechste, gd = None, 12.0                   # nächstgelegener Graph (f oder g)
            for k in ("f", "g"):
                with self._mit(k):
                    if not self._kv["f"]:
                        continue
                    with np.errstate(all="ignore"):
                        yk = float(np.asarray(self._f(np.array([ev.xdata])), dtype=float)[0])
                    if np.isfinite(yk):
                        d = abs(tr.transform((ev.xdata, yk))[1] - ev.y)
                        if d < gd:
                            gd, naechste = d, k
            if naechste:
                with self._mit(naechste):
                    self._drag = ("graph", ev.xdata, ev.ydata, self._graph_drag_start(), naechste)
                return
        self._drag = ("ansicht", ev.x, ev.y, list(self.xlim), list(self.ylim))

    def _bewegung(self, ev):
        if self._drag is None:
            self._summe_hover(ev)                      # Anteil des Rechtecks/Trapezes unter dem Mauszeiger
            return
        art = self._drag[0]
        if art == "ansicht":
            _, x0, y0, xl, yl = self._drag
            bb = self.ax.bbox
            dx = (ev.x - x0) * (xl[1] - xl[0]) / bb.width
            dy = (ev.y - y0) * (yl[1] - yl[0]) / bb.height
            self.xlim = [xl[0] - dx, xl[1] - dx]
            self.ylim = [yl[0] - dy, yl[1] - dy]
            self.aktualisiere()
            return
        if ev.inaxes is not self.ax or ev.xdata is None:
            return
        if art == "grenze":
            # Einrasten an Nullstellen, Extrem-/Wendestellen und Gitterlinien (8 Pixel Fangradius)
            setattr(self, self._drag[1], round(float(self._fang(ev.xdata)), 12) + 0.0)
        elif art == "trace":
            self._trace_setzen(round(float(ev.xdata), 12) + 0.0)
            self._tr_meldung = ""
        elif art == "sekpunkt":
            # A bzw. B gleitet entlang des Graphen der bearbeiteten Funktion (Einrasten wie bei P)
            x = round(float(self._fang(ev.xdata)), 12) + 0.0
            if not np.isfinite(self._wert(x)):
                return
            self.sek["x" + self._drag[1]] = x
            self._sek_meldung = ""
        elif art == "tpunkt":
            # P bzw. Q gleitet entlang des Graphen: nur die x-Position der Maus zählt
            with self._mit(self._drag[1]):
                x = round(float(self._fang(ev.xdata)), 12) + 0.0
                y = float(np.asarray(self._f(np.array([x])), dtype=float)[0])
                if not np.isfinite(y):
                    return
                self.t_x = x
            self._p_meldung = ""
        elif art == "stuetz":
            _, i, k = self._drag
            with self._mit(k):
                x = ev.xdata
                min_abst = 1e-3 * (self.xlim[1] - self.xlim[0])
                andere = np.delete(self.stuetz_x, i)
                if andere.size and np.min(np.abs(andere - x)) < min_abst:
                    return
                self.stuetz_x[i], self.stuetz_y[i] = x, ev.ydata
                self.c = P.polyfit(self.stuetz_x, self.stuetz_y, self.n)
                self._polynom_geaendert()
        elif art == "graph":
            _, x0, y0, start, k = self._drag
            with self._mit(k):
                self._graph_drag(start, ev.xdata - x0, ev.ydata - y0)
        self.aktualisiere()

    def _loslassen(self, _ev):
        war_grenze = self._drag is not None and self._drag[0] in ("grenze", "sekpunkt", "trace")
        self._drag = None
        if war_grenze:
            self.aktualisiere()

    def _scroll(self, ev):
        if ev.inaxes is not self.ax or ev.xdata is None:
            return
        f = 1 / 1.2 if ev.button == "up" else 1.2
        x, y = ev.xdata, ev.ydata
        self.xlim = [x + (g - x) * f for g in self.xlim]
        self.ylim = [y + (g - y) * f for g in self.ylim]
        self.aktualisiere()


def starte(koeffizienten=None, grad: int = 3, block: bool = True, **kwargs) -> PolynomExplorer:
    """Öffnet den Polynom-Explorer. Koeffizienten aufsteigend: a0, a1, …
    Weitere Schlüsselwörter wie bei PolynomExplorer, z. B. design="pearson"."""
    ex = PolynomExplorer(koeffizienten, grad=grad, **kwargs)
    plt.show(block=block)
    return ex


if __name__ == "__main__":
    args = sys.argv[1:]
    koeff = [_parse_zahl(a) for a in args] if args else None
    starte(koeff)
