"""
Herleitung – kommentierte Rechenwege zu den Knöpfen des Funktionen-Explorers (identisch zu Herleitung in
funktionen-explorer.html). Ausgabe: Dokument {"titel", "abschnitte": [{"titel", "inhalt": [Blöcke]}]} mit LaTeX.

Blöcke: {"t": "p", "s"}  Text mit \\( … \\) · {"t": "m", "s"} abgesetzte Formel · {"t": "ul", "s": […]}
        {"t": "tab", "kopf": […], "zeilen": [[…]]} · {"t": "box", "s"} Ergebnis · {"t": "hinweis", "s"}

Aufruf als Unterprogramm:
    import herleitung
    dok = herleitung.erzeuge({"art": "ext", "term": "x^3 - 4x", "c": [0, -4, 0, 1], "fn": "f",
                              "x0": -6.75, "x1": 6.75, "a": -1, "b": 1, "n": 8, "xP": 1, "xA": -1, "xB": 2})
    herleitung.als_html(dok)            # druckfertige Seite (KaTeX)
Arten: null, ext, wende, integral, schnitt, yachse, tH, tT, tW, tP, sek, ober, unter, trapez, mitte, kF, kf, kd1, kd2, kd3
"""
from __future__ import annotations

import json
import math

W: dict = {}                                      # Werkzeuge des Explorers (setze_werkzeuge)



def _endl(v) -> bool:
    return isinstance(v, (int, float)) and math.isfinite(v)


def _jsround(v: float) -> int:                     # wie Math.round in JavaScript
    return int(math.floor(v + 0.5))


def _jsstr(v) -> str:                              # Zahl wie String(v) in JavaScript (ganze Zahlen ohne ,0)
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


# ---------- Zahlen ----------
def _fest_k(betrag: float, st: int) -> str:            # wie toFixed in JavaScript: exakter Binärwert, ,5 aufrunden
    from decimal import Decimal, ROUND_HALF_UP
    t = format(Decimal(betrag).quantize(Decimal(1).scaleb(-st), rounding=ROUND_HALF_UP), "f")
    if "." in t:
        t = t.rstrip("0").rstrip(".")
    return t


def tex_dez(v: float, st: int = 3) -> str:
    """Dezimalzahl als LaTeX, kaufmännisch gerundet – identisch zu texDez in JavaScript."""
    if not _endl(v):
        return "\\text{n. d.}"
    if v != 0 and (abs(v) < 1e-4 or abs(v) >= 1e9):
        e = math.floor(math.log10(abs(v)))
        m = v / 10 ** e
        if float(_fest_k(abs(m), 2)) >= 10:
            m /= 10
            e += 1
        return tex_dez(m, 2) + "\\cdot 10^{" + str(e) + "}"
    if v != 0 and abs(v) < 10 ** (-st + 1):
        st = min(math.floor(-math.log10(abs(v))) + 2, 12)
    t = _fest_k(abs(v), st)
    return ("-" if v < 0 and t != "0" else "") + t.replace(".", "{,}")


def bruch_von(v):
    if not _endl(v):
        return None
    if v == 0:
        return (0, 1)
    if abs(v) >= 1e9:
        return None
    for q in range(1, 13):
        p = _jsround(v * q)
        if p != 0 and abs(p / q - v) < 1e-9 * abs(v):
            return (p, q)
    return None


def exakt(v) -> bool:
    return bruch_von(v) is not None


def zt(v) -> str:
    if not _endl(v):
        return "\\infty" if v > 0 else "-\\infty" if v < 0 else "\\text{n. d.}"
    b = bruch_von(v)
    if b:
        if b[1] == 1:
            return str(b[0])
        return ("-" if b[0] < 0 else "") + "\\frac{" + str(abs(b[0])) + "}{" + str(b[1]) + "}"
    return tex_dez(v, 3)


def zg(v) -> str:
    return ("= " if exakt(v) else "\\approx ") + zt(v)


def zk(v) -> str:
    return "\\left(" + zt(v) + "\\right)" if v < 0 else zt(v)


def glatt(v):
    b = bruch_von(v)
    if b:
        return b[0] / b[1] + 0.0
    return 0.0 if abs(v) < 1e-12 else v


def punkt(name, x, y) -> str:
    return name + "\\left(" + zt(x) + " \\mid " + zt(y) + "\\right)"


def idx(name, i) -> str:
    return name + "_{" + _jsstr(i) + "}"


# ---------- Polynome ----------
def trim(c):
    c = [glatt(float(v)) for v in c]
    while len(c) > 1 and c[-1] == 0:
        c.pop()
    return c


def grad(c) -> int:
    c = trim(c)
    return -1 if len(c) == 1 and c[0] == 0 else len(c) - 1


def pwert(c, x):
    y = 0.0
    for a in reversed(c):
        y = y * x + a
    return y + 0.0


def pabl(c):
    if len(c) <= 1:
        return [0.0]
    return trim([glatt(i * c[i]) for i in range(1, len(c))])


def pstamm(c):
    return trim([0.0] + [glatt(c[i] / (i + 1)) for i in range(len(c))])


def pot_tex(v, k) -> str:
    return "" if k == 0 else v if k == 1 else v + "^{" + str(k) + "}"


def _nur_ziffern(s: str) -> bool:
    return len(s) > 0 and all(ch in "0123456789{}," for ch in s)


def ptex(c, v: str = "x") -> str:
    c = trim(c)
    s = ""
    for k in range(len(c) - 1, -1, -1):
        a = c[k]
        if a == 0:
            continue
        betrag, pot = zt(abs(a)), pot_tex(v, k)
        teil = betrag if k == 0 else (pot if betrag == "1" else betrag + ("" if _nur_ziffern(betrag) else "\\,") + pot)
        if s == "":
            s = ("-" if a < 0 else "") + teil
        else:
            s += (" - " if a < 0 else " + ") + teil
    return "0" if s == "" else s


def einsetzen(c, xt: str) -> str:
    c = trim(c)
    teile = []
    einfach = _nur_ziffern(xt)
    for k in range(len(c) - 1, -1, -1):
        a = c[k]
        if a == 0:
            continue
        betrag = zt(abs(a))
        if k == 0:
            t = betrag
        else:
            if k == 1:
                p = "\\left(" + xt + "\\right)" if xt[:1] == "-" else xt
            else:
                p = (xt if einfach else "\\left(" + xt + "\\right)") + "^{" + str(k) + "}"
            t = p if betrag == "1" else betrag + " \\cdot " + p
        teile.append(("-" if a < 0 else "+", t))
    if not teile:
        return "0"
    s = ("-" if teile[0][0] == "-" else "") + teile[0][1]
    for op, t in teile[1:]:
        s += " " + op + " " + t
    return s


def ableitungs_zeile(c, name, strich) -> str:
    c = trim(c)
    teile = []
    for k in range(len(c) - 1, 0, -1):
        a = c[k]
        if a == 0:
            continue
        teile.append(str(k) + " \\cdot " + zk(a) + ("" if k - 1 == 0 else " \\cdot " + pot_tex("x", k - 1)))
    return name + strich + "(x) = " + (" + ".join(teile) if teile else "0")


def stamm_zeile(c, name) -> str:
    c = trim(c)
    teile = []
    for k in range(len(c) - 1, -1, -1):
        a = c[k]
        if a == 0:
            continue
        teile.append("\\frac{" + zt(a) + "}{" + str(k + 1) + "} \\cdot " + pot_tex("x", k + 1))
    return name + "(x) = " + (" + ".join(teile) if teile else "0")


# ---------- Gleichungen p(x) = 0 lösen ----------
def wurzel_tex(r):
    s = math.sqrt(r)
    if exakt(s):
        return {"tex": zt(s), "exakt": True}
    return {"tex": "\\sqrt{" + zt(r) + "}", "exakt": False}


def _ggt(a, b):
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def rationale_nullstelle(c):
    br = [bruch_von(v) for v in c]
    if any(b is None for b in br):
        return None
    L = 1
    for b in br:
        L = L // _ggt(L, b[1]) * b[1]
    z = [b[0] * (L // b[1]) for b in br]
    if any(abs(x) > 1e6 for x in z):
        return None
    a0, an = abs(z[0]), abs(z[-1])

    def teiler(n):
        return [i for i in range(1, min(n, 1000) + 1) if n % i == 0]

    kand = []
    for p in teiler(a0):
        for q in teiler(an):
            if _ggt(p, q) != 1:
                continue
            kand.append(p / q)
            kand.append(-p / q)
    import functools

    def vergleich(u, w):
        d = abs(u) - abs(w)
        if d != 0:
            return -1 if d < 0 else 1
        return -1 if w - u < 0 else (1 if w - u > 0 else 0)
    kand.sort(key=functools.cmp_to_key(vergleich))
    for r in kand:
        b = bruch_von(r)
        if not b:
            continue
        p, q, n = b[0], b[1], len(z) - 1
        s, gross = 0, False
        for k in range(n + 1):
            t = z[k] * p ** k * q ** (n - k)
            if abs(t) > 9e15:
                gross = True
            s += t
        if not gross and s == 0:
            return r
    return None


def horner(c, r):
    n = len(c) - 1
    q = [0.0] * n
    s = c[n]
    for k in range(n - 1, -1, -1):
        q[k] = glatt(s)
        s = c[k] + s * r
    return trim(q)


def loese(c0, links="", v="x"):
    bl, lsg = [], []
    pn = links.split("(")[0] if links else "p"

    def nr():
        return len(lsg) + 1

    def dazu(x, tex):
        lsg.append({"x": glatt(x), "tex": tex})

    def quadratisch(c):
        a = c[2]
        p, q = glatt(c[1] / a), glatt(c[0] / a)
        if p != 0:
            bl.append({"t": "p", "s": "Quadratische Gleichung" + (": zuerst durch \\(" + zk(a) + "\\) teilen (Normalform), dann die \\(pq\\)-Formel anwenden." if a != 1 else " in Normalform: \\(pq\\)-Formel anwenden.")})
        else:
            bl.append({"t": "p", "s": "Quadratische Gleichung ohne linearen Summanden" + (": durch \\(" + zk(a) + "\\) teilen, nach \\(" + v + "^{2}\\) auflösen und die Wurzel ziehen." if a != 1 else ": nach \\(" + v + "^{2}\\) auflösen und die Wurzel ziehen.")})
        if a != 1:
            bl.append({"t": "m", "s": ptex(c, v) + " = 0 \\quad\\mid :" + zk(a) + " \\quad\\Longrightarrow\\quad " + ptex([q, p, 1], v) + " = 0"})
        if p == 0:
            r = glatt(-q)
            bl.append({"t": "m", "s": v + "^{2} = " + zt(r)})
            if r < 0:
                bl.append({"t": "p", "s": "Ein Quadrat ist nie negativ – keine Lösung."})
                return
            if r == 0:
                bl.append({"t": "m", "s": v + " = 0"})
                dazu(0, "0")
                dazu(0, "0")
                return
            w = wurzel_tex(r)
            bl.append({"t": "m", "s": idx(v, nr()) + " = -" + w["tex"] + ("" if w["exakt"] else " \\approx " + zt(-math.sqrt(r))) + ", \\qquad " + idx(v, nr() + 1) + " = " + w["tex"] + ("" if w["exakt"] else " \\approx " + zt(math.sqrt(r)))})
            dazu(-math.sqrt(r), "-" + w["tex"])
            dazu(math.sqrt(r), w["tex"])
            return
        D, m = glatt((p / 2) * (p / 2) - q), glatt(-p / 2)
        bl.append({"t": "m", "s": "p = " + zt(p) + ", \\quad q = " + zt(q)})
        bl.append({"t": "m", "s": idx(v, (str(nr()) + "," + str(nr() + 1)) if lsg else "1,2") + " = -\\frac{p}{2} \\pm \\sqrt{\\left(\\frac{p}{2}\\right)^{2} - q} = " + zt(m) + " \\pm \\sqrt{" + zk(glatt(p / 2)) + "^{2} - " + zk(q) + "} = " + zt(m) + " \\pm \\sqrt{" + zt(D) + "}"})
        if D < 0:
            bl.append({"t": "p", "s": "Die Diskriminante \\(D = " + zt(D) + "\\) ist negativ – keine reelle Lösung."})
            return
        if D == 0:
            bl.append({"t": "p", "s": "Die Diskriminante ist \\(D = 0\\): genau eine (doppelte) Lösung."})
            bl.append({"t": "m", "s": v + " = " + zt(m)})
            dazu(m, zt(m))
            dazu(m, zt(m))
            return
        w = wurzel_tex(D)
        x1, x2 = glatt(m - math.sqrt(D)), glatt(m + math.sqrt(D))
        t1 = zt(x1) if w["exakt"] else ("" if m == 0 else zt(m)) + " - " + w["tex"]
        t2 = zt(x2) if w["exakt"] else ("" if m == 0 else zt(m) + " + ") + w["tex"]
        bl.append({"t": "p", "s": "Die Diskriminante \\(D = " + zt(D) + "\\) ist positiv: zwei Lösungen."})
        if w["exakt"]:
            bl.append({"t": "m", "s": idx(v, (str(nr()) + "," + str(nr() + 1)) if lsg else "1,2") + " = " + zt(m) + " \\pm " + w["tex"]})
        bl.append({"t": "m", "s": idx(v, nr()) + " = " + t1 + ("" if w["exakt"] else " \\approx " + zt(x1)) + ", \\qquad " + idx(v, nr() + 1) + " = " + t2 + ("" if w["exakt"] else " \\approx " + zt(x2))})
        dazu(x1, t1)
        dazu(x2, t2)

    def biquadratisch(c):
        z = "z"
        bl.append({"t": "p", "s": "Nur gerade Potenzen: Substitution \\(z = " + v + "^{2}\\) führt auf eine quadratische Gleichung in \\(z\\)."})
        bl.append({"t": "m", "s": ptex([c[0], c[2], c[4]], z) + " = 0"})
        innen = loese([c[0], c[2], c[4]], "", z)
        bl.extend(innen["bl"])
        zs = []
        for s in innen["lsg"]:
            if not any(abs(w - s["x"]) < 1e-12 for w in zs):
                zs.append(s["x"])
        bl.append({"t": "p", "s": "Rücksubstitution \\(" + v + "^{2} = z\\):"})
        for zz in zs:
            if zz < 0:
                bl.append({"t": "p", "s": "\\(" + v + "^{2} = " + zt(zz) + "\\): keine Lösung (Quadrat nie negativ)."})
            elif zz == 0:
                bl.append({"t": "p", "s": "\\(" + v + "^{2} = 0\\): \\(" + v + " = 0\\) (doppelt)."})
                dazu(0, "0")
                dazu(0, "0")
            else:
                w = wurzel_tex(zz)
                bl.append({"t": "p", "s": "\\(" + v + "^{2} = " + zt(zz) + "\\): \\(" + v + " = \\pm " + w["tex"] + ("" if w["exakt"] else " \\approx \\pm " + zt(math.sqrt(zz))) + "\\)"})
                dazu(-math.sqrt(zz), "-" + w["tex"])
                dazu(math.sqrt(zz), w["tex"])

    def numerisch(c):
        xs = W["null_poly"](c)
        bl.append({"t": "p", "s": "Für Grad " + str(grad(c)) + " gibt es kein einfaches Lösungsverfahren (keine rationale Lösung, keine Substitution). Die Lösungen werden numerisch bestimmt: Zwischen zwei Stellen mit verschiedenem Vorzeichen liegt eine Nullstelle; das Intervall wird so lange halbiert, bis die Lösung genau genug ist (Intervallhalbierung)."})
        if not xs:
            bl.append({"t": "p", "s": "Das Polynom hat keinen Vorzeichenwechsel und keine Nullstelle – keine reelle Lösung."})
        for x in xs:
            dazu(x, zt(x))

    def teil(c, tiefe):
        c = trim(c)
        n = grad(c)
        if n < 0:
            bl.append({"t": "p", "s": "Die Gleichung ist für jedes \\(" + v + "\\) erfüllt (Nullpolynom)."})
            return
        if n == 0:
            bl.append({"t": "p", "s": "Die Gleichung \\(" + zt(c[0]) + " = 0\\) ist nie erfüllt – keine Lösung aus diesem Teil."})
            return
        if c[0] == 0 and n == 1:
            bl.append({"t": "m", "s": ptex(c, v) + " = 0 \\quad\\mid :" + zk(c[1]) + " \\quad\\Longrightarrow\\quad " + v + " = 0"})
            dazu(0, "0")
            return
        if c[0] == 0:
            k = 0
            while c[k] == 0:
                k += 1
            rest = trim(c[k:])
            if grad(rest) == 0:
                bl.append({"t": "p", "s": "\\(" + ptex(c, v) + " = 0\\) gilt nur für \\(" + pot_tex(v, k) + " = 0\\), also \\(" + v + " = 0\\) (" + str(k) + "-fache Lösung)."})
                for _ in range(k):
                    dazu(0, "0")
                return
            bl.append({"t": "p", "s": "Kein Summand ohne \\(" + v + "\\): \\(" + pot_tex(v, k) + "\\) ausklammern und den Satz vom Nullprodukt anwenden (ein Produkt ist genau dann null, wenn ein Faktor null ist)."})
            bl.append({"t": "m", "s": pot_tex(v, k) + " \\cdot \\left(" + ptex(rest, v) + "\\right) = 0 \\quad\\Longleftrightarrow\\quad " + pot_tex(v, k) + " = 0 \\;\\;\\text{oder}\\;\\; " + ptex(rest, v) + " = 0"})
            bl.append({"t": "p", "s": "Aus \\(" + pot_tex(v, k) + " = 0\\) folgt \\(" + v + " = 0\\) (" + str(k) + "-fache Lösung)." if k > 1 else "Erste Lösung: \\(" + v + " = 0\\)."})
            for _ in range(k):
                dazu(0, "0")
            if grad(rest) >= 1:
                teil(rest, tiefe + 1)
            return
        if n == 1:
            x = glatt(-c[0] / c[1])
            bl.append({"t": "p", "s": "Lineare Gleichung: nach \\(" + v + "\\) auflösen."})
            bl.append({"t": "m", "s": "\\begin{aligned} " + ptex(c, v) + " &= 0 && \\mid " + ("-" if c[0] > 0 else "+") + zt(abs(c[0])) + " \\\\ " +
                       ptex([0, c[1]], v) + " &= " + zt(-c[0]) + (" && \\mid :" + zk(c[1]) if c[1] != 1 else "") + " \\\\ " + v + " &" + zg(x) + " \\end{aligned}"})
            dazu(x, zt(x))
            return
        if n == 2:
            quadratisch(c)
            return
        if n == 4 and c[1] == 0 and c[3] == 0:
            biquadratisch(c)
            return
        r = rationale_nullstelle(c)
        if r is not None:
            q = horner(c, r)
            bl.append({"t": "p", "s": "Grad " + str(n) + ": Eine Lösung durch Probieren finden. Bei ganzzahligen Koeffizienten kommen als rationale Lösungen nur \\(\\pm\\frac{p}{q}\\) in Frage, \\(p\\) Teiler des Absolutglieds, \\(q\\) Teiler des Leitkoeffizienten. Probe:"})
            bl.append({"t": "m", "s": ("q" if tiefe else pn) + "\\left(" + zt(r) + "\\right) = " + einsetzen(c, zt(r)) + " = 0"})
            bl.append({"t": "p", "s": "Also ist \\(" + v + " = " + zt(r) + "\\) eine Lösung. Polynomdivision durch \\(\\left(" + v + (" - " if r > 0 else " + ") + zt(abs(r)) + "\\right)\\) (Horner-Schema):"})
            bl.append({"t": "m", "s": "\\left(" + ptex(c, v) + "\\right) : \\left(" + v + (" - " if r > 0 else " + ") + zt(abs(r)) + "\\right) = " + ptex(q, v)})
            dazu(r, zt(r))
            teil(q, tiefe + 1)
            return
        numerisch(c)

    if links:
        bl.append({"t": "m", "s": links + " = 0"})
    teil(trim(c0), 0)
    lsg.sort(key=lambda s: s["x"])
    zus = []
    for s in lsg:
        if zus and abs(zus[-1]["x"] - s["x"]) <= 1e-9 * (1 + abs(s["x"])):
            zus[-1]["vf"] += 1
        else:
            zus.append({"x": s["x"], "tex": s["tex"], "vf": 1})
    return {"bl": bl, "lsg": zus}


# ---------- Funktion vorbereiten ----------
_STRICH = ["", "'", "''", "'''"]


class _Lage:
    pass


def lage(sz: dict) -> _Lage:
    A = W["ausdruck"](sz["term"])
    L = _Lage()
    L.sz, L.fn = sz, sz.get("fn") or "f"
    L.F = L.fn.upper()
    L.A = A
    L.c = trim(sz["c"]) if sz.get("c") else None
    L.poly = L.c is not None
    L.x0, L.x1, L.a, L.b = sz.get("x0"), sz.get("x1"), sz.get("a"), sz.get("b")
    c = L.c
    L.f = (lambda x: pwert(c, x)) if c else A["f"]
    L.abl = []
    ak, ck = A, c
    for _k in range(1, 4):
        if c:
            ck = pabl(ck)
            L.abl.append({"tex": ptex(ck), "f": (lambda cc: (lambda x: pwert(cc, x)))(ck), "c": ck})
        else:
            ak = ak["abl"]()
            L.abl.append({"tex": ak["tex"](), "f": ak["f"], "c": None})
    L.tex = ptex(c) if c else A["tex"]()
    L.d = lambda k, x: L.f(x) if k == 0 else L.abl[k - 1]["f"](x)
    L.erg = W["analyse_poly"](c, L.a, L.b) if c else W["analyse_allg"](A["f"], L.x0, L.x1, L.a, L.b)
    return L


def fx(L, k, arg) -> str:
    return L.fn + _STRICH[k] + "\\left(" + arg + "\\right)"


def definition(L):
    return {"t": "m", "s": L.fn + "(x) = " + L.tex}


def ableitungen_bloecke(L, bis):
    bl = []
    if L.poly:
        bl.append({"t": "p", "s": "Ableiten mit Potenzregel \\(\\left(x^{n}\\right)' = n\\,x^{n-1}\\), Faktorregel und Summenregel – jeder Summand einzeln, ein konstanter Summand fällt weg:"})
        c = L.c
        for k in range(1, bis + 1):
            z = ableitungs_zeile(c, L.fn, _STRICH[k - 1] + "'")
            c = pabl(c)
            bl.append({"t": "m", "s": z + " = " + ptex(c)})
    else:
        bl.append({"t": "p", "s": "Ableiten mit den Ableitungsregeln (Summen-, Faktor-, Produkt-, Quotienten- und Kettenregel sowie den Ableitungen der Grundfunktionen):"})
        for k in range(1, bis + 1):
            bl.append({"t": "m", "s": L.fn + _STRICH[k] + "(x) = " + L.abl[k - 1]["tex"]})
    return bl


_KNICK = {"abs": "Beträge", "fabs": "Beträge", "floor": "Abrundungen", "ceil": "Aufrundungen", "sign": "Vorzeichenfunktionen"}


def voraussetzung_diffbar(L, ordnung):
    if L.poly:
        return [{"t": "p", "s": "\\(" + L.fn + "\\) ist eine ganzrationale Funktion (Polynom vom Grad " + str(grad(L.c)) + "). Polynome sind auf ganz \\(\\mathbb{R}\\) definiert, stetig und beliebig oft differenzierbar. ✓ Die Voraussetzungen sind erfüllt."}]
    fk = W["funktionen"](L.A)
    knick = [n for n in fk if n in _KNICK]
    out = []
    luecke = W["luecken"](L.f, L.x0, L.x1)
    out.append({"t": "p", "s": "\\(" + L.fn + "\\) ist keine ganzrationale Funktion. Untersucht wird der sichtbare Bereich \\(" + zt(L.x0) + " \\le x \\le " + zt(L.x1) + "\\)."})
    out.append({"t": "p", "s": ("⚠ Im sichtbaren Bereich gibt es Stellen, an denen \\(" + L.fn + "\\) nicht definiert ist (Definitionslücken). Dort gelten die Kriterien nicht; untersucht werden nur die Teilbereiche, in denen \\(" + L.fn + "\\) definiert ist.")
                if luecke else "✓ \\(" + L.fn + "\\) ist im sichtbaren Bereich überall definiert."})
    if knick:
        namen = []
        for n in knick:
            if _KNICK[n] not in namen:
                namen.append(_KNICK[n])
        out.append({"t": "p", "s": "⚠ Der Term enthält " + ", ".join(namen) + ". An Knick- oder Sprungstellen ist \\(" + L.fn + "\\) nicht differenzierbar; dort versagen die Ableitungskriterien."})
    elif ordnung > 0:
        out.append({"t": "p", "s": "✓ Der Term besteht aus differenzierbaren Grundfunktionen; wo \\(" + L.fn + "\\) definiert ist, ist \\(" + L.fn + "\\) " + ("differenzierbar" if ordnung == 1 else ("zweimal" if ordnung == 2 else "dreimal" if ordnung == 3 else str(ordnung) + "-mal") + " differenzierbar") + "."})
    return out


def stelle_wert(L, k, x):
    y = glatt(L.d(k, x))
    if L.poly:
        c = L.c if k == 0 else L.abl[k - 1]["c"]
        e = einsetzen(c, zt(x))
        return {"s": fx(L, k, zt(x)) + (" = " + e if e == zt(y) else " = " + e + " " + zg(y)), "y": y}
    return {"s": fx(L, k, zt(x)) + " " + zg(y), "y": y}


def _vgl(v):
    return "> 0" if v > 0 else "< 0" if v < 0 else "= 0"


def vzw_schritt(L, k, x, nachbarn):
    d = [abs(u - x) for u in nachbarn if abs(u - x) > 1e-9]
    h = min(0.5, min(d) / 2 if d else 0.5)
    h = glatt(max(h, 1e-3))
    if h > 0.1:
        h = _jsround(h * 10) / 10
    xl, xr = glatt(x - h), glatt(x + h)
    yl, yr = L.d(k, xl), L.d(k, xr)
    return {"xl": xl, "xr": xr, "yl": yl, "yr": yr,
            "s": fx(L, k, zt(xl)) + " " + zg(glatt(yl)) + " " + _vgl(yl) + ", \\qquad " + fx(L, k, zt(xr)) + " " + zg(glatt(yr)) + " " + _vgl(yr)}


def abschnitt(titel, inhalt):
    return {"titel": titel, "inhalt": inhalt}


def kopf_abschnitt(L, worum):
    return abschnitt("Worum geht es?", [definition(L)] + worum)


def _kand_liste(kand):
    return ", ".join("\\(" + idx("x", i + 1) + " " + ("= " + s["tex"] if s["tex"] == zt(s["x"]) else "= " + s["tex"] + " \\approx " + zt(s["x"])) + "\\)" for i, s in enumerate(kand)) + "."


def _keine(L):
    return "" if L.poly else "im sichtbaren Bereich "


# ---------- Erklärungen ----------
def nullstellen_rechnung(L):
    if L.poly:
        r = loese(L.c, L.fn + "(x) = " + L.tex)
        return {"bl": r["bl"], "lsg": r["lsg"]}
    bl = [{"t": "m", "s": L.fn + "(x) = " + L.tex + " = 0"},
          {"t": "p", "s": "Diese Gleichung lässt sich im Allgemeinen nicht algebraisch nach \\(x\\) auflösen. Numerisch: Der sichtbare Bereich wird in 2000 Schritte eingeteilt; wo \\(" + L.fn + "\\) das Vorzeichen wechselt, wird das Teilintervall so lange halbiert, bis die Nullstelle genau genug ist (Intervallhalbierung, Zwischenwertsatz)."}]
    return {"bl": bl, "lsg": [{"x": x, "tex": zt(x), "vf": 1} for x in L.erg["nullstellen"]]}


def erkl_nullstellen(L):
    r = nullstellen_rechnung(L)
    pkt = []
    for i, s in enumerate(r["lsg"]):
        z = "\\(" + punkt(idx("N", i + 1), s["x"], 0) + "\\)"
        if s["vf"] > 1:
            z += " – " + str(s["vf"]) + "-fache Nullstelle" + (" (Berührpunkt, kein Vorzeichenwechsel)" if s["vf"] % 2 == 0 else " (mit Vorzeichenwechsel)")
        pkt.append(z)
    n = len(r["lsg"])
    return {
        "titel": "Nullstellen von \\(" + L.fn + "\\)",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Nullstellen sind die Stellen \\(x\\), an denen der Funktionswert null ist. Dort schneidet oder berührt der Graph die \\(x\\)-Achse."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss an der Stelle definiert sein. Für das numerische Verfahren (Vorzeichenwechsel) muss \\(" + L.fn + "\\) außerdem stetig sein (Zwischenwertsatz)."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", voraussetzung_diffbar(L, 0)),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": L.fn + "(x_{N}) = 0"}, {"t": "p", "s": "Ansatz: Funktionsterm gleich null setzen und die Gleichung nach \\(x\\) auflösen – je nach Gestalt durch Umformen, Ausklammern (Satz vom Nullprodukt), \\(pq\\)-Formel, Substitution, Probieren mit Polynomdivision oder numerisch."}]),
            abschnitt("Schrittweise Berechnung", r["bl"]),
            abschnitt("Ergebnis", [{"t": "box", "s": (("Eine Nullstelle: " if n == 1 else str(n) + " Nullstellen: ") + ", ".join(pkt)) if n else "\\(" + L.fn + "\\) hat " + _keine(L) + "keine Nullstelle."}])
        ]
    }


def extrem_rechnung(L, nur):
    bl = ableitungen_bloecke(L, 2)
    bl.append({"t": "p", "s": "<b>1. Notwendige Bedingung</b> \\(" + L.fn + "'(x_{E}) = 0\\):"})
    if L.poly:
        r = loese(L.abl[0]["c"], L.fn + "'(x) = " + L.abl[0]["tex"])
        bl.extend(r["bl"])
        kand = r["lsg"]
    else:
        bl.append({"t": "m", "s": L.fn + "'(x) = " + L.abl[0]["tex"] + " = 0"})
        bl.append({"t": "p", "s": "Die Gleichung wird numerisch gelöst (Vorzeichenwechsel von \\(" + L.fn + "'\\) im sichtbaren Bereich, Intervallhalbierung)."})
        kand = sorted([{"x": p["x"], "tex": zt(p["x"]), "vf": 1} for p in L.erg["extrema"] + L.erg["sattelpunkte"]], key=lambda s: s["x"])
    if not kand:
        bl.append({"t": "p", "s": "\\(" + L.fn + "'\\) hat keine Nullstelle – es gibt keine Kandidaten für Extremstellen."})
    else:
        bl.append({"t": "p", "s": "Kandidaten: " + _kand_liste(kand)})
    punkte = []
    for i, s in enumerate(kand):
        xi, x = idx("x", i + 1), s["x"]
        bl.append({"t": "p", "s": "<b>2. Hinreichende Bedingung für \\(" + xi + "\\)</b>"})
        w2 = stelle_wert(L, 2, x)
        bl.append({"t": "p", "s": "a) Mit der zweiten Ableitung:"})
        bl.append({"t": "m", "s": w2["s"]})
        typ = None
        y2 = 0 if abs(w2["y"]) < 1e-9 * (1 + abs(L.d(1, x + 1) - L.d(1, x - 1))) else w2["y"]
        if y2 < 0:
            typ = "H"
            bl.append({"t": "p", "s": "\\(" + fx(L, 2, xi) + " < 0\\) und \\(" + fx(L, 1, xi) + " = 0\\) ⇒ an \\(" + xi + "\\) liegt ein <b>Hochpunkt</b> (Graph rechtsgekrümmt)."})
        elif y2 > 0:
            typ = "T"
            bl.append({"t": "p", "s": "\\(" + fx(L, 2, xi) + " > 0\\) und \\(" + fx(L, 1, xi) + " = 0\\) ⇒ an \\(" + xi + "\\) liegt ein <b>Tiefpunkt</b> (Graph linksgekrümmt)."})
        else:
            bl.append({"t": "p", "s": "\\(" + fx(L, 2, xi) + " = 0\\): Mit der zweiten Ableitung ist keine Entscheidung möglich – das Vorzeichenwechsel-Kriterium entscheidet."})
        vzw = vzw_schritt(L, 1, x, [q["x"] for q in kand])
        bl.append({"t": "p", "s": "b) Mit dem Vorzeichenwechsel von \\(" + L.fn + "'\\) (Test links und rechts von \\(" + xi + "\\), zwischen den Nachbarkandidaten):"})
        bl.append({"t": "m", "s": vzw["s"]})
        if vzw["yl"] > 0 and vzw["yr"] < 0:
            typ_v = "H"
            bl.append({"t": "p", "s": "Vorzeichenwechsel von \\(+\\) nach \\(-\\): \\(" + L.fn + "\\) steigt erst und fällt dann ⇒ <b>Hochpunkt</b>."})
        elif vzw["yl"] < 0 and vzw["yr"] > 0:
            typ_v = "T"
            bl.append({"t": "p", "s": "Vorzeichenwechsel von \\(-\\) nach \\(+\\): \\(" + L.fn + "\\) fällt erst und steigt dann ⇒ <b>Tiefpunkt</b>."})
        else:
            typ_v = "S"
            bl.append({"t": "p", "s": "Kein Vorzeichenwechsel: kein Extremum, sondern ein <b>Sattelpunkt</b> (Terrassenpunkt)."})
        if typ is None:
            typ = typ_v
        y = glatt(L.f(x))
        w0 = stelle_wert(L, 0, x)
        bl.append({"t": "p", "s": "Funktionswert (\\(y\\)-Koordinate):"})
        bl.append({"t": "m", "s": w0["s"]})
        punkte.append({"x": x, "y": y, "typ": typ, "tex": s["tex"]})
    return {"bl": bl, "punkte": punkte}


def punkte_liste(punkte, nur):
    z, out = {"H": 0, "T": 0, "S": 0}, []
    for p in punkte:
        z[p["typ"]] += 1
        if nur != "alle" and p["typ"] != nur:
            continue
        out.append("\\(" + punkt(idx(p["typ"], z[p["typ"]]), p["x"], p["y"]) + "\\) " + ("Hochpunkt" if p["typ"] == "H" else "Tiefpunkt" if p["typ"] == "T" else "Sattelpunkt"))
    return out


def kriterien_extrema():
    return [
        {"t": "p", "s": "<b>Notwendige Bedingung:</b> An einer Extremstelle \\(x_{E}\\) hat der Graph eine waagerechte Tangente:"},
        {"t": "m", "s": "f'(x_{E}) = 0"},
        {"t": "p", "s": "<b>Hinreichende Bedingung (zweite Ableitung):</b>"},
        {"t": "m", "s": "f'(x_{E}) = 0 \\;\\wedge\\; f''(x_{E}) < 0 \\;\\Rightarrow\\; \\text{Hochpunkt}, \\qquad f'(x_{E}) = 0 \\;\\wedge\\; f''(x_{E}) > 0 \\;\\Rightarrow\\; \\text{Tiefpunkt}"},
        {"t": "p", "s": "Ist \\(f''(x_{E}) = 0\\), liefert dieses Kriterium keine Aussage."},
        {"t": "p", "s": "<b>Hinreichende Bedingung (Vorzeichenwechsel):</b> \\(f'\\) wechselt an \\(x_{E}\\) das Vorzeichen – von \\(+\\) nach \\(-\\): Hochpunkt, von \\(-\\) nach \\(+\\): Tiefpunkt. Ohne Vorzeichenwechsel liegt ein Sattelpunkt vor. Dieses Kriterium entscheidet immer."},
        {"t": "p", "s": "<b>Vorgehen:</b> 1. \\(f'\\) und \\(f''\\) bestimmen. 2. \\(f'(x) = 0\\) lösen (Kandidaten). 3. Jeden Kandidaten mit \\(f''\\) und mit dem Vorzeichenwechsel prüfen. 4. \\(y\\)-Koordinate durch Einsetzen in \\(f\\) berechnen."}
    ]


def erkl_extrema(L, nur, mit_tangente):
    r = extrem_rechnung(L, nur)
    name = "Hochpunkte" if nur == "H" else "Tiefpunkte" if nur == "T" else "Extrempunkte (Hoch- und Tiefpunkte)"
    liste = punkte_liste(r["punkte"], nur)
    worum = [{"t": "p", "s": "Ein Hochpunkt ist ein Punkt des Graphen, der höher liegt als alle Punkte in seiner Umgebung (lokales Maximum)." if nur == "H"
              else "Ein Tiefpunkt ist ein Punkt des Graphen, der tiefer liegt als alle Punkte in seiner Umgebung (lokales Minimum)." if nur == "T"
              else "Gesucht sind die Punkte, an denen der Graph lokal am höchsten (Hochpunkt) oder am tiefsten (Tiefpunkt) liegt. Dort geht er vom Steigen ins Fallen über bzw. umgekehrt."}]
    if mit_tangente:
        worum.append({"t": "p", "s": "Zusätzlich wird in jedem dieser Punkte die Tangente bestimmt. Weil die Steigung dort null ist, ist sie waagerecht."})
    ab = [
        kopf_abschnitt(L, worum),
        abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss in einer Umgebung der Stelle definiert und differenzierbar sein; für das Kriterium mit der zweiten Ableitung zweimal differenzierbar."}]),
        abschnitt("Sind die Voraussetzungen erfüllt?", voraussetzung_diffbar(L, 2)),
        abschnitt("Kriterien und Vorgehen", kriterien_extrema()),
        abschnitt("Schrittweise Berechnung", r["bl"])
    ]
    erg = [{"t": "box", "s": (name + ": " + ", ".join(liste)) if liste else "\\(" + L.fn + "\\) hat " + _keine(L) + "keine " + ("Hochpunkte" if nur == "H" else "Tiefpunkte" if nur == "T" else "Extrempunkte") + "."}]
    sattel = [p for p in r["punkte"] if p["typ"] == "S"]
    if nur == "alle" and sattel:
        erg.append({"t": "p", "s": "Außerdem " + ("ein Sattelpunkt" if len(sattel) == 1 else str(len(sattel)) + " Sattelpunkte") + " (waagerechte Tangente ohne Extremum): " + ", ".join(punkte_liste(r["punkte"], "S")) + "."})
    if mit_tangente:
        z = {"H": 0, "T": 0, "S": 0}
        for p in r["punkte"]:
            z[p["typ"]] += 1
            if p["typ"] != nur:
                continue
            erg.append({"t": "p", "s": "Tangente in \\(" + idx(p["typ"], z[p["typ"]]) + "\\): Steigung \\(m = " + L.fn + "'\\left(" + zt(p["x"]) + "\\right) = 0\\), also"})
            erg.append({"t": "m", "s": "t(x) = " + L.fn + "'\\left(x_{0}\\right)\\cdot\\left(x - x_{0}\\right) + " + L.fn + "\\left(x_{0}\\right) = 0 \\cdot \\left(x - " + zk(p["x"]) + "\\right) + " + zk(p["y"]) + " \\quad\\Longrightarrow\\quad t(x) = " + zt(p["y"])})
    ab.append(abschnitt("Ergebnis", erg))
    return {"titel": name + (" und ihre Tangenten" if mit_tangente else "") + " von \\(" + L.fn + "\\)", "abschnitte": ab}


def wende_rechnung(L):
    bl = ableitungen_bloecke(L, 3)
    bl.append({"t": "p", "s": "<b>1. Notwendige Bedingung</b> \\(" + L.fn + "''(x_{W}) = 0\\):"})
    if L.poly:
        r = loese(L.abl[1]["c"], L.fn + "''(x) = " + L.abl[1]["tex"])
        bl.extend(r["bl"])
        kand = r["lsg"]
    else:
        bl.append({"t": "m", "s": L.fn + "''(x) = " + L.abl[1]["tex"] + " = 0"})
        bl.append({"t": "p", "s": "Die Gleichung wird numerisch gelöst (Vorzeichenwechsel von \\(" + L.fn + "''\\) im sichtbaren Bereich, Intervallhalbierung)."})
        kand = [{"x": p["x"], "tex": zt(p["x"]), "vf": 1} for p in L.erg["wendepunkte"]]
    if not kand:
        bl.append({"t": "p", "s": "\\(" + L.fn + "''\\) hat keine Nullstelle – keine Kandidaten für Wendestellen."})
    else:
        bl.append({"t": "p", "s": "Kandidaten: " + _kand_liste(kand)})
    punkte = []
    for i, s in enumerate(kand):
        xi, x = idx("x", i + 1), s["x"]
        bl.append({"t": "p", "s": "<b>2. Hinreichende Bedingung für \\(" + xi + "\\)</b>"})
        w3 = stelle_wert(L, 3, x)
        bl.append({"t": "p", "s": "a) Mit der dritten Ableitung:"})
        bl.append({"t": "m", "s": w3["s"]})
        ist = None
        if abs(w3["y"]) > 1e-9:
            ist = True
            bl.append({"t": "p", "s": "\\(" + fx(L, 3, xi) + " \\neq 0\\) ⇒ an \\(" + xi + "\\) liegt eine <b>Wendestelle</b>" + (" (Übergang von rechts- zu linksgekrümmt)." if w3["y"] > 0 else " (Übergang von links- zu rechtsgekrümmt).")})
        else:
            bl.append({"t": "p", "s": "\\(" + fx(L, 3, xi) + " = 0\\): keine Entscheidung – das Vorzeichenwechsel-Kriterium entscheidet."})
        vzw = vzw_schritt(L, 2, x, [q["x"] for q in kand])
        bl.append({"t": "p", "s": "b) Mit dem Vorzeichenwechsel von \\(" + L.fn + "''\\):"})
        bl.append({"t": "m", "s": vzw["s"]})
        wechsel = vzw["yl"] * vzw["yr"] < 0
        bl.append({"t": "p", "s": "\\(" + L.fn + "''\\) wechselt das Vorzeichen ⇒ <b>Wendestelle</b> (die Krümmung ändert sich)." if wechsel else "\\(" + L.fn + "''\\) wechselt das Vorzeichen nicht ⇒ <b>keine</b> Wendestelle."})
        if ist is None:
            ist = wechsel
        if not ist:
            continue
        y = glatt(L.f(x))
        bl.append({"t": "p", "s": "Funktionswert:"})
        bl.append({"t": "m", "s": stelle_wert(L, 0, x)["s"]})
        m = glatt(L.d(1, x))
        sattel = abs(m) < 1e-9
        bl.append({"t": "p", "s": "Steigung im Wendepunkt: \\(" + stelle_wert(L, 1, x)["s"] + "\\)" + (" ⇒ waagerechte Wendetangente: <b>Sattelpunkt</b>." if sattel else ".")})
        punkte.append({"x": x, "y": y, "m": m, "sattel": sattel, "tex": s["tex"]})
    return {"bl": bl, "punkte": punkte}


def kriterien_wende():
    return [
        {"t": "p", "s": "An einer Wendestelle ändert der Graph sein Krümmungsverhalten (Links- ↔ Rechtskurve); die Steigung \\(f'\\) ist dort lokal extremal."},
        {"t": "p", "s": "<b>Notwendige Bedingung:</b>"}, {"t": "m", "s": "f''(x_{W}) = 0"},
        {"t": "p", "s": "<b>Hinreichende Bedingung (dritte Ableitung):</b>"}, {"t": "m", "s": "f''(x_{W}) = 0 \\;\\wedge\\; f'''(x_{W}) \\neq 0 \\;\\Rightarrow\\; \\text{Wendestelle}"},
        {"t": "p", "s": "<b>Hinreichende Bedingung (Vorzeichenwechsel):</b> \\(f''\\) wechselt an \\(x_{W}\\) das Vorzeichen."},
        {"t": "p", "s": "<b>Sattelpunkt:</b> Wendepunkt mit waagerechter Tangente, also zusätzlich \\(f'(x_{W}) = 0\\)."},
        {"t": "p", "s": "<b>Vorgehen:</b> 1. \\(f', f'', f'''\\) bestimmen. 2. \\(f''(x) = 0\\) lösen. 3. Kandidaten mit \\(f'''\\) bzw. dem Vorzeichenwechsel von \\(f''\\) prüfen. 4. \\(y\\)-Koordinate und Steigung berechnen."}
    ]


def erkl_wende(L, mit_tangente):
    r = wende_rechnung(L)
    pkt = ["\\(" + punkt(idx("S" if p["sattel"] else "W", i + 1), p["x"], p["y"]) + "\\)" + (" (Sattelpunkt)" if p["sattel"] else "") for i, p in enumerate(r["punkte"])]
    n = len(r["punkte"])
    erg = [{"t": "box", "s": (("Ein Wendepunkt: " if n == 1 else str(n) + " Wendepunkte: ") + ", ".join(pkt)) if n else "\\(" + L.fn + "\\) hat " + _keine(L) + "keine Wendepunkte."}]
    if mit_tangente:
        for i, p in enumerate(r["punkte"]):
            nn = glatt(p["y"] - p["m"] * p["x"])
            erg.append({"t": "p", "s": "Wendetangente in \\(" + idx("S" if p["sattel"] else "W", i + 1) + "\\): Punkt-Steigungs-Form \\(t(x) = m\\,(x - x_{0}) + y_{0}\\) mit \\(m = " + zt(p["m"]) + "\\):"})
            erg.append({"t": "m", "s": "t(x) = " + zt(p["m"]) + " \\cdot \\left(x - " + zk(p["x"]) + "\\right) + " + zk(p["y"]) + " \\quad\\Longrightarrow\\quad t(x) = " + ptex([nn, p["m"]])})
    worum = [{"t": "p", "s": "Gesucht sind die Punkte, in denen der Graph von einer Linkskurve in eine Rechtskurve übergeht oder umgekehrt."}]
    if mit_tangente:
        worum.append({"t": "p", "s": "Zusätzlich wird in jedem Wendepunkt die Tangente (Wendetangente) bestimmt."})
    return {
        "titel": "Wendepunkte" + (" und Wendetangenten" if mit_tangente else "") + " von \\(" + L.fn + "\\)",
        "abschnitte": [
            kopf_abschnitt(L, worum),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss in einer Umgebung der Stelle zweimal differenzierbar sein, für das Kriterium mit der dritten Ableitung dreimal."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", voraussetzung_diffbar(L, 3)),
            abschnitt("Kriterien und Vorgehen", kriterien_wende()),
            abschnitt("Schrittweise Berechnung", r["bl"]),
            abschnitt("Ergebnis", erg)
        ]
    }


def _ausr(v, st=4):
    return "\\text{nicht berechenbar}" if v is None else tex_dez(v, st)


def erkl_integral(L):
    a, b, bl = L.a, L.b, []
    ok = _endl(a) and _endl(b)
    I, A = L.erg["integral"], L.erg["flaeche"]
    if L.poly and ok:
        F = pstamm(L.c)
        bl.append({"t": "p", "s": "<b>1. Stammfunktion</b> mit der Potenzregel rückwärts \\(\\int x^{n}\\,\\mathrm{d}x = \\frac{x^{n+1}}{n+1}\\) – jeder Summand einzeln:"})
        bl.append({"t": "m", "s": stamm_zeile(L.c, L.F) + " = " + ptex(F)})
        bl.append({"t": "p", "s": "<b>2. Hauptsatz:</b> Stammfunktion an den Grenzen auswerten."})
        Fb, Fa = glatt(pwert(F, b)), glatt(pwert(F, a))
        bl.append({"t": "m", "s": "\\begin{aligned} " + L.F + "\\left(" + zt(b) + "\\right) &= " + einsetzen(F, zt(b)) + " " + zg(Fb).replace("= ", "&= ", 1).replace("\\approx", "&\\approx", 1) + " \\\\ " +
                   L.F + "\\left(" + zt(a) + "\\right) &= " + einsetzen(F, zt(a)) + " " + zg(Fa).replace("= ", "&= ", 1).replace("\\approx", "&\\approx", 1) + " \\end{aligned}"})
        I = glatt(Fb - Fa)
        bl.append({"t": "m", "s": "\\int_{" + zt(a) + "}^{" + zt(b) + "} " + L.fn + "(x)\\,\\mathrm{d}x = \\Big[" + L.F + "(x)\\Big]_{" + zt(a) + "}^{" + zt(b) + "} = " + zk(Fb) + " - " + zk(Fa) + " " + zg(I)})
        lo, hi = min(a, b), max(a, b)
        N = [x for x in W["null_poly"](L.c) if lo + 1e-12 < x < hi - 1e-12]
        bl.append({"t": "p", "s": "<b>3. Flächeninhalt</b> zwischen Graph und \\(x\\)-Achse: Liegen Nullstellen im Intervall, wird an ihnen geteilt, weil Flächen unterhalb der Achse negativ zählen; die Beträge der Teilintegrale werden addiert."})
        if not N:
            A = abs(I)
            bl.append({"t": "p", "s": "Zwischen \\(" + zt(lo) + "\\) und \\(" + zt(hi) + "\\) liegt keine Nullstelle, also \\(A = \\left|" + zt(I) + "\\right| " + zg(A) + "\\)."})
        else:
            g = [lo] + N + [hi]
            teile, zeilen, A = [], [], 0.0
            for i in range(len(g) - 1):
                w = glatt(pwert(F, g[i + 1]) - pwert(F, g[i]))
                A += abs(w)
                teile.append("\\left|" + zt(w) + "\\right|")
                zeilen.append(["\\(\\left[" + zt(g[i]) + ";\\ " + zt(g[i + 1]) + "\\right]\\)", "\\(" + zt(w) + "\\)", "oberhalb" if w >= 0 else "unterhalb"])
            A = glatt(A)
            bl.append({"t": "p", "s": "Nullstellen im Intervall: " + "; ".join("\\(" + zt(x) + "\\)" for x in N) + "."})
            bl.append({"t": "tab", "kopf": ["Teilintervall", "Teilintegral", "Lage zur \\(x\\)-Achse"], "zeilen": zeilen})
            bl.append({"t": "m", "s": "A = " + " + ".join(teile) + " " + zg(A)})
    elif ok:
        bl.append({"t": "p", "s": "Für \\(" + L.fn + "\\) gibt es hier keine elementar angebbare Stammfunktion; das Integral wird numerisch berechnet (adaptives Simpson-Verfahren: das Intervall wird so lange in kleinere Stücke geteilt, bis die Näherung auf etwa 10 Stellen genau ist)."})
        bl.append({"t": "m", "s": "\\int_{" + zt(a) + "}^{" + zt(b) + "} " + L.fn + "(x)\\,\\mathrm{d}x \\approx " + _ausr(I)})
        bl.append({"t": "p", "s": "Für den Flächeninhalt wird an den Nullstellen im Intervall geteilt und die Beträge der Teilintegrale addiert."})
        bl.append({"t": "m", "s": "A \\approx " + _ausr(A)})
    if I is None:
        box = "Das Integral ist nicht berechenbar."
    else:
        box = "\\(\\displaystyle\\int_{" + zt(a) + "}^{" + zt(b) + "} " + L.fn + "(x)\\,\\mathrm{d}x " + (zg(I) if L.poly else "\\approx " + tex_dez(I, 4)) + "\\), Flächeninhalt \\(A " + (zg(A) if L.poly else "\\approx " + tex_dez(A, 4)) + "\\)"
    return {
        "titel": "Integral von \\(" + L.fn + "\\) über \\(\\left[" + zt(min(a, b)) + ";\\ " + zt(max(a, b)) + "\\right]\\)",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Das bestimmte Integral \\(\\int_{a}^{b} " + L.fn + "(x)\\,\\mathrm{d}x\\) bilanziert die Flächen zwischen Graph und \\(x\\)-Achse: oberhalb positiv, unterhalb negativ. Der Flächeninhalt \\(A\\) zählt alle Teilflächen positiv. Hier: \\(a = " + zt(a) + "\\), \\(b = " + zt(b) + "\\)."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss auf dem ganzen Intervall \\([a;\\ b]\\) definiert und stetig sein. Dann existiert eine Stammfunktion \\(" + L.F + "\\) mit \\(" + L.F + "' = " + L.fn + "\\) (Hauptsatz der Differential- und Integralrechnung)."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", [{"t": "p", "s": "✓ Polynome sind überall stetig; eine Stammfunktion ist wieder ein Polynom."}] if L.poly else
                      [{"t": "p", "s": ("⚠ \\(" + L.fn + "\\) ist im Intervall nicht überall definiert – das Integral existiert so nicht.") if I is None else "✓ \\(" + L.fn + "\\) ist auf dem Intervall definiert; der Wert wird numerisch bestimmt."}]),
            abschnitt("Kriterien und Vorgehen", [{"t": "m", "s": "\\int_{a}^{b} f(x)\\,\\mathrm{d}x = F(b) - F(a) \\quad\\text{mit } F' = f"}, {"t": "p", "s": "Vorgehen: 1. Stammfunktion bilden. 2. Obere minus untere Grenze einsetzen. 3. Für den Flächeninhalt an den Nullstellen im Intervall teilen und Beträge addieren."}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", [{"t": "box", "s": box}])
        ]
    }


def erkl_y_achse(L):
    y = glatt(L.f(0.0))
    bl = [{"t": "p", "s": "Auf der \\(y\\)-Achse ist \\(x = 0\\). Also \\(x = 0\\) in den Funktionsterm einsetzen" + (" – alle Summanden mit \\(x\\) werden null, übrig bleibt das Absolutglied:" if L.poly else ":")},
          {"t": "m", "s": stelle_wert(L, 0, 0.0)["s"] if _endl(y) else L.fn + "(0) \\text{ ist nicht definiert}"}]
    return {
        "titel": "Schnittpunkt von \\(" + L.fn + "\\) mit der \\(y\\)-Achse",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Gesucht ist der Punkt, in dem der Graph die \\(y\\)-Achse schneidet (\\(y\\)-Achsenabschnitt)."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(x = 0\\) muss zum Definitionsbereich von \\(" + L.fn + "\\) gehören."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", [{"t": "p", "s": ("✓ \\(" + L.fn + "(0)\\) ist definiert.") if _endl(y) else "⚠ \\(" + L.fn + "\\) ist an der Stelle \\(0\\) nicht definiert – es gibt keinen Schnittpunkt mit der \\(y\\)-Achse."}]),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": "S_{y}\\left(0 \\mid f(0)\\right)"}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", [{"t": "box", "s": ("\\(" + punkt("S_{y}", 0, y) + "\\)") if _endl(y) else "Kein Schnittpunkt mit der \\(y\\)-Achse."}])
        ]
    }


def erkl_schnitt(L):
    o = L.sz.get("andere")
    if not o:
        return {"titel": "Schnittpunkte zweier Graphen", "abschnitte": [abschnitt("Worum geht es?", [{"t": "p", "s": "Schnittpunkte zweier Graphen sind die Punkte, die auf beiden liegen. Für die Rechnung wird eine zweite Funktion \\(g\\) gebraucht – bitte im Feld \\(g(x)\\) eintragen und einblenden."}])]}
    B = lage({"term": o["term"], "c": o.get("c"), "fn": o["fn"], "x0": L.sz["x0"], "x1": L.sz["x1"], "a": L.sz["a"], "b": L.sz["b"]})
    bl = [{"t": "m", "s": L.fn + "(x) = " + B.fn + "(x) \\quad\\Longleftrightarrow\\quad " + L.tex + " = " + B.tex}]
    if L.poly and B.poly:
        n = max(len(L.c), len(B.c))
        d = [glatt((L.c[i] if i < len(L.c) else 0) - (B.c[i] if i < len(B.c) else 0)) for i in range(n)]
        bl.append({"t": "p", "s": "Alles auf eine Seite bringen: Die Differenzfunktion \\(d(x) = " + L.fn + "(x) - " + B.fn + "(x)\\) muss null werden."})
        if all(v == 0 for v in trim(d)):
            bl.append({"t": "p", "s": "\\(d(x) = 0\\) für alle \\(x\\): Die Graphen sind gleich."})
        r = loese(d, "d(x) = " + ptex(d))
        bl.extend(r["bl"])
        xs = [s["x"] for s in r["lsg"]]
    else:
        bl.append({"t": "p", "s": "Die Gleichung \\(" + L.fn + "(x) - " + B.fn + "(x) = 0\\) wird numerisch im sichtbaren Bereich gelöst (Vorzeichenwechsel der Differenz, Intervallhalbierung)."})
        xs = [x for x in W["null_num"](lambda x: L.f(x) - B.f(x), L.sz["x0"], L.sz["x1"])
              if abs(L.f(x) - B.f(x)) <= 1e-6 * (1 + abs(L.f(x)) + abs(B.f(x)))]
    pk = []
    if xs:
        bl.append({"t": "p", "s": "\\(y\\)-Koordinaten durch Einsetzen in \\(" + L.fn + "\\) (zur Kontrolle auch in \\(" + B.fn + "\\)):"})
    for i, x in enumerate(xs):
        y, yb = glatt(L.f(x)), glatt(B.f(x))
        bl.append({"t": "m", "s": stelle_wert(L, 0, x)["s"] + ", \\qquad " + B.fn + "\\left(" + zt(x) + "\\right) " + zg(yb)})
        pk.append("\\(" + punkt(idx("S", i + 1), x, y) + "\\)")
    return {
        "titel": "Schnittpunkte von \\(" + L.fn + "\\) und \\(" + B.fn + "\\)",
        "abschnitte": [
            abschnitt("Worum geht es?", [definition(L), {"t": "m", "s": B.fn + "(x) = " + B.tex}, {"t": "p", "s": "Gesucht sind die Punkte, die auf beiden Graphen liegen: gleiche Stelle \\(x\\), gleicher Funktionswert."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "Beide Funktionen müssen an der Stelle definiert sein; für das numerische Verfahren stetig."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", [{"t": "p", "s": "✓ Beide sind Polynome: überall definiert und stetig."}] if L.poly and B.poly else
                      [{"t": "p", "s": "Untersucht wird der sichtbare Bereich \\(" + zt(L.sz["x0"]) + " \\le x \\le " + zt(L.sz["x1"]) + "\\); Stellen, an denen eine der Funktionen nicht definiert ist, werden übergangen."}]),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": "f(x_{S}) = g(x_{S}) \\quad\\Longleftrightarrow\\quad f(x_{S}) - g(x_{S}) = 0"}, {"t": "p", "s": "Vorgehen: Funktionsterme gleichsetzen, auf eine Seite bringen, die Gleichung lösen, \\(y\\)-Koordinaten durch Einsetzen bestimmen."}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", [{"t": "box", "s": (("Ein Schnittpunkt: " if len(pk) == 1 else str(len(pk)) + " Schnittpunkte: ") + ", ".join(pk)) if pk else "Die Graphen schneiden sich " + ("" if L.poly and B.poly else "im sichtbaren Bereich ") + "nicht."}])
        ]
    }


def erkl_tangente_p(L):
    x0 = L.sz["xP"]
    y0 = glatt(L.f(x0))
    bl = []
    t = None if L.poly else W["tangente_allg"](L.f, x0, L.x1 - L.x0)
    bl.append({"t": "p", "s": "<b>1. Berührpunkt:</b>"})
    bl.append({"t": "m", "s": stelle_wert(L, 0, x0)["s"]})
    bl.append({"t": "p", "s": "<b>2. Steigung</b> = Ableitung an der Stelle \\(x_{0}\\):"})
    bl.extend(ableitungen_bloecke(L, 1))
    if L.poly:
        w = stelle_wert(L, 1, x0)
        m = w["y"]
        bl.append({"t": "m", "s": "m = " + w["s"]})
    elif t.get("existiert") is False or t.get("senkrecht"):
        m = math.nan
    else:
        m = glatt(t["m"])
        bl.append({"t": "m", "s": "m = " + L.fn + "'\\left(" + zt(x0) + "\\right) " + zg(m)})
    erg = []
    senkrecht = bool(t and t.get("senkrecht"))
    if not _endl(m):
        bl.append({"t": "p", "s": ("Die Steigung ist unendlich groß – die Tangente ist senkrecht: \\(x = " + zt(x0) + "\\).") if senkrecht else "⚠ An dieser Stelle hat der Graph einen Knick; es gibt keine Tangente."})
        erg.append({"t": "box", "s": ("Senkrechte Tangente \\(x = " + zt(x0) + "\\)") if senkrecht else "Keine Tangente (Knickstelle)."})
    else:
        n = glatt(y0 - m * x0)
        bl.append({"t": "p", "s": "<b>3. Tangentengleichung</b> mit der Punkt-Steigungs-Form:"})
        bl.append({"t": "m", "s": "t(x) = m\\,(x - x_{0}) + y_{0} = " + zt(m) + " \\cdot \\left(x - " + zk(x0) + "\\right) + " + zk(y0)})
        bl.append({"t": "p", "s": "Ausmultiplizieren: \\(n = y_{0} - m\\,x_{0} = " + zk(y0) + " - " + zk(m) + " \\cdot " + zk(x0) + " " + zg(n) + "\\)"})
        bl.append({"t": "m", "s": "t(x) = " + ptex([n, m])})
        erg.append({"t": "box", "s": "Tangente in \\(" + punkt("P", x0, y0) + "\\): \\(t(x) = " + ptex([n, m]) + "\\)"})
    if L.poly:
        erfuellt = voraussetzung_diffbar(L, 1)
    else:
        erfuellt = [{"t": "p", "s": ("⚠ \\(" + L.fn + "\\) ist an der Stelle nicht differenzierbar (Knick).") if t.get("existiert") is False else
                     "⚠ Die Ableitung ist an der Stelle unendlich (senkrechte Tangente)." if t.get("senkrecht") else
                     "✓ \\(" + L.fn + "\\) ist an der Stelle \\(x_{0} = " + zt(x0) + "\\) differenzierbar."}]
    return {
        "titel": "Tangente an \\(" + L.fn + "\\) im Punkt \\(P\\)",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Die Tangente ist die Gerade, die den Graphen im Punkt \\(P\\left(x_{0} \\mid " + L.fn + "(x_{0})\\right)\\) berührt und dort dieselbe Steigung hat. Hier: \\(x_{0} = " + zt(x0) + "\\)."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss an der Stelle \\(x_{0}\\) differenzierbar sein."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", erfuellt),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": "t(x) = f'(x_{0})\\cdot(x - x_{0}) + f(x_{0})"}, {"t": "p", "s": "Vorgehen: 1. \\(y_{0} = f(x_{0})\\). 2. \\(m = f'(x_{0})\\). 3. In die Punkt-Steigungs-Form einsetzen und vereinfachen."}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", erg)
        ]
    }


def erkl_sekante(L):
    xA, xB = L.sz["xA"], L.sz["xB"]
    yA, yB = glatt(L.f(xA)), glatt(L.f(xB))
    bl = [{"t": "p", "s": "<b>1. Punkte auf dem Graphen:</b>"},
          {"t": "m", "s": stelle_wert(L, 0, xA)["s"] + ", \\qquad " + stelle_wert(L, 0, xB)["s"]}]
    dx, dy = glatt(xB - xA), glatt(yB - yA)
    erg = []
    bl.append({"t": "p", "s": "<b>2. Steigungsdreieck:</b>"})
    bl.append({"t": "m", "s": "\\Delta x = x_{B} - x_{A} = " + zt(xB) + " - " + zk(xA) + " " + zg(dx) + ", \\qquad \\Delta y = y_{B} - y_{A} = " + zk(yB) + " - " + zk(yA) + " " + zg(dy)})
    if dx == 0:
        erg.append({"t": "box", "s": "\\(A\\) und \\(B\\) fallen zusammen – keine Sekante."})
    else:
        m = glatt(dy / dx)
        n = glatt(yA - m * xA)
        bl.append({"t": "p", "s": "<b>3. Steigung</b> = Differenzenquotient (mittlere Änderungsrate):"})
        bl.append({"t": "m", "s": "m = \\frac{\\Delta y}{\\Delta x} = \\frac{" + zt(dy) + "}{" + zt(dx) + "} " + zg(m)})
        bl.append({"t": "p", "s": "<b>4. Geradengleichung</b> durch \\(A\\):"})
        bl.append({"t": "m", "s": "s(x) = m\\,(x - x_{A}) + y_{A} = " + zt(m) + " \\cdot \\left(x - " + zk(xA) + "\\right) + " + zk(yA) + " \\quad\\Longrightarrow\\quad s(x) = " + ptex([n, m])})
        erg.append({"t": "box", "s": "Sekante durch \\(" + punkt("A", xA, yA) + "\\) und \\(" + punkt("B", xB, yB) + "\\): \\(s(x) = " + ptex([n, m]) + "\\), mittlere Änderungsrate \\(m " + zg(m) + "\\)"})
    ok = _endl(yA) and _endl(yB)
    return {
        "titel": "Sekante an \\(" + L.fn + "\\) durch \\(A\\) und \\(B\\)",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Die Sekante ist die Gerade durch zwei Punkte \\(A\\) und \\(B\\) des Graphen. Ihre Steigung ist die mittlere Änderungsrate von \\(" + L.fn + "\\) zwischen \\(x_{A}\\) und \\(x_{B}\\); rückt \\(B\\) immer näher an \\(A\\), wird sie zur Tangente."}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss an beiden Stellen definiert sein, und es muss \\(x_{A} \\neq x_{B}\\) gelten."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", [{"t": "p", "s": (("✓ Beide Funktionswerte existieren, und \\(x_{A} \\neq x_{B}\\).") if dx != 0 else "⚠ \\(x_{A} = x_{B}\\).") if ok else "⚠ \\(" + L.fn + "\\) ist an einer der Stellen nicht definiert."}]),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": "m = \\frac{f(x_{B}) - f(x_{A})}{x_{B} - x_{A}}, \\qquad s(x) = m\\,(x - x_{A}) + f(x_{A})"}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", erg)
        ]
    }


_SUMME_NAME = {"ober": "Obersumme", "unter": "Untersumme", "trapez": "Trapezsumme", "mitte": "Mittensumme"}
_SUMME_Z = {"ober": "O", "unter": "U", "trapez": "T", "mitte": "M"}


def erkl_summe(L, art):
    a, b, n = L.a, L.b, int(L.sz["n"])
    krit = W["null_poly"](pabl(L.c)) if L.poly else None
    s = W["summe"](L.f, a, b, n, art, krit)
    bl, z = [], _SUMME_Z[art] + "_{" + str(n) + "}"
    lo, hi = min(a, b), max(a, b)
    dx = glatt((hi - lo) / n)
    bl.append({"t": "p", "s": "<b>1. Breite der Teilintervalle:</b>"})
    bl.append({"t": "m", "s": "\\Delta x = \\frac{b - a}{n} = \\frac{" + zt(hi) + " - " + zk(lo) + "}{" + str(n) + "} " + zg(dx)})
    bl.append({"t": "p", "s": "Teilungspunkte \\(x_{i} = a + i\\cdot\\Delta x\\) für \\(i = 0, 1, \\dots, " + str(n) + "\\)."})
    hoehe = {"ober": "der größte Funktionswert im Teilintervall (an einem Rand oder an einem Hochpunkt im Inneren).",
             "unter": "der kleinste Funktionswert im Teilintervall (an einem Rand oder an einem Tiefpunkt im Inneren).",
             "trapez": "Mittelwert der beiden Randwerte \\(\\frac{f(x_{i-1}) + f(x_{i})}{2}\\) (Trapez).",
             "mitte": "Funktionswert in der Intervallmitte \\(f\\left(\\frac{x_{i-1} + x_{i}}{2}\\right)\\)."}[art]
    bl.append({"t": "p", "s": "<b>2. Höhe je Teilintervall:</b> " + hoehe})
    if s.get("fehlt"):
        bl.append({"t": "p", "s": "⚠ \\(" + L.fn + "\\) ist im Teilintervall \\(\\left[" + zt(s["fehlt"][0]) + ";\\ " + zt(s["fehlt"][1]) + "\\right]\\) nicht überall definiert – die Summe ist nicht berechenbar."})
    else:
        teile = s["teile"]
        zeig = teile if n <= 12 else teile[:5] + [None] + teile[-3:]
        alle_exakt = all(exakt(t["x0"]) and exakt(t["x1"]) for t in teile)

        def zs(v):
            return zt(v) if alle_exakt else tex_dez(v, 3)
        zeilen = []
        for t in zeig:
            if t is None:
                zeilen.append(["…", "…", "…", "…"])
                continue
            if art == "trapez":
                stelle = "\\(" + zs(t["x0"]) + "\\); \\(" + zs(t["x1"]) + "\\)"
            else:
                stelle = "\\(" + (zt(t["xi"]) if exakt(t["xi"]) and alle_exakt else tex_dez(t["xi"], 3)) + "\\)"
            zeilen.append(["\\(\\left[" + zs(t["x0"]) + ";\\ " + zs(t["x1"]) + "\\right]\\)", stelle, "\\(" + zt(glatt(t["h"])) + "\\)", "\\(" + zt(glatt(t["wert"])) + "\\)"])
        bl.append({"t": "tab", "kopf": ["Teilintervall", "Ränder" if art == "trapez" else "Stelle der Höhe", "Höhe \\(h_{i}\\)", "Fläche \\(h_{i}\\cdot\\Delta x\\)"], "zeilen": zeilen})
        bl.append({"t": "p", "s": "<b>3. Summe</b> aller Rechteck- bzw. Trapezflächen" + (" (wegen \\(b < a\\) mit umgekehrtem Vorzeichen, wie beim Integral)" if b < a else "") + ":"})
        bl.append({"t": "m", "s": z + " = \\sum_{i=1}^{" + str(n) + "} h_{i}\\cdot\\Delta x " + zg(glatt(s["wert"]))})
        if L.erg.get("integral") is not None:
            I = L.erg["integral"]
            d = glatt(s["wert"] - I)
            bl.append({"t": "p", "s": "<b>4. Vergleich mit dem Integral:</b> \\(\\int_{" + zt(a) + "}^{" + zt(b) + "} " + L.fn + "(x)\\,\\mathrm{d}x " + (zg(glatt(I)) if L.poly else "\\approx " + tex_dez(I, 4)) + "\\), Abweichung \\(" + z + " - I \\approx " + tex_dez(d, 4) + "\\). Mit wachsendem \\(n\\) wird die Abweichung kleiner."})
    wort = {"ober": "Bei der Obersumme ist jedes Rechteck so hoch wie der größte Funktionswert im Teilintervall – sie liegt nie unter dem Integral.",
            "unter": "Bei der Untersumme ist jedes Rechteck so hoch wie der kleinste Funktionswert im Teilintervall – sie liegt nie über dem Integral.",
            "trapez": "Die Trapeze verbinden die Funktionswerte an den Rändern der Teilintervalle geradlinig.",
            "mitte": "Jedes Rechteck ist so hoch wie der Funktionswert in der Mitte des Teilintervalls."}[art]
    return {
        "titel": _SUMME_NAME[art] + " von \\(" + L.fn + "\\) mit \\(n = " + str(n) + "\\)",
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": "Die Fläche zwischen Graph und \\(x\\)-Achse über \\([a;\\ b] = \\left[" + zt(a) + ";\\ " + zt(b) + "\\right]\\) wird durch \\(n = " + str(n) + "\\) " + ("Trapeze" if art == "trapez" else "Rechtecke") + " gleicher Breite angenähert. " + wort}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": "\\(" + L.fn + "\\) muss auf \\([a;\\ b]\\) definiert und beschränkt sein; damit Ober- und Untersumme für \\(n \\to \\infty\\) gegen das Integral streben, stetig."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", [{"t": "p", "s": ("⚠ \\(" + L.fn + "\\) ist im Intervall nicht überall definiert.") if s.get("fehlt") else "✓ Polynome sind überall stetig." if L.poly else "✓ \\(" + L.fn + "\\) ist auf dem Intervall definiert."}]),
            abschnitt("Kriterium und Vorgehen", [{"t": "m", "s": z + " = \\sum_{i=1}^{n} h_{i}\\cdot\\Delta x, \\qquad \\Delta x = \\frac{b - a}{n}, \\qquad \\lim_{n \\to \\infty} " + _SUMME_Z[art] + "_{n} = \\int_{a}^{b} f(x)\\,\\mathrm{d}x"}]),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", [{"t": "box", "s": "Nicht berechenbar." if s.get("fehlt") else "\\(" + z + " " + zg(glatt(s["wert"])) + "\\)"}])
        ]
    }


def erkl_kurve(L, k):
    if k == 0:
        return erkl_funktion(L)
    bl = []
    if k < 0:
        if L.poly:
            F = pstamm(L.c)
            bl.append({"t": "p", "s": "Potenzregel rückwärts \\(\\int x^{n}\\,\\mathrm{d}x = \\frac{x^{n+1}}{n+1} + C\\), Summand für Summand:"})
            bl.append({"t": "m", "s": stamm_zeile(L.c, L.F) + " + C = " + ptex(F) + " + C"})
            bl.append({"t": "p", "s": "Der Explorer zeichnet die Stammfunktion mit \\(C = 0\\), also \\(" + L.F + "(0) = 0\\)."})
            bl.append({"t": "p", "s": "Probe durch Ableiten:"})
            bl.append({"t": "m", "s": L.F + "'(x) = " + ptex(pabl(F)) + " = " + L.fn + "(x) \\;✓"})
        else:
            bl.append({"t": "p", "s": "Für diese Funktion gibt es hier keine elementar angebbare Stammfunktion. Der Explorer berechnet sie numerisch als Integralfunktion:"})
            bl.append({"t": "m", "s": L.F + "(x) = \\int_{x_{a}}^{x} " + L.fn + "(t)\\,\\mathrm{d}t"})
            bl.append({"t": "p", "s": "Jeder Wert ist ein bestimmtes Integral (adaptives Simpson-Verfahren). Es gilt \\(" + L.F + "' = " + L.fn + "\\)."})
    else:
        bl.extend(ableitungen_bloecke(L, k))
    name = "Stammfunktion " + L.F if k < 0 else str(k) + ". Ableitung " + L.fn + _STRICH[k]
    titel = name.replace(L.F, "\\(" + L.F + "\\)", 1) if k < 0 else name.replace(L.fn + _STRICH[k], "\\(" + L.fn + _STRICH[k] + "\\)", 1)
    if k < 0:
        worum = "Eine Stammfunktion \\(" + L.F + "\\) ist eine Funktion, deren Ableitung \\(" + L.fn + "\\) ist: \\(" + L.F + "' = " + L.fn + "\\). Sie ist bis auf eine Konstante \\(C\\) eindeutig."
    else:
        worum = "Die " + str(k) + ". Ableitung \\(" + L.fn + _STRICH[k] + "\\) beschreibt " + (
            "die Steigung des Graphen von \\(" + L.fn + "\\) an jeder Stelle." if k == 1 else
            "die Änderung der Steigung, also die Krümmung: \\(" + L.fn + "'' > 0\\) Linkskurve, \\(" + L.fn + "'' < 0\\) Rechtskurve." if k == 2 else
            "die Änderung der Krümmung; sie wird beim Nachweis von Wendestellen gebraucht.")
    if k < 0:
        ergebnis = L.F + "(x) = " + (ptex(pstamm(L.c)) if L.poly else "\\int_{x_{a}}^{x} " + L.fn + "(t)\\,\\mathrm{d}t")
    else:
        ergebnis = L.fn + _STRICH[k] + "(x) = " + L.abl[k - 1]["tex"]
    return {
        "titel": titel,
        "abschnitte": [
            kopf_abschnitt(L, [{"t": "p", "s": worum}]),
            abschnitt("Voraussetzungen", [{"t": "p", "s": ("\\(" + L.fn + "\\) muss stetig sein.") if k < 0 else "\\(" + L.fn + "\\) muss " + ("" if k == 1 else str(k) + "-mal ") + "differenzierbar sein."}]),
            abschnitt("Sind die Voraussetzungen erfüllt?", voraussetzung_diffbar(L, max(k, 0))),
            abschnitt("Schrittweise Berechnung", bl),
            abschnitt("Ergebnis", [{"t": "box", "s": "\\(" + ergebnis + "\\)"}])
        ]
    }


def erkl_funktion(L):
    bl, erg = [], []
    if L.poly:
        n, an = grad(L.c), L.c[-1]
        bl.append({"t": "p", "s": "<b>Grad und Leitkoeffizient:</b> Grad \\(" + str(n) + "\\), Leitkoeffizient \\(a_{" + str(n) + "} = " + zt(an) + "\\), Absolutglied \\(a_{0} = " + zt(L.c[0]) + "\\)."})
        if n >= 1:
            plus = "+\\infty" if an > 0 else "-\\infty"
            minus = "+\\infty" if (n % 2 == 0) == (an > 0) else "-\\infty"
            bl.append({"t": "p", "s": "<b>Verhalten für \\(x \\to \\pm\\infty\\):</b> entscheidend ist der Summand mit der höchsten Potenz \\(" + ptex([v if i == n else 0 for i, v in enumerate(L.c)]) + "\\)."})
            bl.append({"t": "m", "s": "x \\to +\\infty:\\; " + L.fn + "(x) \\to " + plus + ", \\qquad x \\to -\\infty:\\; " + L.fn + "(x) \\to " + minus})
        gerade = all(v == 0 for i, v in enumerate(L.c) if i % 2 == 1)
        ungerade = all(v == 0 for i, v in enumerate(L.c) if i % 2 == 0)
        sym = ("Nullfunktion." if gerade and ungerade else
               "Nur gerade Exponenten ⇒ \\(" + L.fn + "(-x) = " + L.fn + "(x)\\): achsensymmetrisch zur \\(y\\)-Achse." if gerade else
               "Nur ungerade Exponenten ⇒ \\(" + L.fn + "(-x) = -" + L.fn + "(x)\\): punktsymmetrisch zum Ursprung." if ungerade else
               "Gerade und ungerade Exponenten gemischt ⇒ keine Symmetrie zur \\(y\\)-Achse oder zum Ursprung.")
        bl.append({"t": "p", "s": "<b>Symmetrie:</b> " + sym})
        bl.append({"t": "p", "s": "<b>Höchstzahlen:</b> höchstens \\(" + str(n) + "\\) Nullstellen, höchstens \\(" + str(max(n - 1, 0)) + "\\) Extremstellen, höchstens \\(" + str(max(n - 2, 0)) + "\\) Wendestellen."})
        erg.append({"t": "box", "s": "Ganzrationale Funktion vom Grad \\(" + str(n) + "\\); \\(" + L.fn + "(0) = " + zt(L.c[0]) + "\\)"})
    else:
        fk = W["funktionen"](L.A)
        bl.append({"t": "p", "s": "Allgemeine Funktion" + ((" mit den Grundfunktionen " + ", ".join("\\(\\mathrm{" + n + "}\\)" for n in fk)) if fk else "") + ". Untersucht wird der sichtbare Bereich \\(" + zt(L.x0) + " \\le x \\le " + zt(L.x1) + "\\)."})
        y0 = L.f(0.0)
        bl.append({"t": "p", "s": "\\(" + L.fn + "(0) " + (zg(glatt(y0)) if _endl(y0) else "\\text{ ist nicht definiert}") + "\\)"})
        erg.append({"t": "box", "s": "Funktionsterm: \\(" + L.fn + "(x) = " + L.tex + "\\)"})
    return {"titel": "Die Funktion \\(" + L.fn + "\\)",
            "abschnitte": [kopf_abschnitt(L, [{"t": "p", "s": "Überblick über die Funktion: Art, Verhalten an den Rändern und Symmetrie."}]), abschnitt("Eigenschaften", bl), abschnitt("Ergebnis", erg)]}


ARTEN = ("null", "ext", "wende", "integral", "schnitt", "yachse", "tH", "tT", "tW", "tP", "sek",
         "ober", "unter", "trapez", "mitte", "kF", "kf", "kd1", "kd2", "kd3")


def erzeuge(sz: dict) -> dict:
    """Dokument zur Erklärung sz["art"] (siehe Modulbeschreibung)."""
    if not W:
        setze_werkzeuge(standard_werkzeuge())
    L = lage(sz)
    art = sz["art"]
    if art == "null":
        return erkl_nullstellen(L)
    if art == "ext":
        return erkl_extrema(L, "alle", False)
    if art == "wende":
        return erkl_wende(L, False)
    if art == "integral":
        return erkl_integral(L)
    if art == "schnitt":
        return erkl_schnitt(L)
    if art == "yachse":
        return erkl_y_achse(L)
    if art == "tH":
        return erkl_extrema(L, "H", True)
    if art == "tT":
        return erkl_extrema(L, "T", True)
    if art == "tW":
        return erkl_wende(L, True)
    if art == "tP":
        return erkl_tangente_p(L)
    if art == "sek":
        return erkl_sekante(L)
    if art in _SUMME_NAME:
        return erkl_summe(L, art)
    kurve = {"kF": -1, "kf": 0, "kd1": 1, "kd2": 2, "kd3": 3}
    if art in kurve:
        return erkl_kurve(L, kurve[art])
    raise ValueError("Unbekannte Erklärung: " + str(art))


def setze_werkzeuge(w: dict) -> None:
    W.update(w)


def standard_werkzeuge() -> dict:
    """Werkzeuge aus polynom_explorer.py und funktionen_explorer.py (dieselben Verfahren wie im Explorer)."""
    import numpy as np
    import polynom_explorer as pe
    import funktionen_explorer as fe

    def ausdruck(text):
        def huelle(a):                         # Ausdruck ist für Zahlen und numpy-Arrays aufrufbar
            return {"f": a, "tex": a.tex, "abl": lambda: huelle(a.ableitung()), "baum": a.baum}
        return huelle(fe.Ausdruck(text))

    def ruf_namen(A):
        menge = set()

        def lauf(n):
            if n[0] == "ruf":
                menge.add(n[1])
                for a in n[2]:
                    lauf(a)
            else:
                for teil in n[1:]:
                    if isinstance(teil, tuple):
                        lauf(teil)
        lauf(A["baum"])
        return sorted(menge)

    def luecken(f, x0, x1):
        return any(not math.isfinite(f(x0 + (x1 - x0) * i / 2000)) for i in range(2001))

    def norm(e):
        ext = [{"x": float(p[0]), "y": float(p[1]), "typ": "H" if p[2] == "Hochpunkt" else "T"} for p in e["extrema"]]
        return {"nullstellen": [float(x) for x in e["nullstellen"]], "extrema": ext,
                "sattelpunkte": [{"x": float(p[0]), "y": float(p[1])} for p in e["sattelpunkte"]],
                "wendepunkte": [{"x": float(p[0]), "y": float(p[1])} for p in e["wendepunkte"]],
                "integral": e.get("integral"), "flaeche": e.get("flaeche")}

    def vektor(f):                             # alle Funktionen der Herleitung verarbeiten auch numpy-Arrays
        return f

    def null_num(g, x0, x1):
        gx = np.linspace(x0, x1, 4001)
        gy = np.asarray(g(gx), dtype=float)
        return [float(v) for v in fe._nullstellen_von(vektor(g), gx, gy)]

    def summe(f, a, b, n, art, krit):
        s = pe.riemann_summe(vektor(f), a, b, n, art, kritisch=krit)
        return s

    def tangente_allg(f, x, breite):
        return fe.tangente_in(vektor(f), x, breite)

    return {"dez": pe._dez, "ausdruck": ausdruck, "funktionen": ruf_namen, "luecken": luecken,
            "analyse_poly": lambda c, a, b: norm(pe.analysiere(c, a, b)),
            "analyse_allg": lambda f, x0, x1, a, b: norm(fe.analysiere_funktion(vektor(f), x0, x1, a, b)),
            "null_poly": lambda c: [float(x) for x in pe._reelle_nullstellen(np.asarray(c, dtype=float))],
            "null_num": null_num, "summe": summe, "tangente_allg": tangente_allg}


# ---------- Druckfertige HTML-Seite ----------
KATEX = "https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.11/"


def als_html(dok: dict, katex_basis: str = KATEX) -> str:
    """Eigenständige, druckbare HTML-Seite (gesetzt im Browser mit KaTeX; derselbe Aufbau wie im Explorer)."""
    daten = json.dumps(dok, ensure_ascii=False).replace("</", "<\\/")
    return ("<!doctype html><html lang=\"de\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            "<title>" + _klartext(dok["titel"]) + "</title>"
            "<link rel=\"stylesheet\" href=\"" + katex_basis + "katex.min.css\">"
            "<script src=\"" + katex_basis + "katex.min.js\"></script>"
            "<style>body{margin:0;background:#e9ebef} .blatt{max-width:820px;margin:24px auto;padding:28px 34px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,.12)}"
            " .leiste{max-width:820px;margin:16px auto 0;display:flex;justify-content:flex-end;gap:8px} .leiste button{font:15px -apple-system,Segoe UI,Arial,sans-serif;padding:7px 16px;border-radius:8px;border:1px solid #2454c9;background:#2454c9;color:#fff;cursor:pointer}"
            " @media print{body{background:#fff}.leiste{display:none}.blatt{box-shadow:none;margin:0;max-width:none;padding:0}} @page{margin:18mm 16mm}</style>"
            "</head><body><div class=\"leiste\"><button onclick=\"window.print()\">🖨 Drucken</button></div><div class=\"blatt hl-dok\" id=\"dok\"></div>"
            "<script>" + ANSICHT_JS + "\nconst DOK = " + daten + ";\n"
            "document.head.insertAdjacentHTML('beforeend', '<style>' + HerleitungAnsicht.CSS + '</style>');\n"
            "document.getElementById('dok').innerHTML = HerleitungAnsicht.html(DOK);</script></body></html>")


def _klartext(s: str) -> str:
    import re
    t = re.sub(r"\\\(|\\\)", "", s)
    t = re.sub(r"\\[a-zA-Z]+", "", t).replace("{", "").replace("}", "")
    return t.replace("&", "&amp;").replace("<", "&lt;").strip()


def zeige(dok: dict, pfad: str | None = None) -> str:
    """Schreibt die Seite (Standard: temporäre Datei) und öffnet sie im Browser."""
    import os
    import tempfile
    import webbrowser
    if pfad is None:
        pfad = os.path.join(tempfile.gettempdir(), "funktionen-explorer-herleitung.html")
    with open(pfad, "w", encoding="utf-8") as f:
        f.write(als_html(dok))
    webbrowser.open("file://" + os.path.abspath(pfad))
    return pfad


# ---------- Darstellung (aus herleitung_ansicht.js, wird mit sync_herleitung.py übernommen) ----------
ANSICHT_JS = r"""
// Darstellung eines Herleitungs-Dokuments mit KaTeX (gemeinsam für Explorer-Fenster und Python-Druckseite)
const HerleitungAnsicht = (() => {
  const URHEBER = `<footer class="hl-urheber"><span>Copyright B. Ericke - Schuljahr 2026/2027.</span><span>Nur für den Unterricht.</span><span>Weitergabe, Veränderungen, Veröffentlichung durch Dritte nicht gestattet.</span></footer>`;
  const esc = s => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  function formel(tex, display) {
    try { return katex.renderToString(tex, { displayMode: display, throwOnError: false, strict: "ignore", output: "html" }); }
    catch (e) { return "<code>" + esc(tex) + "</code>"; }
  }
  function zeile(s) {                              // Text mit \( … \) und <b> … </b>
    let out = "", i = 0;
    while (i < s.length) {
      const j = s.indexOf("\\(", i);
      if (j < 0) { out += text(s.slice(i)); break; }
      out += text(s.slice(i, j));
      const k = s.indexOf("\\)", j + 2);
      if (k < 0) { out += text(s.slice(j)); break; }
      out += formel(s.slice(j + 2, k), false);
      i = k + 2;
    }
    return out;
  }
  function text(s) { return esc(s).replace(/&lt;b&gt;/g, "<b>").replace(/&lt;\/b&gt;/g, "</b>"); }
  function block(b) {
    switch (b.t) {
      case "p": return `<p>${zeile(b.s)}</p>`;
      case "m": return `<div class="hl-formel">${formel(b.s, true)}</div>`;
      case "ul": return `<ul>${b.s.map(x => `<li>${zeile(x)}</li>`).join("")}</ul>`;
      case "box": return `<div class="hl-ergebnis">${zeile(b.s)}</div>`;
      case "hinweis": return `<p class="hl-hinweis">${zeile(b.s)}</p>`;
      case "tab": return `<div class="hl-tabwrap"><table class="hl-tab"><thead><tr>${b.kopf.map(k => `<th>${zeile(k)}</th>`).join("")}</tr></thead><tbody>` +
        b.zeilen.map(z => `<tr>${z.map(c => `<td>${zeile(c)}</td>`).join("")}</tr>`).join("") + `</tbody></table></div>`;
    }
    return "";
  }
  function html(doc) {
    let h = `<h1 class="hl-titel">${zeile(doc.titel)}</h1>`;
    for (const a of doc.abschnitte) h += `<section class="hl-abschnitt"><h2>${zeile(a.titel)}</h2>${a.inhalt.map(block).join("")}</section>`;
    return h + URHEBER;
  }
  const CSS = `
.hl-dok { font: 16px/1.55 "Latin Modern Roman", "Computer Modern Serif", "Cambria", "Georgia", serif; color: #111; background: #fff; }
.hl-dok .hl-titel { font-size: 24px; font-weight: 600; margin: 0 0 4px; }
.hl-dok h2 { font-size: 17px; font-weight: 700; margin: 20px 0 6px; padding-bottom: 3px; border-bottom: 1px solid #c9ccd3; font-family: -apple-system, "Segoe UI", Arial, sans-serif; letter-spacing: .2px; }
.hl-dok p { margin: 6px 0; }
.hl-dok .hl-formel { margin: 8px 0 8px 18px; overflow-x: auto; overflow-y: hidden; }
.hl-dok .hl-formel .katex-display { margin: 0; text-align: left; }
.hl-dok .hl-formel .katex-display > .katex { text-align: left; }
.hl-dok .katex { font-size: 1.08em; }
.hl-dok .hl-ergebnis { margin: 8px 0; padding: 10px 14px; border: 1.5px solid #2454c9; border-radius: 8px; background: #eef3ff; }
.hl-dok .hl-hinweis { color: #5d6576; font-size: 14px; }
.hl-dok .hl-tabwrap { overflow-x: auto; margin: 8px 0; }
.hl-dok .hl-tab { border-collapse: collapse; font-size: 15px; }
.hl-dok .hl-tab th, .hl-dok .hl-tab td { border: 1px solid #c9ccd3; padding: 4px 10px; text-align: center; }
.hl-dok .hl-tab th { background: #f0f2f6; font-family: -apple-system, "Segoe UI", Arial, sans-serif; font-size: 13px; }
.hl-dok section { break-inside: auto; }
.hl-dok .hl-urheber { display: flex; flex-wrap: wrap; justify-content: center; gap: 2px 26px; margin-top: 28px; padding-top: 8px; border-top: 1px solid #c9ccd3;
  font: 11.5px/1.4 -apple-system, "Segoe UI", Arial, sans-serif; color: #5d6576; text-align: center; break-inside: avoid; }
.hl-dok h2 { break-after: avoid; }
.hl-dok .hl-formel, .hl-dok .hl-ergebnis, .hl-dok tr { break-inside: avoid; }`;
  return { html, CSS, zeile };
})();
"""
