"""Selbsttest des Rechenkerns: python3 -m formeleditor --selbsttest

Prüft jede Beispielzeile zweimal: (1) den SymPy-Wert gegen den erwarteten Wert, (2) dass der Formelsatz
(LaTeX und StarMath) fehlerfrei entsteht. Am Ende steht eine Zusammenfassung zum Weitergeben.
"""
import sys
import traceback

# (Eingabe, erwarteter Wert als SymPy-Text | ("menge", [...]) | ("zahl", wert, toleranz) | None = nur Satz prüfen)
FAELLE = [
    # Grundlagen
    ("2x^2 - 3x + 1", "2*x**2 - 3*x + 1"),
    ("1,5 + 1/4", "7/4"),
    ("sqrt(8)", "2*sqrt(2)"),
    ("root(-8; 3)", "-2"),
    ("binomial(5; 2)", "10"),
    ("5!", "120"),
    ("log(8; 2)", "3"),
    ("e^(ln(3))", "3"),
    ("|-3| + |2|", "5"),
    ("sin(pi/6)", "1/2"),
    # Festlegungen
    ("a := 3", None),
    ("f(x) := x^3 - 4x", None),
    ("a^2 + 1", "10"),
    ("f(2)", "0"),
    ("f'(x)", "3*x**2 - 4"),
    ("f''(1)", "6"),
    # Analysis
    ("diff(x^3; x)", "3*x**2"),
    ("diff(sin(x)^2; x)", "2*sin(x)*cos(x)"),
    ("diff(x^4; x; 2)", "12*x**2"),
    ("integrate(x^2; x)", "x**3/3"),
    ("integrate(x^2; x; 0; 1)", "1/3"),
    ("integrate(f(x); x; 0; 2)", "-4"),
    ("integrate(e^(-x); x; 0; oo)", "1"),
    ("limit(sin(x)/x; x; 0)", "1"),
    ('limit(1/x; x; 0; "+")', "oo"),
    ("limit((1 + 1/n)^n; n; oo)", "E"),
    ("summation(1/k^2; k; 1; oo)", "pi**2/6"),
    ("summation(k; k; 1; n)", "n*(n + 1)/2"),
    ("product(k; k; 1; 5)", "120"),
    ("series(e^x; x; 0; 3)", "1 + x + x**2/2 + x**3/6"),
    ("tangente(x^2; x; 1)", "2*x - 1"),
    ("dsolve(y' = y; y; y(0) = 1)", None),
    # Algebra
    ("expand((x + 1)^3)", "x**3 + 3*x**2 + 3*x + 1"),
    ("factor(x^2 - 5x + 6)", "(x - 2)*(x - 3)"),
    ("simplify(sin(x)^2 + cos(x)^2)", "1"),
    ("apart(1/(x^2 - 1))", "1/(2*(x - 1)) - 1/(2*(x + 1))"),
    ("solve(x^2 = 4; x)", ("menge", ["-2", "2"])),
    ("solve(f(x) = 0; x)", ("menge", ["-2", "0", "2"])),
    ("x^2 - 9 = 0", ("menge", ["-3", "3"])),
    ("solve(x^2 + 1 = 0; x)", ("menge", [])),
    ("csolve(x^2 + 1 = 0; x)", ("menge", ["-I", "I"])),
    ("solve(x^2 > 4; x)", None),
    ("solve([x + y = 3; x - y = 1]; [x; y])", None),
    ("subs(x^2 + 1; x; 3)", "10"),
    ("N(pi; 15)", ("zahl", 3.14159265358979, 1e-12)),
    # Lineare Algebra
    ("det([[1; 2]; [3; 4]])", "-2"),
    ("inv([[1; 2]; [3; 4]])", "Matrix([[-2, 1], [3/2, -1/2]])"),
    ("transpose([[1; 2]; [3; 4]])", "Matrix([[1, 3], [2, 4]])"),
    ("rank([[1; 2]; [2; 4]])", "1"),
    ("eigenvals([[2; 0]; [0; 3]])", None),
    ("dot([1; 2; 3]; [4; 5; 6])", "32"),
    ("cross([1; 0; 0]; [0; 1; 0])", "Matrix([0, 0, 1])"),
    ("norm([3; 4])", "5"),
    ("[[1; 2]; [3; 4]] * [1; 1]", "Matrix([3, 7])"),
    ("linsolve([[1; 1]; [1; -1]]; [3; 1])", "Matrix([2, 1])"),
    # Numerik
    ("nsolve(cos(x) = x; x; 1)", None),
    ("fsolve(x^3 - 2; x; 1)", None),
    ("brentq(x^2 - 2; x; 0; 2)", None),
    ("quad(e^(-x^2); x; -oo; oo)", ("zahl", 1.7724538509055159, 1e-8)),
    ("nroots(x^3 - 6x^2 + 11x - 6)", None),
    ("minimize((x - 2)^2 + 1; x; 0)", None),
    # Stochastik
    ("binompdf(10; 0,5; 5)", ("zahl", 0.24609375, 1e-12)),
    ("binomcdf(10; 0,5; 5)", ("zahl", 0.623046875, 1e-12)),
    ("binomcdf(10; 0,5; 3; 7)", ("zahl", 0.890625, 1e-12)),
    ("normcdf(-1; 1; 0; 1)", ("zahl", 0.6826894921370859, 1e-9)),
    ("invnorm(0,975; 0; 1)", ("zahl", 1.959963984540054, 1e-9)),
    ("poissonpdf(2; 3)", ("zahl", 0.18044704431548356, 1e-12)),
    ("mean([1; 2; 3; 4])", ("zahl", 2.5, 1e-12)),
    ("std([2; 4; 4; 4; 5; 5; 7; 9])", ("zahl", 2.0, 1e-12)),
    ("erwartungswert([0; 1; 2]; [1/4; 1/2; 1/4])", "1"),
]


def main():
    try:
        import sympy as sp
    except ImportError:
        print("SymPy ist nicht installiert. Bitte das Installationsskript ausführen.")
        return 1
    import numpy
    import scipy
    from .rechnen import Arbeitsblatt
    print(f"Python {sys.version.split()[0]} · SymPy {sp.__version__} · NumPy {numpy.__version__} · SciPy {scipy.__version__}")
    blatt = Arbeitsblatt()
    ok = fehler = 0
    protokoll = []
    for eingabe, erwartet in FAELLE:
        zeile = f"{eingabe:45s}"
        try:
            if ":=" in eingabe:
                erg = blatt.berechne(eingabe)
                stimmt = True
            else:
                k = blatt.parse(eingabe)
                wert = blatt.ausdruck(k) if k[0] != "rel" else None
                erg = blatt.berechne(eingabe)
                stimmt = _pruefe(sp, blatt, k, wert, erwartet, erg)
            if stimmt:
                ok += 1
                zeile += " ✓  " + erg["latex"]
            else:
                fehler += 1
                zeile += " ✗  erwartet " + repr(erwartet) + "  |  " + erg["latex"]
        except Exception as e:
            fehler += 1
            zeile += f" ✗  {type(e).__name__}: {e}"
            protokoll.append(traceback.format_exc())
        print(zeile)
    print(f"\n{ok} von {ok + fehler} Prüfungen bestanden.")
    if protokoll:
        print("\n--- Fehlerdetails ---")
        for p in protokoll:
            print(p)
    return 0 if fehler == 0 else 2


def _pruefe(sp, blatt, k, wert, erwartet, erg):
    for schluessel in ("latex", "starmath", "eingabe_latex", "ergebnis_latex"):
        if not isinstance(erg.get(schluessel), str):
            return False
    if erwartet is None:
        return True
    if isinstance(erwartet, tuple) and erwartet[0] == "zahl":
        return abs(float(wert) - erwartet[1]) <= erwartet[2]
    if isinstance(erwartet, tuple) and erwartet[0] == "menge":
        from .satz import latex
        from .rechnen import ast_aus_sympy
        werte = [sp.sympify(x) for x in erwartet[1]]
        if all(w.is_real for w in werte):
            return latex(("menge", [ast_aus_sympy(x) for x in sorted(werte)])) in erg["latex"]
        return all(latex(ast_aus_sympy(w)) in erg["latex"] for w in werte)
    ziel = sp.sympify(erwartet, locals={"x": blatt.sym("x"), "n": blatt.sym("n"), "E": sp.E})
    if wert == ziel:                                   # auch für ∞ (∞ − ∞ wäre unbestimmt)
        return True
    if isinstance(wert, sp.MatrixBase):
        return sp.simplify(wert - ziel) == sp.zeros(*wert.shape)
    return sp.simplify(wert - ziel) == 0


if __name__ == "__main__":
    sys.exit(main())
