"""Start: python3 -m formeleditor [--fenster] [--port N] [--kein-browser] [--selbsttest]

--fenster       eigenes Programmfenster (pywebview), sonst Standardbrowser
--selbsttest    prüft den Rechenkern und gibt einen Bericht aus
"""
import argparse
import sys
import time
import webbrowser

from .server import starte, STANDARD_PORT


def main(argv=None):
    p = argparse.ArgumentParser(prog="formeleditor", description="Formeleditor mit SymPy, NumPy und SciPy")
    p.add_argument("--fenster", action="store_true", help="eigenes Fenster (pywebview)")
    p.add_argument("--port", type=int, default=STANDARD_PORT)
    p.add_argument("--kein-browser", action="store_true")
    p.add_argument("--selbsttest", action="store_true")
    a = p.parse_args(argv)
    if a.selbsttest:
        from .selbsttest import main as test
        return test()
    srv, url = starte(a.port, im_hintergrund=True)
    if a.fenster:
        try:
            import webview
        except ImportError:
            print("pywebview fehlt – öffne den Editor im Browser.", file=sys.stderr)
        else:
            if sys.platform == "darwin":               # Name im Menü „Formeleditor“ statt „Python“
                try:
                    from Foundation import NSBundle
                    info = NSBundle.mainBundle().infoDictionary()
                    info["CFBundleName"] = "Formeleditor"
                    info["CFBundleDisplayName"] = "Formeleditor"
                except Exception:
                    pass
            webview.create_window("Formeleditor", url, width=1280, height=860, min_size=(820, 560))
            webview.start()
            srv.shutdown()
            return 0
    print("Formeleditor läuft unter", url, "– beenden mit Ctrl+C")
    if not a.kein_browser:
        webbrowser.open(url)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        srv.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
