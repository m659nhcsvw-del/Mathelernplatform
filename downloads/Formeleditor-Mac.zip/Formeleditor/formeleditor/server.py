"""Lokaler Webserver des Formeleditors (nur Python-Standardbibliothek).

GET  /                  Oberfläche          GET /katex/…   KaTeX (lokal, offline)
GET  /api/vorlagen      Vorlagenkatalog     GET /api/info  Versionen der Bibliotheken
POST /api/satz          {"text", "variablen", "funktionen"} → {"latex", "starmath", "definiert"} bzw. {"fehler", "pos"}
POST /api/berechne      {"zeilen": [...], "index": i} → Ergebnis der Zeile i (Festlegungen der Zeilen davor gelten)
POST /api/uebergabe     {"starmath", "quelle", "titel"} → schreibt die Übergabedatei für LibreOffice
GET  /api/auftrag       neuer Bearbeitungsauftrag aus LibreOffice (oder {"auftrag": null})
GET  /api/iwork_apps    geöffnete iWork-Programme (Pages, Keynote, Numbers)
POST /api/iwork_formel  {"app", "latex"} → Gleichung direkt einfügen (macOS)
POST /api/iwork_bild    {"app", "svg", "png", "beschreibung", "name"} → Grafik direkt einfügen (macOS)
GET  /explorer/         Funktionen-Explorer (iWork-Ausgabe)
Die reinen Rechenaufrufe stehen in webapi.py und laufen genauso im Browser (Pyodide).
"""
import json
import os
import threading
import time
import urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

from .webapi import ruf, satz_antwort, info, berechne_zeilen  # noqa: F401 (auch für andere Aufrufer)
from . import iwork_mac

WEB = os.path.join(os.path.dirname(__file__), "web")
STANDARD_PORT = 47110
PY_DATEIEN = ("__init__.py", "sprache.py", "satz.py", "vorlagen.py", "rechnen.py", "webapi.py")


def austauschordner():
    """Ordner für den Austausch mit LibreOffice (auf allen Systemen gleich aufgebaut)."""
    d = os.path.join(os.path.expanduser("~"), "Library", "Application Support", "Formeleditor")
    os.makedirs(d, exist_ok=True)
    return d


UEBERGABE = "uebergabe.txt"      # Editor → LibreOffice
AUFTRAG = "bearbeiten.txt"       # LibreOffice → Editor


def schreibe_uebergabe(starmath, quelle, titel):
    pfad = os.path.join(austauschordner(), UEBERGABE)
    tmp = pfad + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write("FORMELEDITOR 1\n")
        f.write(" ".join(starmath.split()) + "\n")
        f.write(urllib.parse.quote(json.dumps(quelle, ensure_ascii=False), safe="") + "\n")
        f.write(" ".join(titel.split())[:200] + "\n")
    os.replace(tmp, pfad)
    return pfad


def lies_auftrag():
    pfad = os.path.join(austauschordner(), AUFTRAG)
    try:
        with open(pfad, encoding="utf-8") as f:
            zeilen = f.read().splitlines()
    except FileNotFoundError:
        return None, None
    if not zeilen or not zeilen[0].startswith("FORMELEDITOR-AUFTRAG"):
        return None, None
    quelle = None
    if len(zeilen) > 1 and zeilen[1].strip():
        try:
            quelle = json.loads(urllib.parse.unquote(zeilen[1].strip()))
        except ValueError:
            quelle = None
    return os.path.getmtime(pfad), quelle


class _Handler(BaseHTTPRequestHandler):
    server_version = "Formeleditor/1.0"
    letzter_auftrag = [0.0]

    def log_message(self, *a):
        pass

    def _json(self, daten, status=200):
        roh = json.dumps(daten, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(roh)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(roh)

    def _datei(self, pfad, wurzel=WEB):
        typen = {".html": "text/html; charset=utf-8", ".js": "application/javascript", ".css": "text/css",
                 ".woff2": "font/woff2", ".woff": "font/woff", ".ttf": "font/ttf", ".svg": "image/svg+xml",
                 ".png": "image/png", ".json": "application/json",
                 ".py": "text/plain; charset=utf-8", ".webmanifest": "application/manifest+json"}
        voll = os.path.normpath(os.path.join(wurzel, pfad.lstrip("/")))
        if not voll.startswith(wurzel) or not os.path.isfile(voll):
            self.send_error(404)
            return
        with open(voll, "rb") as f:
            roh = f.read()
        self.send_response(200)
        self.send_header("Content-Type", typen.get(os.path.splitext(voll)[1], "application/octet-stream"))
        self.send_header("Content-Length", str(len(roh)))
        self.end_headers()
        self.wfile.write(roh)

    def do_GET(self):
        pfad = urllib.parse.urlparse(self.path).path
        if pfad in ("/", "/index.html"):
            return self._datei("index.html")
        if pfad in ("/explorer", "/explorer/"):
            return self._datei("explorer/index.html")
        if pfad == "/api/info":
            return self._json(dict(info(), mac=iwork_mac.verfuegbar()))
        if pfad == "/api/iwork_apps":
            return self._json({"apps": iwork_mac.laufende_apps(), "mac": iwork_mac.verfuegbar()})
        if pfad == "/api/auftrag":
            zeit, quelle = lies_auftrag()
            if zeit and zeit > self.letzter_auftrag[0]:
                self.letzter_auftrag[0] = zeit
                return self._json({"auftrag": quelle or {"zeilen": [""]}})
            return self._json({"auftrag": None})
        if pfad.startswith("/py/") and pfad[4:] in PY_DATEIEN:     # Quellen für den Browser-Rechenkern (Pyodide)
            return self._datei(pfad[4:], os.path.dirname(__file__))
        if pfad.startswith("/api/"):
            antwort = ruf(pfad)
            if antwort is not None:
                return self._json(antwort)
        return self._datei(pfad)

    def do_POST(self):
        laenge = int(self.headers.get("Content-Length", 0))
        try:
            daten = json.loads(self.rfile.read(laenge) or b"{}")
        except ValueError:
            return self._json({"fehler": "ungültige Anfrage"}, 400)
        pfad = urllib.parse.urlparse(self.path).path
        if pfad == "/api/iwork_formel":
            return self._json(iwork_mac.gleichung_einfuegen(daten.get("app", ""), daten.get("latex", "")))
        if pfad == "/api/iwork_bild":
            return self._json(iwork_mac.bild_einfuegen(daten.get("app", ""), daten.get("svg", ""), daten.get("png", ""),
                                                       daten.get("beschreibung", ""), daten.get("name", "grafik")))
        if pfad == "/api/uebergabe":
            p = schreibe_uebergabe(daten.get("starmath", ""), daten.get("quelle", {}), daten.get("titel", ""))
            return self._json({"ok": True, "pfad": p})
        antwort = ruf(pfad, daten)
        if antwort is not None:
            return self._json(antwort)
        self.send_error(404)


def starte(port=STANDARD_PORT, im_hintergrund=True):
    """Startet den Server; gibt (server, url) zurück. Ist der Port belegt, wird ein freier gewählt."""
    # alte Aufträge nicht erneut laden
    zeit, _ = lies_auftrag()
    _Handler.letzter_auftrag[0] = (zeit or 0.0) if time.time() - (zeit or 0) > 30 else 0.0
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", port), _Handler)
    except OSError:
        srv = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    url = f"http://127.0.0.1:{srv.server_address[1]}/"
    if im_hintergrund:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, url
