"""Direktes Einfügen in Pages, Keynote und Numbers (nur macOS, über AppleScript/osascript).

Gleichungen: Apple bietet dafür keinen AppleScript-Befehl. Deshalb wird der Menübefehl
„Einfügen → Gleichung …“ (⌥⌘E) über „System Events“ ausgelöst, das LaTeX eingesetzt und
„Einfügen“ gedrückt. Dafür braucht das Programm einmalig das Recht „Bedienungshilfen“
(Systemeinstellungen → Datenschutz & Sicherheit → Bedienungshilfen).
Grafiken: werden mit „make new image“ eingefügt (Keynote: aktuelle Folie, Numbers: aktives Blatt,
Pages: über die Zwischenablage an der Schreibmarke); die Beschreibung trägt den Explorer-Zustand.
"""
import base64
import os
import subprocess
import sys
import tempfile
import time

APPS = ("Pages", "Keynote", "Numbers")


def verfuegbar():
    return sys.platform == "darwin"


def _osascript(skript, *argumente, zeit=30):
    r = subprocess.run(["osascript", "-"] + list(argumente), input=skript, capture_output=True,
                       text=True, timeout=zeit)
    return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()


def laufende_apps():
    """Geöffnete iWork-Programme – über die Prozessliste, damit macOS dafür KEINE Steuerungserlaubnis abfragt."""
    if not verfuegbar():
        return []
    try:
        aus = subprocess.run(["/bin/ps", "-axo", "comm="], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        return []
    pfade = aus.splitlines()
    return [a for a in APPS if any(z.endswith(f"/{a}.app/Contents/MacOS/{a}") for z in pfade)]


def _fehlertext(fehler):
    if "-1719" in fehler or "-25211" in fehler or "assistive" in fehler.lower() or "bedienungshilfen" in fehler.lower():
        return ("macOS erlaubt das Tippen in andere Programme noch nicht. Bitte in Systemeinstellungen → "
                "Datenschutz & Sicherheit → Bedienungshilfen „Formeleditor“ einschalten und erneut versuchen.")
    if "-1743" in fehler:
        return ("macOS erlaubt die Steuerung noch nicht. Bitte in Systemeinstellungen → Datenschutz & Sicherheit → "
                "Automation dem Formeleditor die Steuerung von „System Events“ und der iWork-Programme erlauben.")
    if "-600" in fehler or "-1728" in fehler:
        return "Das Programm ist nicht geöffnet oder hat kein Dokument im Vordergrund."
    return fehler or "unbekannter Fehler"


_GLEICHUNG = r'''
on run argv
    set appName to item 1 of argv
    set tex to item 2 of argv
    set alteAblage to missing value
    try
        set alteAblage to the clipboard
    end try
    set the clipboard to tex
    tell application appName to activate
    delay 0.6
    tell application "System Events"
        tell process appName
            set frontmost to true
            keystroke "e" using {option down, command down}
            delay 1.0
            keystroke "a" using command down
            keystroke "v" using command down
            delay 0.8
            set geklickt to false
            repeat with ziel in {"Einfügen", "Insert", "Aktualisieren", "Update"}
                try
                    click button (ziel as text) of sheet 1 of window 1
                    set geklickt to true
                    exit repeat
                end try
                try
                    click button (ziel as text) of window 1
                    set geklickt to true
                    exit repeat
                end try
            end repeat
            if not geklickt then key code 36 using command down
        end tell
    end tell
    delay 0.4
    if alteAblage is not missing value then
        try
            set the clipboard to alteAblage
        end try
    end if
    return "ok"
end run
'''


def gleichung_einfuegen(app, latex):
    if not verfuegbar():
        return {"fehler": "Direktes Einfügen gibt es nur auf dem Mac."}
    if app not in APPS:
        return {"fehler": "Unbekanntes Programm: " + str(app)}
    try:
        code, aus, fehler = _osascript(_GLEICHUNG, app, latex)
    except subprocess.TimeoutExpired:
        return {"fehler": "Zeitüberschreitung bei der Steuerung von " + app}
    if code:
        return {"fehler": _fehlertext(fehler)}
    return {"ok": True}


_BILD = r'''
on run argv
    set appName to item 1 of argv
    set pfad to item 2 of argv
    set ersatz to item 3 of argv
    set beschreibung to item 4 of argv
    set datei to POSIX file pfad
    tell application appName to activate
    if appName is "Keynote" then
        tell application "Keynote"
            tell front document
                tell current slide
                    try
                        set bild to make new image with properties {file:datei}
                    on error
                        set bild to make new image with properties {file:(POSIX file ersatz)}
                    end try
                    try
                        set description of bild to beschreibung
                    end try
                end tell
            end tell
        end tell
    else if appName is "Numbers" then
        tell application "Numbers"
            tell front document
                tell active sheet
                    try
                        set bild to make new image with properties {file:datei}
                    on error
                        set bild to make new image with properties {file:(POSIX file ersatz)}
                    end try
                    try
                        set description of bild to beschreibung
                    end try
                end tell
            end tell
        end tell
    else
        -- Pages: an der Schreibmarke einfügen (PNG über die Zwischenablage), sonst frei schwebend
        try
            set the clipboard to (read (POSIX file ersatz) as «class PNGf»)
            tell application "System Events" to tell process "Pages"
                set frontmost to true
                keystroke "v" using command down
            end tell
        on error
            tell application "Pages"
                tell front document
                    set bild to make new image with properties {file:datei}
                    try
                        set description of bild to beschreibung
                    end try
                end tell
            end tell
        end try
    end if
    return "ok"
end run
'''


def bild_einfuegen(app, svg, png_base64, beschreibung, name="funktionen-explorer"):
    if not verfuegbar():
        return {"fehler": "Direktes Einfügen gibt es nur auf dem Mac."}
    if app not in APPS:
        return {"fehler": "Unbekanntes Programm: " + str(app)}
    ordner = os.path.join(tempfile.gettempdir(), "formeleditor-iwork")
    os.makedirs(ordner, exist_ok=True)
    stempel = time.strftime("%Y%m%d-%H%M%S")
    sicher = "".join(c if c.isalnum() or c in "-_" else "-" for c in name)[:60] or "grafik"
    p_svg = os.path.join(ordner, f"{sicher}-{stempel}.svg")
    p_png = os.path.join(ordner, f"{sicher}-{stempel}.png")
    with open(p_svg, "w", encoding="utf-8") as f:
        f.write(svg)
    with open(p_png, "wb") as f:
        f.write(base64.b64decode(png_base64.split(",")[-1]))
    try:
        code, aus, fehler = _osascript(_BILD, app, p_svg, p_png, beschreibung[:30000])
    except subprocess.TimeoutExpired:
        return {"fehler": "Zeitüberschreitung bei der Steuerung von " + app}
    if code:
        return {"fehler": _fehlertext(fehler)}
    return {"ok": True}
