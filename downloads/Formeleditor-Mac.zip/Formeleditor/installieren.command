#!/bin/bash
# Formeleditor – Installation für macOS (Apple Silicon und Intel)
# Doppelklick (beim ersten Mal: Rechtsklick → Öffnen) oder im Terminal:  bash installieren.command
set -e
cd "$(dirname "$0")"
ZIEL="$HOME/Library/Application Support/Formeleditor"
APP="$HOME/Applications/Formeleditor.app"
echo ""
echo "=== Formeleditor 1.3.3 wird installiert ==="

PY=""
for K in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [ -x "$K" ] && "$K" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then PY="$K"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3 (ab 3.9) wurde nicht gefunden."
  echo "Bitte Python von python.org installieren (macOS 64-bit universal2 installer) und dieses Skript erneut starten."
  open "https://www.python.org/downloads/macos/"
  exit 1
fi
echo "Python: $PY  ($("$PY" --version 2>&1))"

mkdir -p "$ZIEL"
if [ ! -x "$ZIEL/venv/bin/python" ]; then
  echo "Lege eine eigene Python-Umgebung an …"
  "$PY" -m venv "$ZIEL/venv"
fi
echo "Installiere SymPy, NumPy, SciPy und pywebview (einige Minuten beim ersten Mal) …"
"$ZIEL/venv/bin/python" -m pip install --upgrade --quiet pip
"$ZIEL/venv/bin/python" -m pip install --upgrade --quiet sympy numpy scipy pywebview

echo "Kopiere das Programm …"
rm -rf "$ZIEL/formeleditor"
cp -R formeleditor "$ZIEL/formeleditor"

echo "Erstelle das Programm $APP …"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp Formeleditor.icns "$APP/Contents/Resources/Formeleditor.icns"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Formeleditor</string>
  <key>CFBundleDisplayName</key><string>Formeleditor</string>
  <key>CFBundleIdentifier</key><string>de.ericke.formeleditor</string>
  <key>CFBundleVersion</key><string>1.3.3</string>
  <key>CFBundleShortVersionString</key><string>1.3.3</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleExecutable</key><string>Formeleditor</string>
  <key>CFBundleIconFile</key><string>Formeleditor</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSApplicationCategoryType</key><string>public.app-category.education</string>
  <key>NSAppleEventsUsageDescription</key><string>Der Formeleditor fügt Gleichungen und Grafiken direkt in Pages, Keynote und Numbers ein.</string>
</dict>
</plist>
PLIST
cat > "$APP/Contents/MacOS/Formeleditor" <<'START'
#!/bin/bash
unset PYTHONHOME PYTHONPATH PYTHONSTARTUP PYTHONEXECUTABLE PYTHONUSERBASE DYLD_LIBRARY_PATH DYLD_FALLBACK_LIBRARY_PATH
ZIEL="$HOME/Library/Application Support/Formeleditor"
cd "$ZIEL" || exit 1
exec "$ZIEL/venv/bin/python" -E -m formeleditor --fenster >> "$ZIEL/editor.log" 2>&1
START
chmod +x "$APP/Contents/MacOS/Formeleditor"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"

echo ""
echo "Selbsttest des Rechenkerns:"
"$ZIEL/venv/bin/python" -m formeleditor --selbsttest | tee "$ZIEL/selbsttest.txt" || true
echo ""
echo "=== Fertig ==="
echo "Programm:  $APP  (im Finder unter Benutzerordner → Programme; gern ins Dock ziehen)"
echo "LibreOffice: Extras → Erweiterungen … → Hinzufügen … → Formeleditor.oxt (liegt in diesem Ordner)"
echo "Pages/Keynote/Numbers: „Direkt einfügen“ braucht beim ersten Mal das Recht unter"
echo "  Systemeinstellungen → Datenschutz & Sicherheit → Bedienungshilfen (Formeleditor einschalten)."
echo "Bericht des Selbsttests: $ZIEL/selbsttest.txt"
open -R "$APP"
