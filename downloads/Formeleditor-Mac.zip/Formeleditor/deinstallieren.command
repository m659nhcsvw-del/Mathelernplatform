#!/bin/bash
# Formeleditor entfernen (die LibreOffice-Erweiterung bitte in LibreOffice unter Extras → Erweiterungen entfernen)
rm -rf "$HOME/Applications/Formeleditor.app"
rm -rf "$HOME/Library/Application Support/Formeleditor"
echo "Formeleditor wurde entfernt."
